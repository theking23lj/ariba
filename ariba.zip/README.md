
# MHP Ariba 

This is the assistant Bot for MHP Ariba.

# Installation and Usage


##  Prerequisites

1. Register the bot in BotFather and set `BOT_TELEGRAM_TOKEN` variable
2. Setup Ngrok to setup webhooks
   - Get [ngrok](https://dashboard.ngrok.com/) account and obtain the auth token and [static domain](https://ngrok.com/blog-post/free-static-domains-ngrok-users)  
   - ```ngrok http --domain=YOUR_DOMAIN 8001 --authtoken YOUR TOKEN ```
   - Set the variable `WEBHOOK_URL="https://your_domain.ngrok-free.app/"` in `.env.dev` 
3. Create new mongodb database and set `MONGO_URI` 

## Via Docker
To run the project via Docker, you need to have Docker installed on your machine.

To build the project, run the following command in the project's root directory:
```bash
docker compose build
```
To run the project, run the following:
```bash
docker compose up
```

If you want to add new dependency to the project, run the following command(package for example):
```bash
poetry add pendulum
```
After that, you need to rebuild the project:
```bash
docker compose build
```

If you want to add a new migration for db:
```bash
mongodb-migrate-create --description <description>
```

Apply migrations for db, run from directory 'app/':
```bash
mongodb-migrate --url mongodb://127.0.0.1:27017/db_name
```

## Via VSCode Debugger

1. Set `USE_DEBUGGER=true` the file `docker-compose.yml`
2. To build the project, run the following command in the project's root directory:
    ```bash
    docker compose build
    ```
    To run the project, run the following:
    ```bash
    docker compose up
    ```
3. Run the debuggers for the server and celery worker in VSCode 

## Via Jupyter Notebook
To run the project via Jupyter Notebook, you need to have Jupyter Notebook installed on your machine.

Fist of all, you need to install the project's dependencies locally. To do that, run the following command in the project's root directory:
```bash
poetry install
```

then run the jupyter notebook(it depends on your IDE and/or how you're going to run it)
