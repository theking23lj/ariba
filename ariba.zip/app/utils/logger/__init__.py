from .logger_manager import LoggerManager

logger_manager = LoggerManager()
