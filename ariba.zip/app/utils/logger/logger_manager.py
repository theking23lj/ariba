import logging
from logging import Logger
import http.client as http_client

from opensearch_logger import OpenSearchHandler

from .abc_logger_manager import BaseLoggerManager
from settings import settings


class LoggerManager(BaseLoggerManager):
    def __init__(self):
        self.logging_name = settings.LOGGING_NAME
        self.logging_level = settings.LOGGING_LEVEL.upper()
        self.logging_http_client_enable = settings.LOGGING_HTTP_CLIENT_ENABLE
        self.logging_console_enable = settings.LOGGING_CONSOLE_ENABLE
        self.logging_formatter = settings.LOGGING_FORMATTER
        self.logging_file_enable = settings.LOGGING_FILE_ENABLE
        self.logging_file_path = settings.LOGGING_FILE_PATH
        self.attach_opensearch_logger = settings.ATTACH_OPENSEARCH_LOGGER
        self.osearch_url = settings.OSEARCH_URL
        self.osearch_login = settings.OSEARCH_LOGIN
        self.osearch_pass = settings.OSEARCH_PASS
        self.osearch_index_logs = settings.OSEARCH_INDEX_LOGS
        self.environment = settings.ENVIRONMENT
        self._logger = self.initialize_logger()

    def initialize_logger(self):
        # Create a logger
        logger = logging.getLogger(self.logging_name or __name__)
        logger.setLevel(self.logging_level)

        # Read logs from http connections
        if self.logging_http_client_enable is True:
            http_client.HTTPConnection.debuglevel = 1

        # Console handler
        if self.logging_console_enable is True:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(self.logging_level)
            console_formatter = logging.Formatter(self.logging_formatter)
            console_handler.setFormatter(console_formatter)
            logger.addHandler(console_handler)

        # File handler
        if self.logging_file_enable is True:
            file_handler = logging.FileHandler(self.logging_file_path)
            file_handler.setLevel(self.logging_level)
            file_formatter = logging.Formatter(self.logging_formatter)
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)

        #  Attach opensearch logger
        if self.attach_opensearch_logger is True:
            logger_settings = {
                "index_name": f"{self.osearch_index_logs}-{self.environment}",
                "hosts": [self.osearch_url],
                "http_auth": (self.osearch_login, self.osearch_pass),
                "http_compress": False,
                "use_ssl": True,
                "verify_certs": False,
                "ssl_assert_hostname": False,
                "ssl_show_warn": False,
            }

            logger.addHandler(OpenSearchHandler(**logger_settings))

        return logger

    def get_logger(self) -> Logger:
        return self._logger
