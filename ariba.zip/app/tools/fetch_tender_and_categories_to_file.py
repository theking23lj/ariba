import os
import json
import asyncio
import aiofiles
from typing import List
from pydantic import BaseModel
from tenders.mhp_client import MHPClient


async def save_to_file(path: str, data: List[BaseModel]):
    data = [d.model_dump() for d in data]
    async with aiofiles.open(path, "w", encoding="utf-8") as f:
        await f.write(json.dumps(data, indent=4, ensure_ascii=False))


async def fetch_tenders_and_categories(dir_path: str = "./", count: int = 10):
    """ Fetch data from MHP API and save it partially to JSON files """

    client = MHPClient()
    all_categories = await client.get_categories()
    tenders = await client.get_active_tenders()
    tenders = tenders[:count]
    categories = []

    for tender in tenders:
        for c in tender.commodities:
            for category in all_categories:
                if c.unique_name == category.unique_name \
                        and category not in categories:
                    categories.append(category)
                    break

    await asyncio.gather(
        save_to_file(os.path.join(dir_path, "tenders.json"), tenders),
        save_to_file(os.path.join(dir_path, "categories.json"), categories)
    )
