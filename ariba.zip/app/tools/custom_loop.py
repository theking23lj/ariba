import functools
import inspect
import logging
import weakref
from copy import deepcopy

from agentcore.actions import Call, Continue, Finish
from agentcore.function import Break
from agentcore.loop import Loop
from agentcore.messages import FunctionResult, FunctionCall
from agentcore.utils import args_to_dict
from langsmith import traceable


class custom_loop:

    def __init__(self, loop_kwargs_names: list[str] = None):
        self.loop_kwargs_names = loop_kwargs_names

    def __call__(self, func):
        # TODO: check that func returns Result
        @traceable(name=func.__qualname__)
        @functools.wraps(func)
        async def awrapper(loop: Loop, *args, **kwargs) -> str | None:
            sig = inspect.signature(func)
            kwargs = args_to_dict(sig, *args, **kwargs)
            # TODO validate kwargs
            # TODO decide whether people will need to write custom code for plan method in the classes derived from BaseRole
            #     if yes, then this implementation will ignore their custom code
            for _ in range(loop.max_iterations):
                action = await func(loop, **kwargs)
                logging.debug("\n" + str(action) + "\n")
                if isinstance(action, Finish):
                    return action.text
                if isinstance(action, Continue):
                    continue
                elif isinstance(action, Call):
                    function_kwargs = deepcopy(action.kwargs)
                    if self.loop_kwargs_names:
                        function_kwargs.update({
                            arg_name: weakref.proxy(getattr(loop, arg_name)) for arg_name in self.loop_kwargs_names
                        })

                    result = await action.function.arun(action.text, **function_kwargs)
                    logging.debug("\n" + str(result) + "\n")
                    match result:
                        case Break():
                            if result.text is not None:
                                return result.text
                            else:
                                return
                        case _:
                            loop.inter_steps.append(
                                FunctionCall(action.text, action.function.name, action.kwargs)
                            )
                            value = result if result is not None else "Complete"
                            loop.inter_steps.append(
                                FunctionResult(func_name=action.function.name, value=value)
                            )
                else:
                    raise Exception("Unknown action")  # TODO improve exception
            if loop.escape_func:
                return await loop.escape_func()
            else:
                raise Exception("Too many iterations")

        return awrapper
