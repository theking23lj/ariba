import argparse
import asyncio

from agentcore.tools.knowledge_base_transfer import copy_md_file_to_repo

from repos.knowledge_base import KnowledgeBaseRepository


async def create_knowledge_base(file_path: str):
    repo = await KnowledgeBaseRepository.get_instance()
    await repo.collection.drop()
    res = await copy_md_file_to_repo(file_path, repo)
    print(res)


if __name__ == "__main__":
    argParser = argparse.ArgumentParser()
    argParser.add_argument(
        "--file", "-f", default="../info.md", type=str,
        metavar="<file>", help="Path to file with Knowledge Base. (.md) file"
    )
    parsedArgs = argParser.parse_args()

    asyncio.run(create_knowledge_base(parsedArgs.file))
