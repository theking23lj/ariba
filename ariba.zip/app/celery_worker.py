import asyncio
import uvicorn
from pytz import timezone
from datetime import datetime, timedelta
from multiprocessing import Process
from celery import Celery
from celery.schedules import crontab
from celery.signals import worker_process_init, worker_process_shutdown

from chats.services import notify_admin_about_open_threads, scheduled_reset_tokens_and_unpause_users, clear_old_events
from settings import settings
from health_check import health_check_app
from tenders.services import fetch_tenders_and_categories, get_and_send_tenders, clear_watched_tenders
from tenders.tasks import read_tg_notification_tenders
from utils.logger import logger_manager

logger = logger_manager.get_logger()

health_check_process = None


@health_check_app.get("/")
async def health_check():
    try:
        return {"msg": "OK"}
    except Exception as e:
        logger.exception(e)



celery_app = Celery('tasks', broker=settings.REDIS_URI, backend=settings.REDIS_URI)


@worker_process_init.connect
def on_worker_init(**kwargs):
    global health_check_process
    try:
        def run_server():
            uvicorn.run(health_check_app, host="0.0.0.0",
                        port=settings.CELERY_SERVER_PORT)
        health_check_process = Process(target=run_server, args=(), daemon=True)
        health_check_process.start()
        print("SERVER STARTED")
    except Exception as e:
        logger.exception(e)


@worker_process_shutdown.connect
def on_worker_shutdown(**kwargs):
    global health_check_process
    try:
        if health_check_process is not None:
            health_check_process.terminate()
            health_check_process.join()
        print("SERVER STOPPED")
    except Exception as e:
        logger.exception(e)


def get_localtime():
    return datetime.now(timezone('Europe/Kyiv'))

@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    try:
        sender.add_periodic_task(
            crontab(hour="8", minute='0', nowfun=get_localtime),
            task_notify_admin.s(),
        )
        # Execute every 15 minutes.
        sender.add_periodic_task(
            crontab(minute='*/15'),
            task_fetch_tenders_and_categories.s(),
        )
        sender.add_periodic_task(
            crontab(minute='*/15'),
            task_send_tenders.s(),
        )
        sender.add_periodic_task(
            crontab(day_of_week='mon', hour='0', minute='0', nowfun=get_localtime),
            celery_reset_tokens_and_unpause_users.s(),
        )
        sender.add_periodic_task(
            crontab(minute='*'),
            task_read_tg_notification_tenders.s()
        )
        sender.add_periodic_task(
            crontab(day_of_week='mon', hour='1', minute='0', nowfun=get_localtime),
            task_clear_watched_tenders.s()
        )
        sender.add_periodic_task(
            crontab(hour="1", minute='0', nowfun=get_localtime),
            task_clear_old_events.s()
        )
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def task_notify_admin(skip_time: bool = False):
    try:
        asyncio.run(notify_admin_about_open_threads(skip_time=skip_time))
        return {"Result": True}
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def task_fetch_tenders_and_categories():
    try:
        tenders, categories = asyncio.run(fetch_tenders_and_categories())
        return {
            "Fetched tenders": [t.internal_id for t in tenders],
            "Fetched categories": len(categories),
        }
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def task_clear_watched_tenders():
    try:
        asyncio.run(
            clear_watched_tenders()
        )
        return {"Result": True}
    except Exception as e:
        logger.exception(e)

@celery_app.task()
def task_clear_old_events():
    try:
        now = datetime.now()
        two_weeks_ago = now - timedelta(weeks=2)
        asyncio.run(clear_old_events(int(two_weeks_ago.timestamp())))
        return {"Result": True}
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def task_send_tenders():
    try:
        asyncio.run(get_and_send_tenders())
        return {"Result": True}
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def celery_reset_tokens_and_unpause_users():
    try:
        asyncio.run(scheduled_reset_tokens_and_unpause_users())
    except Exception as e:
        logger.exception(e)


@celery_app.task()
def task_read_tg_notification_tenders():
    try:
        asyncio.run(read_tg_notification_tenders())
        return {"Result": True}
    except Exception as e:
        logger.exception(e)

