#!/bin/sh

# Check if the DEBUG environment variable is set to "true"
if [ "$USE_DEBUGGER" = "true" ]; then
    # Start debugpy with Celery
    echo "Starting Celery worker in debug mode"
    python -m debugpy --listen 0.0.0.0:8003 --wait-for-client -m celery -A celery_worker worker -B --pool=solo --loglevel=info
else
    # Start Celery worker without debugpy
    echo "Starting Celery worker in normal mode"
    # exec uvicorn health_check:health_check_app --host 0.0.0.0 --port 80 &
    celery -A celery_worker worker -B --pool=solo --loglevel=info
fi
