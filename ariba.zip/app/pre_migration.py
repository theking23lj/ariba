import os
from pymongo import MongoClient

# Use os.getenv to retrieve environment variables
MONGO_URI = os.getenv('MONGO_URI')
MONGO_DB_NAME = os.getenv('MONGO_DB_NAME')

client = MongoClient(MONGO_URI)
db = client[MONGO_DB_NAME]

# Drop the collection
collection_name = 'database_migrations'
db.drop_collection(collection_name)

print(f"Collection '{collection_name}' has been dropped.")
