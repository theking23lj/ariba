from langchain_community.callbacks import openai_info

from utils.logger import logger_manager

logger = logger_manager.get_logger()


class TokenHandler:
    @staticmethod
    async def handle_token_usage(repo, chat_id, prompt_tokens, completion_tokens):
        logger.info(f"User {chat_id} spent {prompt_tokens} prompt and {completion_tokens} completion tokens")

        #TODO temporary hack because langchain hasn't added gpt-4o to their mapping table yet
        # since it's twice as expensive as gpt-4-turbo, we'll just double the cost
        prompt_tokens_cost = openai_info.get_openai_token_cost_for_model("gpt-4-turbo", prompt_tokens) * 2.
        completion_tokens_cost = openai_info.get_openai_token_cost_for_model("gpt-4-turbo", completion_tokens) * 2.

        await repo.update_token_usage(chat_id, prompt_tokens_cost, completion_tokens_cost)
