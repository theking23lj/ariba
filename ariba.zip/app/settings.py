import json
from os import path

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

APP_PATH = path.abspath(path.dirname(__file__))
ENV_PATH = path.join(APP_PATH, ".env")
ENV_DEV_PATH = path.join(APP_PATH, ".env.dev")
CONFIG_PATH = path.join(APP_PATH, "config.json")

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=(ENV_PATH, ENV_DEV_PATH))

    BOT_TELEGRAM_TOKEN: str
    ENABLE_EMAIL: bool
    MONGO_URI: str
    MONGO_DB_NAME: str
    ADMIN_EMAIL: str
    LANGCHAIN_TRACING_V2: str
    LANGCHAIN_ENDPOINT: str
    LANGCHAIN_API_KEY: str
    LANGCHAIN_PROJECT: str
    BOT_NAME: str
    MHP_API_URL: str
    MHP_API_KEY: str
    AZURE_KEY: str
    AZURE_ENDPOINT: str
    AZURE_API_VERSION: str
    AZURE_DEPLOYMENT_NAME: str
    AZURE_EMBEDDING_NAME: str
    LLM_MODEL: str
    TEMPERATURE: float
    LOG_NAME: str
    OPENAI_KEY: str
    LLM_API_TYPE: str
    ENABLE_JOBS: bool

    PER_USER_BUDGET: float

    REDIS_URI: str

    GRAPH_CLIENT_ID: str
    GRAPH_CLIENT_SECRET: str
    GRAPH_TENANT_ID: str
    EMAIL_PRINCIPAL_NAME: str

    LOGGING_NAME: str
    LOGGING_LEVEL: str
    LOGGING_HTTP_CLIENT_ENABLE: str
    LOGGING_CONSOLE_ENABLE: bool
    LOGGING_FORMATTER: str
    LOGGING_FILE_ENABLE: bool
    LOGGING_FILE_PATH: str

    ATTACH_OPENSEARCH_LOGGER: bool
    OSEARCH_URL: str
    OSEARCH_LOGIN: str
    OSEARCH_PASS: str
    OSEARCH_INDEX_LOGS: str

    ENVIRONMENT: str
    ADMIN_API_KEY: str | None = None
    CELERY_SERVER_PORT: int = 8004

    VECTOR_DB_URL: str
    VECTOR_DB_API_KEY: str

class SupportContacts(BaseModel):
    message: str

class AppConfig(BaseModel):
    support_contacts: SupportContacts
    
    @classmethod
    def load(cls):
        with open(CONFIG_PATH, 'r') as file:
            settings_json = json.load(file)
        return cls(**settings_json)


settings = Settings()
app_config = AppConfig.load()
__all__ = ['settings', 'app_config', 'APP_PATH']
