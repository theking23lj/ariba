# Official website of MHP
https://mhp.com.ua/
# User Administrator
This is a contact person on the part of the Contracting Company with more advanced powers to manage basic information about the Company and its users registered in SAP Ariba.
# Ariba Sourcing
SAP Ariba module designed to search for suppliers and manage purchasing activities using various types of purchasing procedures
# Ariba Contracts
SAP Ariba module designed to manage contracts with suppliers selected by winners
# Procurement procedure (event or project)
Sequence of actions for the Customer to purchase goods and services
# Request for information (event)
The stage of the tender, during which the Counterparty sends non-price (technical) information.
# Request for proposal (event)
The tender stage, during which the Counterparty sends non-price (technical) and price (commercial) information.
# Auction (event)
A real-time tendering stage in which bidders submit competitive price proposals for specific goods or services.
# Full project
A project consisting of several events (e.g. Request for Proposal and Auction)
# Contract
Document in the SAP Ariba Contracts module, which is sent to the winning supplier based on the results of the procurement procedure
# Supplier 360° profile
Supplier management page accessible to the buyer in the system, containing all available information about the supplier.
# Where can I find a complete list of MHP purchases? Can I see a list of active tenders?
Public tender procedures in SAP Ariba system can be found at this link: https://mhp.com.ua/uk/partners/tendery
# Link to the MHP site with tenders
MHP website page with all of MHP's public tenders: https://mhp.com.ua/uk/partners/tendery
# SAP Ariba system link
https://service.ariba.com/
# SAP Ariba
Cloud platform designed for automating the procurement activities of a company.
# SAP Ariba SLP
SAP Ariba SLP (Supplier Lifecycle and Performance) – SAP Ariba module designed for supplier management.
# Ariba Network
External system where the supplier's personal account is located, allowing them to receive invitations to participate in procurement procedures and manage the basic data of their company.
# Main contact for MHP support service
If you have technical problems you can contact by email s.lesko@mhp.com.ua or phone number 0669934604.
# Additional MHP Contact support service
You can turn to email address is d.kolov@mhp.com.ua, and its telephone number is 0503354807.
# Main contact for Ariba support service
If you have technical problems you can contact by email s.lesko@mhp.com.ua or phone number 0669934604.
# Additional Ariba Contact support service
You can turn to email address d.kolov@mhp.com.ua, and its telephone number is 0503354807.
# Register a supplier and gain access to procurement procedures 
To register a supplier and gain access to procurement procedures in the system, you must complete the following sequence of steps:
Creating a self-registration request;
Registration / Account linking on the Ariba Network portal;
Filling out the MHP registration form.
# Technical Requirements SAP Ariba system
To work with the SAP Ariba system, it is recommended to use the following versions of web browsers:
* Microsoft Edge 32-bit
* Chrome 53+ (64-bit)
* Firefox 48+ (64-bit)
* Safari 9+ (64-bit)
* Microsoft Internet Explorer 11+ 32-bit (until December 31, 2021)

The up-to-date information on supported browsers can be found at the following link: 
https://support.ariba.com/Item/view/130899

Before starting to work with SAP Ariba, it is recommended to clear temporary internet files, cookies, cache, and browsing history in the used browser to avoid errors.
After clearing temporary internet files, cookies, cache, and browsing history, it is necessary to restart the browser.
# Supplier self-registration link
https://mhp.sourcing-eu.ariba.com/ad/selfRegistration
# Supplier self-registration
The starting point for onboarding a supplier in the system is the creation of a self-registration request. 
To initiate this request, you need to follow the link:
https://mhp.sourcing-eu.ariba.com/ad/selfRegistration

After following the link, a window with a form will open, and you need to fill it out.
The supplier self-registration request form consists of three sections:
* Загальна інформація про підприємство
* Supplier's Contact Person Details
* Specify the material and service groups for which the supplier wishes to obtain supplier status
# Self-registration request. Section Загальна інформація про підприємство
In the "Загальна інформація про підприємство" section, initially, four questions are displayed:

* 2.1 Країна реєстрації
* 2.4 Коротка назва підприемства (англiйською мовою)
* 2.8 DUNS 
* 2.9 Реестрaциiний номер (VAT)

Note! In question No. 2.1, only one country can be selected! Otherwise, the system will not be able to create a request!
When selecting an answer for question 2.1 'Країна реєстраці', the form will display unique questions specific to that country.
At the same time, the form also uses unique questions when choosing in question No. 2.2 'Тип організаційно-правової форми власності'.

View of the 'Загальна інформація про підприємство' section when selecting the 'Юридична особа' answer in question No. 2.2:

* 2.1 Країна реєстраці (example: Україна)
* 2.2 Тип організаційно-правової форми власності (example: Юридична особа)
* 2.3 Коротка назва підприємства (in the language of the country of registration)
* 2.5 ЄДРПОУ (Єдиний державний реєстр підприємств та організацій України) 
* 2.6 ІПН (Ідентифікаційний номер платника податків)

View of the 'Загальна інформація про підприємство' section when selecting the 'ФОП' answer in question No. 2.2:

* 2.1 Країна реєстраці (example: Україна)
* 2.2 Тип організаційно-правової форми власності (example: ФОП)
* 2.3 Коротка назва підприємства (in the language of the country of registration) (example: Іван Михайлович Грод)
* 2.7 ІПН (Ідентифікаційний номер платника податків)

Note! Answers to all open questions must be indicated in Ukrainian!
# Self-registration request. Question Країна реєстрації
Question type: Choice
Description: To select an answer, click on the button, then expand the list of countries by clicking on the button "magnifying glass", and select the required country. Text input is also supported, with the system searching for similar values.
Mandatory: Yes
Note: If the answer selected is different from Ukraine, it will affect which questions are displayed in the form.
# Self-registration request. Question Тип організаційно-правової форми власності
Question type: Choice
Options: ФОП (Individual entrepreneur); Юридична особа (Legal entity).
Description: This question affects which subsequent questions are displayed. For "ФОП", question 2.7 "ІПН" is added as mandatory. For "Юридична особа", questions 2.5 "ЄДРПОУ" (mandatory) and 2.6 "ІПН" (optional) are added.
Mandatory: Yes
# Self-registration request. Question Коротка назва підприємства
Description: Enter the supplier's name, which will be displayed in its profile in the system. The following characters are not allowed: /:*?!"<>|#+%”«».,;~().
Mandatory: Yes
# Self-registration request. Question ЄДРПОУ (Єдиний державний реєстр підприємств та організацій України) 
Description: The answer must contain only numbers and be 8 characters long. Displayed only if "Україна" is selected in question 2.1 and "Юридична особа" is selected in question 2.2.
Mandatory: Yes
# Self-registration request. Question ІПН (Ідентифікаційний номер платника податків) для Юридичних осіб
Description: The answer must contain only numbers and be 12 characters long. Displayed only if "Україна" is selected in question 2.1 and "Юридична особа" is selected in question 2.2.
Mandatory: No
# Self-registration request. Question ІПН (Ідентифікаційний номер платника податків) для ФОП
Description: The answer must contain only numbers and be 10 characters long. Displayed only if "Україна" is selected in question 2.1 and "ФОП" is selected in question 2.2.
Mandatory: Yes
# Self-registration request. Section Дані контактної особи постачальника 
In the "Дані контактної особи постачальника" section, for the Ukraine, nine questions are displayed:
* 3.1 Відділ: (example: Продажi [Sales])
* 3.3 Ім’я: (example: Іван)
* 3.4 По-батьковi (example: Іванович)
* 3.5 Прiзвище (example: Іванов)
* 3.6 Код країни (example: +380 Україна [UA])
* 3.7 Телефон (без коду країни)(example: 444618061)
* 3.8 Email (example: ivan.ivanov@mail.ua)
* 3.9 Часовий пояс, за яким плануватимуться майбутні закупівельні заходи (example: Europe/Kiev (Eastern European Time))
* 3.10 Укажіть мову комунікації, якій віддаэте перевагу (example: Українська [ru_RU])
# Self-registration request. Question Відділ
Question type: Choice  
Description: Select the department of the contact person at the supplier's side. The choice determines the "Contact Type" that will be displayed in the supplier's profile in SAP Ariba MHP.  
Options:  
- Продажі 
- Технічний спеціаліст
- Якість 
- Фінанси 
- Раціональне використання 
- Юридичний 
- Власник бізнесу 
- Електронна комерція 
- Служба підтримки 
- Менеджер торгів 
- Дебіторська заборгованість
Mandatory: Yes
# Self-registration request. Question Ім'я
Question type: Text  
Description: Enter the first name of the supplier's contact person.  
Mandatory: Yes
# Self-registration request. Question По-батьковi
Question type: Text  
Description: Enter the patronymic of the supplier's contact person.  
Mandatory: No
# Self-registration request. Question Прізвище
Question type: Text  
Description: Enter the last name of the supplier's contact person.  
Mandatory: Yes
# Self-registration request. Question Код країни
Question type: Choice  
Description: Select the country code from a dropdown list.  
Mandatory: Yes
# Self-registration request. Question Телефон (без коду країни)
Question type: Text  
Description: Enter the phone number of the supplier's contact person without the country code.  
Mandatory: Yes
# Self-registration request. Question E-mail
Question type: Text  
Description: Specify the email address where the supplier will receive notifications about registration invitations and procurement procedures.  
Mandatory: Yes
# Self-registration request. Question Часовий пояс, за яким плануватимуться майбутні закупівельні заходи
Question type: Choice  
Default: Europe/Kiev (Eastern European Time)  
Description: Determines how the deadlines for procurement procedures will be displayed in email notifications to the supplier.  
Mandatory: Yes
# Self-registration request. Question Бажана мова комунікації
Question type: Choice  
Options:  
- Українська (Ukrainian)  
- Англійська (English)  
Description: Specifies the language in which the supplier will receive email notifications.  
Mandatory: Yes  
# Self-registration request. Section Вкажіть групи матеріалів/послуг, за якими Ви маєте намір отримати статус постачальника
In this section, suppliers are required to specify the categories of goods/services they intend to supply. This information is crucial for matching supplier capabilities with procurement needs.

* 4.1 Категорія товарів/послуг, що постачаються
    - Question type: Multiple Choice
    - Description: Suppliers must select one or more categories of goods/services they plan to participate in procurement procedures for.
    - Mandatory: Yes

* 4.2 Вкажіть країни, в яких працює Ваша компанія
    - Question type: Multiple Choice
    - Description: Suppliers need to select one or more countries where they operate.
    - Mandatory: Yes
# Self-registration request. Question Категорія товарів/послуг, що постачаються
To open the directory, you need to click on the button, then click the 🔍("magnifying glass") button.
The directory is presented in the form of a hierarchical structure with three levels of product/service categories. 
Each category of levels 1 and 2 can be expanded with the ▶️(">") button.
When you select a specific category, all subordinate, nested categories are selected.
To select a category, you need to mark it with the ☑️("check mark") indicator, and it will be displayed at the bottom of the field.
# Self-registration request. Question Вкажіть країни, в яких працює Ваша компанія
You need to select one or more countries where the supplier operates.
To open the directory, click on the 🔍("magnifying glass") button, then click the ▶️(">") button.
The directory presents a list of countries in two languages.
To select a category, mark it with the ☑️("check mark") indicator, and it will be displayed at the bottom of the field.
The directories can also be filled by entering a text value, and the system will display options corresponding to the entered text.
# Country of registration is not Ukraine
If the supplier is not a resident of Ukraine, indicating another country of registration in question 2.1 in the form will result in several changes:

Questions that will be hidden:
* 2.2 Тип організаційно-правової форми власності;
* 2.3 Коротка назва підприємства (мовою країни реєстрації);
* 2.5 ЄДРПОУ;
* 2.6 ІПН (для юридичних осіб);
* 2.7 ІПН (для ФОП).

Questions that will be displayed:

Table 6. Questions for non-residents of Ukraine

| №   | Question                                           | Description                                                                                   | Mandatory |
|-----|----------------------------------------------------|-----------------------------------------------------------------------------------------------|-----------|
| 2.4 | Коротка назва підприємства (англійською мовою)     | This field should contain the supplier's name, which will be displayed in its profile.        | Yes       |
| 2.8 | DUNS                                               | This field should contain the supplier's DUNS number.                                         | No        |
| 2.9 | Реєстраційний номер                                | This field should contain the supplier's tax identification number.                           | Yes       |
| 4.2 | Форма звернення                                    | A question with a choice of answer. Available options: Mr; Mrs; Miss.                         | No        |

To submit the form, you need to press the "Submit" button at the bottom of the form.
After pressing the "Submit" button, a window with a summary of the submitted form information is displayed to the user.
Once the supplier's request is approved by the manager in the system and the supplier is invited to register, the supplier's user will receive an email notification about the invitation to register.
# Self-registration request. Submitting the form
To submit the form, click the "Submit" button at the bottom of the form. After clicking the "Submit" button, a window will appear displaying a summary of the information submitted in the form.
After the manager approves the supplier request in the system and invites the supplier to register, the supplier user will receive an email notification inviting them to register.
# Registering in Ariba Network
After the manager approves the supplier’s request in the system and invites the supplier to register, the supplier’s user will receive an email notification of the invitation to register.

After clicking on the link in the letter, the user will open the Ariba Network page, where it is possible to register a new supplier account or log into an existing one if the supplier has previously registered a company in Ariba Network.

If the supplier logs in under his account, the MHP Ariba account is synchronized with the supplier’s existing Ariba Network account, then the supplier fills out a registration form to gain access to the MHP procurement procedures.
The following will cover the steps to create a new account on Ariba Network.
When you click on the “Registration” button in Ariba Network, a registration form opens, which consists of several sections:
* Сведения о компании 
* Данные учетной записи пользователя
* Подробная информация о компании (категории/регионы предоставления товаров/услуг) 
* Согласие с политиками использования и конфиденциальности 
# Registering in Ariba Network. Сведения о компании 
In the “Сведения о компании” section, you must provide basic information about your company: company name and address information.

EXAMPLE:
- Название компании: "Instruction Corp"
- Страна/регион*: "Украина [UKR]"
- Почтовый индекс*: "38509"
- Штат/Область*: "Выбрать"
- Город: "Киев"
- Адрес: "ул. Льва Толстого 11, пом. 25А"
# Registering in Ariba Network. Данные учетной записи пользователя
Below you need to fill in the details of your personal user account, which will subsequently be used by the provider user to log into Ariba Network.

EXAMPLE:
- Имя: Андрей
- Фамилия: Смирнов
- Электронная почта: test_2504_1@mail.ua
- [ ] Использовать адрес эл. почты в качестве имени пользователя
- Имя пользователя: andrey.smirnov@mail.ua "Must be in the format (john@newco.com)"
- Пароль: ******** (дважды) "The password must contain a minimum of eight characters, including uppercase and lowercase letters, numbers, and special characters."
- Язык: Русский
# Registering in Ariba Network. Расскажите подробнее о Вашей компании
In the detailed company information section, you must indicate the categories of goods and services, as well as the regions of delivery or provision of services.
These questions can be filled in by text input of a value or by selecting a value from the reference book by clicking the “Browse” button.
When you click the “Browse” button, a page for selecting values from a hierarchical reference book opens, in which you need to select one or more values, then click the “OK” button.

Note! The reference books for the category/region questions for the provision of goods/services in the Ariba Network registration form differ from similar ones in the “Supplier Request” and “Supplier Registration Form” documents. These questions on the Ariba Network registration form do NOT affect purchasing procedures as an MHP supplier!
# Registering in Ariba Network. Согласие с политиками использования и конфиденциальности 
At the bottom of the page, you must mark the fields that agree with the company’s policies with indicators and click the “Создать учетную запись и продолжить” button.
# Filling out the Supplier registration questionnaire as an MHP supplier. Page content
After registering with Ariba Network, the user is automatically redirected to the page for filling out the registration form as an MHP supplier.

- This page contains the following elements:
- The “Event” area, where all sections of the registration form are displayed;
- Area for filling out the registration form;
- “Suggest” button to send the completed questionnaire;
- The “Save draft” button, where you can save the current state of the registration form;
- “Hide/Expand” button for more convenient display of the questionnaire;
- The remaining time during which the questionnaire remains open for filling out;
- Button to go to the control panel for MHP questionnaires and events.

Question Types and Their Representation in the Form:
- Question with a selection from a directory. **Type in the form**: A question where you need to select a value from a directory by clicking the "Select" button.
- Question with a choice of answer. **Type in the form**: A question where you need to select a value from a dropdown list that opens when you click on the answer field.
- Question with text input. **Type in the form**: A question where you need to specify a text value. If the value is entered incorrectly, the system will display an error and highlight the question in red.
- Question with additional attachment and comment. **Type in the form**: In this type of question, clicking the blue button in the bottom right corner opens a page where the user can add a file as an attachment and an additional comment.
- Question in a repeating section. **Type in the form**: In this type of questions, you need to specify the supplier's banking details by clicking the "Add Banking Details" button.
If necessary, you can add more than one value by clicking the "Add additional banking details" button. In this question, you only need to fill in the bank's country and IBAN number.
- Attachment type question. **Type in the form**: In this type of question, the user needs to click the "Attach file" button and then select the required file on their computer to attach to the form. This type of questions is often accompanied by an example of the attachment next to the question text (Figure 28).

Questions that are mandatory to fill are marked with a red asterisk (*).

If there are errors or unfilled required fields, the system will display a corresponding message and highlight the fields that need to be corrected/filled in.
After sending the registration form, it is automatically approved in the system (with current settings). The provider user receives a notification that their registration form has been approved.
# SAP Ariba Service link as an MHP supplier
https://service.ariba.com/Supplier.aw/1249990604/aw?awhr=aw&awssk=ozZMUh53&dard=1
# Filling out the Supplier registration questionnaire as an MHP supplier. Recommendations
WE RECOMMEND LOG IN TO THE SAP ARIBA PLATFORM IN A BROWSER, THROUGH INCOGNITO MODE
- New window in Incognito mode/new window in anonymous (private) viewing mode (key combination Ctrl+Shift+N)
- Copy and paste this list into the address field

https://service.ariba.com/Supplier.aw/1249990604/aw?awhr=aw&awssk=ozZMUh53&dard=1

- enter Username login (probably this is your email)
- password (the one you used when creating this account)
In the middle of the screen - go to the Supplier registration questionnaire tab

In the upper left corner of Business Network →
Ariba Proposals and Questionnaires

MHP Holding tab

Supplier registration questionnaire tab →
fill in the questionnaire data

Events tab →
tenders are displayed

Qualification Questionnaire tab →
fill in after Registration

Supplier registration questionnaire

Fill in the fields in the questionnaire with * sign.
Important!
p.2.1 Selection of categories_categories must be chosen by 3 levels of the hierarchy or by 2, if it is the last.
Fill in the required fields marked with a *.
P.9.1 - attach the Charter
P.9.2 – close f.1 Balance sheet for past periods
In case of absence, related documents: extract from the ЄДР, certificate of opening a bank account, etc.

For ФОП - attach ІПН, certificate about opening a bank account, etc.
Fill in all the necessary fields, click Submit Entire Response - OK.
Your application goes to us for accreditation. Upon approval and/or if it is necessary to make corrections to the application data, a letter will be sent to your mail.
# Filling out the Supplier registration questionnaire as an MHP supplier. Changing the Supplier registration questionnaire
The registration form remains in the “Open” state even after it is initially filled out and sent to the Ariba MHP system.
If the supplier user needs to update the registration form data, then on the questionnaires and events control panel you need to click on the name of the registration form.
After opening the registration form, you need to click the “Change Offer” button, then change the necessary data in the form and click the “Offer” button again.

Left in the upper corner.
1.Business Network → 2. Ariba Proposals and Questionnaires → 3. MHP Holding tab → 4. in the middle of the Supplier registration questionnaire screen

In the registration form, click on the blue Change offer/View answer tab. After that, you can make changes to this questionnaire.
Importantly!
In clause 2.1 Selection of categories and services, categories must be selected according to the last level, as a rule, this is the 3rd level of categories with the 6th digit identifier code or the 2nd level with the 4th digit by the identifier code, if it is the last one.
Importantly!
P.10.1 - insert the Charter
P.10.2 - insert f.1 Balance for past periods
In case of absence - related documents: extract from the ЄДР, certificate of opening a bank account, etc.

For ФОП - attach ІПН, certificate of opening a bank account, etc.
If you need to adjust attached files, click on Update the file and attach the document we need.
The system prompts if something has been omitted. After filling in all the necessary fields, click on the blue "Offer" tab. You have sent us your application for accreditation. If the application data has been correctly and correctly filled out by you, please wait for approval from the MHP staff in the near future.
• You will be informed by a corresponding letter.
• If necessary, make adjustments to the registration form supplier, you will be informed by a corresponding letter.
# Page doesn't load completely
1. You need to turn off the ad blocker! (possible blockers ADBLOCK, ADGUARD)
2. Delete cookies.
3. We do not recommend opening many tabs in your browser.
4. Or you can open a new window in Incognito mode and work in it.
# I have Ariba in English, how to translate it into Ukrainian?
Dear partners, the SAP Ariba electronic trading platform is currently available in Russian, unfortunately. It is already being translated into Ukrainian, but it will take time and our patience.
According to information from foreign developers, the first part of the translation will be integrated by the end of 2023. The system will be fully translated into Ukrainian in 2024.
To use the site in Ukrainian, you need to change the language of the Internet browser to Russian, or continue working on the English version of the site.
# Service Ariba password change link
https://service.ariba.com/Sourcing.aw/109521011/aw?awh=r&awssk=4JsOb3VX&dard=1&ancdc=2
# How to recover your login password
What are your actions if you forget your personal account password:

To reset your password, you need to follow the link:
https://service.ariba.com/Sourcing.aw/109521011/aw?awh=r&awssk=4JsOb3VX&dard=1&ancdc=2

And click on the word "password".
# Participation in the tender. How to participate in the tender of the MHP company?
First of all, it is necessary to be registered on the SAP Ariba platform, as well as to be accredited by the MHP.
# I've signed up, but I can't see anything in the "Events" section. In my personal account in SAP.
Please inform your responsible manager from the MHP company to invite you to the tender you are interested in.
# Where should messages go? I am afraid to miss the tender.
System messages will be sent to your registered mail from the manager conducting this tender. Tenders will also be displayed in the "Events" tab.
# Participation in procurement procedures. General instructions for SAP Ariba
Before starting work, it is necessary:
1. You need to turn off the ad blocker! (possible blockers ADBLOCK, ADGUARD)
2. Delete cookies.
3. We do not recommend opening many tabs in your browser.
4. Or you can open a new window in Incognito mode and work in it.

Browser language - Russian. If, for example, you speak Ukrainian, then the SAP Ariba platform will be displayed in English.
# Participation in procurement procedures. Error 404 "The requested page was not found"
If the page cannot be displayed, you should contact the technical support of your company or the technical support of your Internet provider.
# Participation in procurement procedures. Invitations and notifications for participation in Procurement procedures are not received by email
If notifications are not received by email, you should contact your internal IT service with a request to check whether emails from the following email address ordersender-prod@ansmtp.ariba.com have been blocked.
# Participation in procurement procedures. There are no events in your personal account from the MHP company
If the MHP company has invited you to participate in events, but this event is not displayed for you, then contact the MHP company administrator.
# Participation in procurement procedures. Opening a Procurement Procedure in the System
The list of events you are invited to participate in can be found under "Ariba Proposals and Questionnaires". To navigate to this section, click on the arrow in the top left corner and select "Ariba Proposals and Questionnaires" from the dropdown menu.

In the "Events" table, various events are listed: Requests for Proposal, Requests for Information, and Auctions conducted by MHP. Events are grouped by their current status (see Table 1).

Table 1

| Event Status         | Description |
|----------------------|-------------|
| Preliminary Review   | The event is available to suppliers for preliminary review of content before the start. In this state, suppliers can view the content in the event and submit preliminary proposals (if this feature is enabled in the event) |
| Open                 | The event is open for proposal submission |
| Selection Expected   | The event is closed for proposal submission, the buyer is analyzing the submitted proposals and may reopen the event for proposal submission if necessary |
| Closed               | The event is closed for proposal submission and a winner has been selected. The event cannot be reopened for proposal submission |


To open an event, click on its title in the system. To participate in an event, the following steps are required:

1. Verify event details
2. Read and accept the terms and conditions
3. Submit a proposal

The number of steps depends on the settings established by the event owner.
# Participation in procurement procedures. View event data
After you have opened an event in the system, you will be redirected to the “Check Event Data” tab. On this tab you can view the basic event data provided by the project owner. In addition, you can also download this data by clicking on the 'Print Event Details' button.
# Participation in procurement procedures. Participation and refusal to participate in the event, mandatory conditions for the bidder
Once you have reviewed the basic event details, you can proceed to submit an event proposal or decline to participate. In order to refuse to participate in the event and no longer receive notifications about it, you must click on the 'Refuse to participate' button. If you plan to participate in the event, you must click on the 'View prerequisites' button.

In the window that opens, you can view the mandatory conditions that must be accepted for further participation in the auction. Select the option 'I accept the terms of this agreement' if you accept the terms of this agreement, and 'I do not accept the terms of this agreement' if you do not accept the terms of this agreement and do not plan to participate in the event. Once you have selected the required option, press the 'OK' button to move to the next page.

If you have selected the 'I accept the terms of this agreement' option, after clicking the 'OK' button, a window will appear on the screen in which you will need to confirm your acceptance of the agreement by clicking the 'OK' button again.
# Participation in procurement procedures. Viewing content in an event
Once you have reviewed and accepted the event's prerequisites, you can view the event's contents in detail, including the issues, items, and lots for which you are required to submit a bid. You can switch between content sections by clicking on the 'Previous' and 'Next' buttons, and also use the menu on the left to go to the desired section. In addition, you can also click the 'Print Event Details' button to download the event details, including the event content information.

If you are participating in an auction, you can also view the reduction conditions for each item/lot. To do this, you need to find the position/lot in the content and click on it. In the window that opens, you can view all the features of trading for a given position/lot, including the minimum step to reduce the offer.
# Participation in procurement procedures. Selection of lots to submit an offer
Selection of lots to submit an offer

After you have familiarized yourself with the contents of the event, you need to select the lots/items for which you will submit an offer. To do this, click on the 'Select' lots button.

Next, in the window that opens, you need to select the positions/lots that you will include in your offer. To do this, you need to select all the necessary positions that will be included in the proposal and indicate the reason in the 'Reason for refusal' field why you refuse to submit a proposal for the positions that you do not include in the proposal. You also need to select the currency in which you will submit the offer in the 'Select event bidding currency' field.

In addition, if the project owner has set the appropriate settings, you can also add your own position to the already added positions by clicking the 'Add new lot' button. Next, in the window that opens, you must enter the name of the position to be added in the “Name” field, a description of the position in the “Description” field, and then click 'Finish'.

After clicking the 'Finish' button, the position will appear in the general list of positions. You can change this position by clicking on it and selecting the 'Change' option. You can also delete this position if necessary.

After you select/add all the required lots/items, you must click on the 'Confirm selected lots' button to move to the next tab for submitting an offer.
# Participation in procurement procedures. Submitting a Proposal
After selecting the lots, you will be taken to the proposal submission page. On this page, you are required to enter responses for all questions, positions, and lots in the content. The types of responses for the content are provided in Table 2.

Table 2

| Name                    | Description                                      | Example Response          |
|-------------------------|--------------------------------------------------|---------------------------|
| Monetary Amount         | A number recognized by the system as an amount of money in any currency | "10000"                   |
| Text                    | Text string                                      | "We can deliver the goods within 10 days" |
| Dropdown Selection      | Choice from several response options             | "Post-payment"            |
| Integer or Decimal      | Any number                                       | "5", "5.7"                |
| Calendar Date           | Date                                             | 12.04.2001                |
| Yes/No                  | Choice between two response options              | "Yes"                     |
| Attachment              | A file needs to be attached                      |                           |
| Address                 | Enter the address by terms (city, country, street, etc.) | Kiev, Ukraine, Example Street, 1 |

After providing all the responses, click "Submit" to submit your proposal. If you have not filled in any of the mandatory fields or have given a response of the wrong type, an error warning will be displayed. After correcting this error, you will be able to submit your proposal. Additionally, you can save your proposal by clicking the 'Save' button to continue editing the proposal in the next session in the system.

Next, you need to confirm the submission of the proposal in the system by clicking the 'OK' button.

After the proposal has been submitted, you can change it by clicking the 'Change Proposal' button.
# Participation in procurement procedures. Creating a message to the project owner
To create a message to the project owner, you need to click the 'Create Message' button at the bottom of the page.

In the window that opens, you must specify the subject of the message you are creating, write the text of the message, and if necessary, attach an attachment. After this, click the 'Send' button to send the message.

You will also be able to view all questions and answers regarding the message by clicking the 'Response Log' button in the event.
# Participation in procurement procedures. Creating an Alternative Offer
You can create an alternative proposal after submitting the main proposal in the system if the project owner has provided such an opportunity. To do this, go to the event for which the proposal was submitted and click the 'Create Alternative' button, then select the type of alternative you are creating.

Table 3

| Name                | Description |
|---------------------|-------------|
| Alternative Prices  | This type of alternative is used if you plan to indicate alternative prices for a position, providing answers that differ from the main proposal (e.g., payment terms) |
| Alternative Package | This type of alternative is used if you plan to combine several positions into a package to offer a discount if the project owner selects you as the winner for all positions included in the package |
| Alternative Level   | This type of alternative is used if you plan to offer different prices depending on the quantity purchased from you |

After selecting the required type of alternative, a window will open showing the positions/lots (including positions added by you) available for inclusion in the alternative proposal. You need to select the positions/lots to be included in the alternative, then fill in the name of the alternative, specify the currency of the proposal, and click the 'OK' button.

Next, you need to provide responses to all questions in the alternative proposal, similar to submitting the main proposal as described in section 7.6 of this instruction. After this, click the 'Submit' button.
# Participation in procurement procedures. Submitting a Proposal Using Excel Import
To submit a proposal in the system, the import function from Excel is provided. To access the Excel format content upload menu, click 'Import from Excel'.

Next, you will move to the content upload and download screen. Click the 'Upload Content' button to download the event content as an Excel table.

The downloaded Excel file contains the following sheets:

- Proposal Submission – instructions for working with the file;
- Other tabs – list of price and non-price conditions required for submitting a proposal.

To submit a proposal, you need to fill in all cells highlighted in yellow on all tabs except the "Proposal Submission" tab.

After filling in all the cells highlighted in yellow, save the file to your computer's local disk. Then, you need to go to the SAP Ariba system, and at Step 3, select the file you saved and click the 'Upload to Server' button.

If your import file was successfully processed, you will see a confirmation message. Click the 'OK' button and then 'Submit' to submit your proposal.
# Participation in procurement procedures. Providing access to Ariba Network to other company users
If you are the administrator of your company on the Ariba Network portal, you can grant access to your colleagues. Click on your initials in the top right corner, then click 'Settings' and select 'Users'.

In the opened window, available roles created for company users will be displayed. If the required role is missing, you can create it by clicking on the "plus" sign.

When creating a role, add the name of the role in the "Name" field, then select the available system permissions for it. After this, click the 'Save' button.

Next, go to the "User Management" tab. To create a user in the system, click on the plus button.

In the opened window, enter the unique user identifier in the "Username" field, email address for receiving notifications in the "Email Address" field, then enter the user's full name in the corresponding fields. Next, select the required role for the user from the list and click 'Done' to complete the process of adding a user.

Click the 'Save' button to save the added users in the system.
# Participation in procurement procedures. Access the Help Center
To access the help center, click on the question mark icon in the top right corner.

In the window that opens on the right, the help center will be displayed, containing answers to frequently asked questions. To go to the extended view of the help center, click the 'Documentation' or 'Support' button.
