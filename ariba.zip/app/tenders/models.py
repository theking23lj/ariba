from datetime import datetime

from pydantic import BaseModel, Field, AliasChoices


DATETIME_FORMAT = '%d.%m.%Y %H:%M'

class TenderCategory(BaseModel):
    id: int
    unique_name: str # unique name for category, in format XXYYZZ where XX - parent category, YY - subcategory, ZZ - subsubcategory
    name_ru: str | None
    name_en: str | None
    parent_id: int | None = None
    children: list['TenderCategory'] | None = Field(None, validation_alias=AliasChoices("children", "childs"))
    vector_name: str | None = None

    def get_name(self) -> str:
        if not self.name_ru and not self.name_en:
            raise Exception(f"Category {self.unique_name} has no name")
        return self.name_ru if self.name_ru else self.name_en # type: ignore


class TenderCommodity(BaseModel):
    unique_name: str


class Tender(BaseModel):
    internal_id: str
    link: str
    is_active: bool

    title_ua: str | None = None
    title_en: str | None = None
    event_type_name: str | None = None
    description_ua: str | None = None
    description_en: str | None = None
    open_date_detailed: int | None = None
    close_date_detailed: int | None = None
    status: str | None = None
    manager_name: str | None = Field(None, alias='managerName')
    manager_email: str | None = Field(None, alias='managerEmail')
    attach: list[dict[str, str]] = []
    regions: list[dict[str, str]] = []
    commodities: list[TenderCommodity] = []
    departments: list[dict[str, str]] = Field(alias='departaments', default_factory=list)


    class Config:
        populate_by_name = True

    def to_short_ua_message(self, categories: dict[str, TenderCategory]) -> str:
        title = self.title_ua if self.title_ua else self.title_en
        
        own_categories = [categories[c.unique_name] for c in self.commodities if c.unique_name in categories]
        categories_lines = []
        for c in own_categories:
            name = c.name_ru if c.name_ru else c.name_en
            categories_lines.append(name)
        categories_str = "\n".join(categories_lines)

        close_date = "не вказано"
        if self.close_date_detailed:
            close_date = datetime.fromtimestamp(self.close_date_detailed // 1000).strftime(DATETIME_FORMAT)

        return (
            f"Назва тендеру: {title}\n\nКатегорія закупівлі:\n{categories_str}\n\n"
            f"ПІБ менеджера, який проводить тендер: {self.manager_name}\n\n"
            f"Пошта менеджера, який проводить тендер: {self.manager_email}\n\n"
            f"Дата завершення: {close_date}\n\n"
            f"Більш детальна інформація за посиланням: <a href='{self.link}'>Інформація</a>"
        )

    def to_short_ua_html_message(self, categories: dict[str, TenderCategory]) -> str:
        title = self.title_ua if self.title_ua else self.title_en

        own_categories = [categories[c.unique_name] for c in self.commodities if c.unique_name in categories]
        categories_lines = []
        for c in own_categories:
            name = c.name_ru if c.name_ru else c.name_en
            categories_lines.append(name)
        categories_str = "<br>".join(categories_lines)

        close_date = "не вказано"
        if self.close_date_detailed:
            close_date = datetime.fromtimestamp(self.close_date_detailed // 1000).strftime(DATETIME_FORMAT)

        return (
            f"<br>Назва тендеру: {title}<br><br>Категорія закупівлі:<br>{categories_str}<br><br>"
            f"ПІБ менеджера, який проводить тендер: {self.manager_name}<br><br>"
            f"Пошта менеджера, який проводить тендер: {self.manager_email}<br>"
            f"Дата завершення: {close_date}<br>"
            f"Більш детальна інформація за посиланням: <a href='{self.link}'>Інформація</a>"
        )

    def to_short_en_message(self, categories: dict[str, TenderCategory]) -> str:
        title = self.title_en if self.title_en else self.title_ua

        own_categories = [categories[c.unique_name] for c in self.commodities if c.unique_name in categories]
        categories_lines = []
        for c in own_categories:
            name = c.name_en if c.name_en else c.name_ru
            categories_lines.append(name)
        categories_str = "\n".join(categories_lines)

        close_date = "not specified"
        if self.close_date_detailed:
            close_date = datetime.fromtimestamp(self.close_date_detailed // 1000).strftime(DATETIME_FORMAT)

        return (
            f"Tender name: {title}\n\nPurchase category:\n{categories_str}\n\n"
            f"Name of the manager conducting the tender: {self.manager_name}\n\n"
            f"Mail of the manager who conducts the tender: {self.manager_email}\n\n"
            f"Completion date: {close_date}\n\n"
            f"More detailed information at the link: <a href='{self.link}'>Information</a>"
        )

    def to_short_en_html_message(self, categories: dict[str, TenderCategory]) -> str:
        title = self.title_en if self.title_en else self.title_ua

        
        own_categories = [categories[c.unique_name] for c in self.commodities if c.unique_name in categories]
        categories_lines = []
        for c in own_categories:
            name = c.name_en if c.name_en else c.name_ru
            categories_lines.append(name)
        categories_str = "<br>".join(categories_lines)

        close_date = "not specified"
        if self.close_date_detailed:
            close_date = datetime.fromtimestamp(self.close_date_detailed // 1000).strftime(DATETIME_FORMAT)

        return (
            f"<br>Tender name: {title}<br><br>Purchase category:<br>{categories_str}<br><br>"
            f"Name of the manager conducting the tender: {self.manager_name}<br><br>"
            f"Mail of the manager who conducts the tender: {self.manager_email}<br>"
            f"Completion date: {close_date}<br>"
            f"More detailed information at the link: <a href='{self.link}'>Information</a>"
        )
