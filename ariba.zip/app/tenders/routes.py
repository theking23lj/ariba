from fastapi import APIRouter

from broadcast.constants import BroadcastType
from celery_worker import task_clear_watched_tenders
from broadcast.repo import BroadcastCache
from chats.email_user_chat import EmailMessageDistributor
from chats.tg_chat import TgMessageDistributor
from repos.email_user import EmailUserMongoRepository
from repos.tg_user import TgUserMongoRepository
from tenders.services import fetch_tenders, get_and_send_tenders
from utils.logger import logger_manager

logger = logger_manager.get_logger()

router = APIRouter(
    prefix="/tenders",
    tags=["tenders"],
)


@router.get("/fetch_active/")
async def send_active_tenders_to_all():
    await get_and_send_tenders()
    return {"Tenders are sent."}


@router.post("/add_categories_to_tg_user/")
async def add_categories_to_tg_user(username: str, categories: list[str]):
    repo = await TgUserMongoRepository.get_instance()
    await repo.add_chosen_categories(username, categories)

    return "Added."


@router.post("/fetch_active_tenders_for_user/")
async def fetch_active_tenders_for_user(username: str, user_type: BroadcastType, skip_watched: bool = False):
    user, sender = None, None
    match user_type:
        case BroadcastType.TELEGRAM:
            repo = await TgUserMongoRepository.get_instance()
            user = await repo.get_user_by_username(username)
            sender = await TgMessageDistributor.build(broadcast_cache=BroadcastCache.get_instance())
        case BroadcastType.EMAIL:
            repo = await EmailUserMongoRepository.get_instance()
            user = await repo.get_user_by_chat_id(username)
            sender = await EmailMessageDistributor.build(broadcast_cache=BroadcastCache.get_instance())
        case BroadcastType.ALL:
            return "Bad user_type."

    if user is None:
        return "Can not find user."

    tenders = await fetch_tenders()
    await sender.send_tenders_to_one(user.chat_id, tenders, skip_watched=skip_watched)

    return "Tenders is fetched for the user."


@router.post("/clear_categories_and_watched_tenders_for_user/")
async def clear_categories_and_watched_tenders_for_user(username: str, user_type: BroadcastType):
    user, repo = None, None
    match user_type:
        case BroadcastType.TELEGRAM:
            repo = await TgUserMongoRepository.get_instance()
            user = await repo.get_user_by_username(username)
        case BroadcastType.EMAIL:
            repo = await EmailUserMongoRepository.get_instance()
            user = await repo.get_user_by_chat_id(username)
        case BroadcastType.ALL:
            return "Bad user_type."

    if user is None:
        return "Can not find user."

    await repo.clear_watched_tenders(user)
    await repo.clear_waiting_tenders(user)
    await repo.clear_chosen_categories(user)

    return "Watched tenders and chosen categories are clean."


@router.get("/start_clear_watched_tenders_for_all_users_task")
async def start_clear_watched_tenders_for_all_users_task():
    result = task_clear_watched_tenders.delay()

    return {"task_id": result.id}

