from pymongo import UpdateOne
from qdrant_client.models import PointStruct

from typing import List

from repos.base import BaseQdrantRepository, BaseRepository
from tenders.models import TenderCategory, Tender


class TenderRepository(BaseQdrantRepository, BaseRepository):
    vector_collection_name: str = "tenders_categories"
    limit_vector_search: int = 20

    async def bulk_write_categories(self, categories: List[TenderCategory]) -> None:
        qdrant_client = await self.get_qdrant_client(self.vector_collection_name)

        actions = list()
        points = list()
        titles = list()

        # Formation of titles for vectorization
        for category in categories:
            titles.append(category.vector_name)

        list_of_vectors = await self.get_list_of_vectors(titles)

        for i, category in enumerate(categories):
            actions.append(
                UpdateOne(
                    {"id": category.id},
                    {"$set": category.model_dump()},
                    upsert=True
                )
            )
            point = PointStruct(
                id=category.id,
                vector=list_of_vectors[i],
                payload=category.model_dump()
            )
            points.append(point)

        await self.db.tender_categories.bulk_write(actions)

        await qdrant_client.upsert(
            collection_name=self.vector_collection_name,
            points=points,
        )

    async def vector_search_categories(self, title: str) -> list[TenderCategory]:
        vector = await self.get_vector(title)
        client = await self.get_qdrant_client(self.vector_collection_name)
        categories = await client.search(
            collection_name=self.vector_collection_name,
            query_vector=vector,
            limit=self.limit_vector_search,
            append_payload=True
        )
        return [TenderCategory(**category.payload) for category in categories]

    async def get_categories(self) -> list[TenderCategory]:
        categories = await self.db.tender_categories.find().to_list(None)
        return [TenderCategory(**category) for category in categories]
    
    async def get_categories_by_unique_names(self, unique_names: list[str]) -> list[TenderCategory]:
        categories = await self.db.tender_categories.find({"unique_name": {"$in": unique_names}}).to_list(None)
        return [TenderCategory(**category) for category in categories]

    async def get_top_level_categories(self) -> list[TenderCategory]:
        categories = await self.db.tender_categories.find({"parent_id": None}).to_list(None)
        return [TenderCategory(**category) for category in categories]
    
    async def find_category(self, name: str) -> TenderCategory | None:
        category = await self.db.tender_categories.find_one({"$or": [{"name_ru": name}, {"name_en": name}]})
        if category:
            return TenderCategory(**category)
        else:
            return None

    async def bulk_write_tenders(self, tenders_to_deactivate: list[Tender], tenders_to_upsert: list[Tender]):
        actions = []
        for tender in tenders_to_deactivate:
            actions.append(UpdateOne({"internal_id": tender.internal_id}, {"$set": {"is_active": False}}))
        for tender in tenders_to_upsert:
            actions.append(
                UpdateOne(
                    {"internal_id": tender.internal_id},
                    {"$set": tender.model_dump()},
                    upsert=True
                ))

        await self.db.tenders.bulk_write(actions)

    async def get_all_tenders(self) -> list[Tender]:
        tenders = await self.db.tenders.find().to_list(None)
        return [Tender(**tender) for tender in tenders]

    async def get_tender_by_id(self, tender_id: str) -> Tender | None:
        tender = await self.db.tenders.find_one({"internal_id": tender_id})

        return Tender(**tender) if tender else None

    async def get_all_active_tenders(self) -> list[Tender]:
        tenders = await self.db.tenders.find({"is_active": True}).to_list(None)
        return [Tender(**tender) for tender in tenders]
