import httpx

from settings import settings
from tenders.models import Tender, TenderCategory


class MHPClient:

    def __init__(self):
        self.api_key = settings.MHP_API_KEY
        self.api_url = settings.MHP_API_URL

    def _process_category(
            self,
            data: dict,
            parent: TenderCategory | None,
            categories: list[TenderCategory],
            vector_name: str = "",
    ) -> TenderCategory:
        if vector_name:
            vector_name = f'{vector_name} > {data.get("name_ru", "")} {data.get("name_en", "")}'
        else:
            vector_name = f'{data.get("name_ru", "")} {data.get("name_en", "")}'

        parent_id = parent.id if parent else None

        category_data = {**data, "parent_id": parent_id, "vector_name": vector_name}
        category = TenderCategory(**category_data)

        childs = []
        for child in data.get("childs", []):
            childs.append(self._process_category(child, category, categories, vector_name))

        category.children = childs
        categories.append(category)
        return category

    async def get_categories(self) -> list[TenderCategory]:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                url=f"{self.api_url}/api/v1/external/tenders/categories/tree",
                headers={"X-App-Token": self.api_key},
            )
        if resp.status_code == 200:
            data = resp.json()
            categories: list[TenderCategory] = []
            for category in data["All"]["childs"]:
                self._process_category(category, None, categories)
            return categories
        else:
            raise Exception(f"Can't get categories from MHP API: {resp.text}")

    async def get_active_tenders(self) -> list[Tender]:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                url=f"{self.api_url}/api/v1/external/tenders/list",
                headers={"X-App-Token": self.api_key},
            )
        if resp.status_code == 200:
            data = resp.json()
            tenders: list[Tender] = []
            for tender in data:
                tenders.append(Tender(**tender, is_active=True))
            return tenders
        else:
            raise Exception(f"Can't get tenders from MHP API: {resp.text}")
