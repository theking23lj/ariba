import asyncio

from depends.redis_client import get_redis
from repos.email_user import EmailUserMongoRepository
from repos.tg_user import TgUserMongoRepository
from tenders.mhp_client import MHPClient
from tenders.models import Tender
from tenders.repo import TenderRepository
from chats.email_user_chat import EmailMessageDistributor
from chats.tg_chat import TgMessageDistributor
from broadcast.repo import BroadcastCache

from utils.logger import logger_manager

logger = logger_manager.get_logger()


async def fetch_tenders() -> list[Tender]:
    try:
        fetched_tenders = await MHPClient().get_active_tenders()
        repo = await TenderRepository.get_instance()
        all_tenders = await repo.get_all_tenders()
        fetched_tenders_ids = [t.internal_id for t in fetched_tenders]

        tenders_to_deactivate = [t for t in all_tenders if t.is_active and t.internal_id not in fetched_tenders_ids]

        await repo.bulk_write_tenders(tenders_to_deactivate, fetched_tenders)

    except Exception as e:
        logger.error("Error while fetching tenders", exc_info=e)
        raise e

    return fetched_tenders


async def fetch_tender_categories():
    fetched_categories = await MHPClient().get_categories()
    repo = await TenderRepository.get_instance()
    await repo.bulk_write_categories(fetched_categories)
    return fetched_categories


async def get_and_send_tenders():
    repo = await TenderRepository.get_instance()
    tenders = await repo.get_all_active_tenders()
    redis_client = get_redis()
    cache = BroadcastCache(redis_client)
    email_sender = await EmailMessageDistributor.build(broadcast_cache=cache)
    tg_sender = await TgMessageDistributor.build(broadcast_cache=cache)
    await asyncio.gather(
        email_sender.send_tenders_to_all(tenders),
        tg_sender.send_tenders_to_all(tenders)
    )
    await redis_client.close()


async def fetch_tenders_and_categories():
    tenders, categories = await asyncio.gather(
        fetch_tenders(),
        fetch_tender_categories()
    )
    return tenders, categories


async def clear_watched_tenders():
    repo = await TenderRepository.get_instance()
    tenders = await repo.get_all_active_tenders()
    active_tender_ids = [t.internal_id for t in tenders]
    for repo in (await TgUserMongoRepository.get_instance(), await EmailUserMongoRepository.get_instance()):
        await repo.clear_watched_tenders_for_all(active_tender_ids)