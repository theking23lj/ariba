from depends.redis_client import get_redis
from depends import get_tg_client
from broadcast.repo import BroadcastCache
from repos.tg_user import TgUserMongoRepository
from tenders.repo import TenderRepository
from repos.base import BaseLanguageRepository
from repos.language_converter import language_converter, BaseLang
from utils.logger import logger_manager

logger = logger_manager.get_logger()


async def read_tg_notification_tenders():
    redis_client = get_redis()
    broadcast_cache = BroadcastCache(redis_client)
    user_ids = await broadcast_cache.get_tg_notification_tenders_users_ids()
    tg_client = get_tg_client()
    tender_repo = await TenderRepository.get_instance()
    all_categories = await tender_repo.get_categories()
    all_categories_by_dict = {c.unique_name: c for c in all_categories}
    tg_user_repo = await TgUserMongoRepository.get_instance()
    for user_id in user_ids:
        if not tg_client.can_send_notification_for_user(user_id):
            continue

        user = await tg_user_repo.get_user_by_chat_id(user_id)
        if not user:
            continue

        tender_mes = await broadcast_cache.pop_tg_notification_tender_by_user_id(user_id)
        if not tender_mes:
            continue

        tender = await tender_repo.get_tender_by_id(tender_mes.id)
        if not tender:
            continue

        # Double check subscriptions
        tenders = user.filter_tenders(
            [tender],
            [],
            skip_watched=tender_mes.skip_watched
        )
        if not tenders:
            continue

        language_repo = await BaseLanguageRepository.get_instance()
        language = await language_converter(await language_repo.get_language_or_default(user.chat_id))
        if language == BaseLang.UKRAINIAN:
            await tg_client.send_message(user_id, tender.to_short_ua_message(all_categories_by_dict), html=True)
        else:
            await tg_client.send_message(user_id, tender.to_short_en_message(all_categories_by_dict), html=True)
        await tg_user_repo.add_watched_tenders(user, [tender])
    await redis_client.close()
