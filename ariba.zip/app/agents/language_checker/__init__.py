import re

from agentcore.base import arun
from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, MessageType
from agentcore.roles.basic import BasicRole
from agentcore.config import get_global_config


class LanguageChecker(BasicRole):
    def __init__(self):
        super().__init__(config=get_global_config().copy_with(temperature=0))
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "",
                MessageType.USER: "{text}\n\n",
                MessageType.AGENT: "",
                MessageType.FUNCTION_CALL: "",
                MessageType.FUNCTION_RESULT: "",
            }
        )

    async def check(self, messages: list[AbstractMessage], n_last_messages: int = 7) -> str:
        user_messages = [msg for msg in messages if msg.type == 'user']
        filtered_messages = user_messages[-n_last_messages:]
        formatted_history = self.history_template.format(filtered_messages)
        cleaned_history = re.sub(r'\n\n+', '\n', formatted_history).strip()
        result = await self._check(cleaned_history)
        return result.strip("\"'")

    @arun
    async def _check(self, messages: str) -> str:
        ...
