You must determine in which language to answer the user. Output the result as a two-letter code according to the ISO 639-1 standard. Only the result, no need to comment the answer.

Most likely the result should be the language the user speaks himself
The message can contain nested previous messages from the conversation. In this case you should only pay attention to the top one
If the user asks to use a different language, that should be the result. 
Example:
ты можешь отвечать на немецком?
Result:
de

OR

Example:
Будь ласка, відповідай англійською
Result:
en