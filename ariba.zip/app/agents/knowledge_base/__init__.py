from agentcore.actions import Call
from agentcore.loop import Loop, Continue, Finish
from agentcore.messages import SysMessage, AgentMessage
from agentcore.messages import to_langchain_messages
from langchain.schema import HumanMessage

from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from repos.knowledge_base import KnowledgeBaseRepository
from tools.custom_loop import custom_loop

from settings import settings
import agents.common as common

INTRO =  (common.INTRODUCTION + """

While answering user's questions, {name} uses the knowledge base, which is a collection of information about SAP Ariba and MHP
If {name} can't find the answer in the knowledge base, she asks the Admin for help.
When Admin provides the answer, the knowledge base should be updated with the new information, so that {name} can use it in the future.
You will be provided with the conversation between {name} and Admin. There is no way to contact {name} or Admin
You are responsible for the process of updating the knowledge base with the information from the conversation. 
This information may include but is not limited to: change in terminology, new procedures, new UI elements, updated contacts, etc.
Note that terms and names from the knowledge base can be used in a different language in the conversation
Also, you should pay attention to the structure of the knowledge base. Some sections may reference information from the others, but it should be avoided to not to clutter the knowledge base.
Remember! You shouldn't have a conversation - your task is to update the knowledge base.
""").format(name=settings.BOT_NAME)

class KnowledgeBaseLoop(Loop):
    call_function_message = SysMessage("Remember that you must only advise to perform an action from the provided list")

    def __init__(self, kbr: KnowledgeBaseRepository):
        super().__init__(max_iterations=20, escape_func=self.escape_func_f)
        self.adviser_inter_steps = []
        self.updater_inter_steps = []
        self.kbr = kbr

    async def escape_func_f(self) -> str | None:
        # if the loop exceeds max_iterations, just finish it
        ...

    @custom_loop()
    async def go(self, conversation: str):
        #TODO this code will duplicate a message if Updater generates text
        if self.inter_steps:
            self.adviser_inter_steps.append(self.inter_steps[-1])
            self.updater_inter_steps.append(self.inter_steps[-1])

        titles = "\n".join(await self.kbr.get_section_titles())
        adviser = get_roles_mgr().get_role(RoleNames.KB_ADVISER)
        advice = await adviser.advice(
            INTRO, titles, [HumanMessage(content=conversation)] + to_langchain_messages(self.adviser_inter_steps)
        )
        self.adviser_inter_steps.append(AgentMessage(advice))
        self.updater_inter_steps.append(SysMessage(advice))

        updater = get_roles_mgr().get_role(RoleNames.KB_UPDATER, self.kbr)
        action = await updater.plan(
            INTRO, titles, [HumanMessage(content=conversation)] + to_langchain_messages(self.updater_inter_steps)
        )

        if isinstance(action, Finish) or (isinstance(action, Call) and action.text):
            self.inter_steps.append(self.call_function_message)
            return Continue(self.call_function_message)
        else:
            self.adviser_inter_steps.append(action.message)
            self.updater_inter_steps.append(action.message)
            return action

    def clear(self):
        self.kbr = None
        self.adviser_inter_steps.clear()
        self.updater_inter_steps.clear()
        self.inter_steps.clear()
        self.escape_func = None