import re
from repos.knowledge_base import KnowledgeBaseRepository
from langchain.schema import BaseMessage
from agentcore.base import  aplan, Function
from agentcore.loop import Break
from agentcore.roles.conversational import Conversational
from agentcore.config import get_global_config
from pydantic import BaseModel, Field

class Section(BaseModel):
    title: str = Field(..., alias='_id')
    content: str

class Sections(BaseModel):
    sections: list[Section]

REMINDER = "Note that terms and names from the knowledge base can be used in Ukrainian or Russian in the conversation"

class Updater(Conversational):
    def __init__(self, kbr: KnowledgeBaseRepository):
        functions = [Function.from_func(f) for f in [self.read, self.create, self.replace, self.update_title, self.search, self.delete]]
        stop_functions = [Function.from_func(f, after=self.after) for f in [self.stop_update, self.finish]]
        super().__init__(config=get_global_config().copy_with(temperature=0.1), functions=functions + stop_functions)
        self.kbr = kbr

    async def read(self, title: str):
        """Read the section's content"""
        s = await self.kbr.get_section(title)
        if s is None:
            return "Section not found. " + REMINDER
        return s
    
    async def create(self, title: str, content: str):
        """Create a new section. Don't forget to escape special characters in the content"""
        s = await self.kbr.get_section(title)
        if s is not None:
            return "The section with this title already exists"
        await self.kbr.save_section(title, content)
        return "Section created"

    async def replace(self, title: str, find: str, replace: str):
        """Perform a find and replace operation on the section content. Don't forget to escape special characters in the parameters"""
        s = await self.kbr.get_section(title)
        if s is None:
            return "Section not found. " + REMINDER
        if find not in s:
            return "The find string is not in the section content. " + REMINDER
        new_content = re.sub(re.escape(find), replace, s, flags=re.IGNORECASE)
        await self.kbr.update_section(title, new_content)
        return "Section updated. New content: \n" + new_content

    async def search(self, string: str):
        """Search for a string in the knowledge base"""
        raw_sections = await self.kbr.collection.find({"$or": [{"content": {"$regex": string, "$options": "i"}}, {"_id": {"$regex": string, "$options": "i"}}]}).to_list(100)
        sections=Sections(sections = [Section(**s) for s in raw_sections])
        if sections.sections:
            # return yaml.dump(sections.model_dump(), allow_unicode=True)
            return "The following sections contain the string:\n" + "\n".join([s.title for s in sections.sections])
        else:
            return "String not found. " + REMINDER
    
    async def update_title(self, title: str, new_title: str):
        """Update the title of a section"""
        s = await self.kbr.get_section(title)
        if s is None:
            return "Section not found. " + REMINDER
        await self.kbr.delete_section(title)
        await self.kbr.save_section(new_title, s)
        return "Section title updated to " + new_title

    async def delete(self, title: str):
        """Delete the section"""
        s = await self.kbr.get_section(title)
        if s is None:
            return "Section not found. " + REMINDER
        await self.kbr.delete_section(title)
        return "Section deleted"
    
    def after(self, *args, **kwargs):
        return Break()

    async def finish(self):
        """Call this function when you are finished with the task"""
        return "Finished"
    
    async def stop_update(self):
        """Call this function if the update process should be stopped. For example if the information provided by the Admin is irrelevant"""
        return "Finished"

    @aplan
    async def plan(self, intro, titles, history: list[BaseMessage]):
        ...