from langchain.schema import BaseMessage, HumanMessage
from agentcore.base import  arun
from agentcore.roles.conversational import Conversational
from agentcore.config import get_global_config

class Adviser(Conversational):
    def __init__(self):
        super().__init__(config=get_global_config().copy_with(temperature=0.1))

    @arun
    async def advice(self, intro, titles, history: list[BaseMessage]):
        ...