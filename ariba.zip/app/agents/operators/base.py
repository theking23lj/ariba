from abc import abstractmethod
from pydantic.v1 import create_model
from agentcore.function import Function

from tenders.models import TenderCategory
from agentcore.actions import Action
from agentcore.messages import AbstractMessage
from agentcore.roles.conversational import Conversational

from providers.base.models import BaseMHPMessage


OPERATOR_TEMPERATURE = 0.5

class BaseOperator(Conversational):
    @abstractmethod
    async def plan(
        self,
        user_id: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
        advice: str | None,
    ) -> Action: ...

    @abstractmethod
    async def run(
        self,
        user_id: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
        advice: str | None,
    ) -> str | None: ...


def format_tender_categories(categories: list[TenderCategory] | None) -> str:
    if not categories:
        return "[]"
    categories_str = ""
    for c in categories:
        children_len = len(c.children) if c.children else 0
        categories_str += "* " + c.get_name() + f"    ({children_len} subcategories)\n"
    return categories_str


async def ask_manager(question: str, context: str, admin_chats_register, **__):
    """Ask the manager a question. Provide your question and the context in Ukrainian"""
    admin_chats_register.append(question=question, context=context)
    return "The message has been sent to the manager/admin."\
        "They will respond to your question shortly and you will answer the user. "\
        "Meanwhile keep the conversation going, but notify the user "\
        "that you are waiting the response from the manager/admin"

async def show_top_level_categories(tender_repo, **__):
    """Show a list of all the top level tender categories in the hierarchy."""
    tender_categories = await tender_repo.get_top_level_categories()
    return (f"Top level categories are:\n {format_tender_categories(tender_categories)}\n"
            "Don't list all the categories to the user, rather ask them questions to determine which category is suitable for their products/services")

async def show_subcategories(category: str, tender_repo, **__):
    """Show all the subcategories of the specified tender category."""
    tender_category = await tender_repo.find_category(category)
    if tender_category:
        return f"Subcategories of {category} are:\n {format_tender_categories(tender_category.children)}"
    else:
        return f"Category {category} is not found"

@staticmethod
async def category_search(search: str, tender_repo, **__):
    """Show a list of the tender categories by query."""
    tender_categories = await tender_repo.vector_search_categories(search)
    return (f"Found categories:\n {format_tender_categories(tender_categories)}\n"
            "Don't list all the categories to the user, rather ask them questions to determine which category is suitable for their products/services")

async def subscribe(category: str, tender_repo, user_chat, **__):
    """Subscribe the user to the tenders newsletter. Specify one category only.
    Only use it if you are sure you've found the most specific category for the user's product/service"""
    tender_category = await tender_repo.find_category(category)
    if tender_category:
        await user_chat.repo.add_chosen_category(
            user_chat.user, tender_category
        )
        return f"The user has been subscribed to {category}"
    else:
        tender_categories = await tender_repo.get_top_level_categories()
        return (f"Category {category} is not found."
                "Here is the list of top level categories:\n"
                f"{format_tender_categories(tender_categories)}")

async def unsubscribe(category: str, tender_repo, user_chat, **__):
    """Unsubscribe the user from the tenders newsletter for one category. Specify one category only"""
    tender_category = await tender_repo.find_category(category)
    if tender_category:
        await user_chat.repo.delete_chosen_category(
            user_chat.user, tender_category
        )
        return f"The user has been unsubscribed from {category}"
    else:
        return f"Category {category} is not found"

async def unsubscribe_from_all(user_chat, **__):
    """Unsubscribe the user from the tenders newsletter for ALL categories. Use it only if you are sure of it"""
    await user_chat.repo.clear_chosen_categories(
        user_chat.user
    )
    return "The user has been unsubscribed from all categories"

async def subscribe_all(**__):
    """Subscribe the user to the tenders newsletter for ALL categories. Use it only if you are sure of it"""
    return "Users are not able to subscribe to all categories"

async def show_subscribed_categories(tender_repo, user_chat, **__):
    """Show all the categories the user is currently subscribed to"""
    categories = await tender_repo.get_categories_by_unique_names(
        user_chat.user.chosen_category_ids
    )
    return f"The user is subscribed to: {[c.get_name() for c in categories]}"

async def search_knowledge_base(title: str, knowledge_base, **__) -> str:
    """Search the knowledge base for the specific title"""
    return await knowledge_base.read(title)

operator_functions = [
    Function.from_func(
        ask_manager,
        args_schema=create_model(
            "ask_manager_schema",
            question=(str, ...),
            context=(str, ...)
        )
    ),
    Function.from_func(
        show_top_level_categories,
        args_schema=create_model(
            "show_top_level_categories_schema",
        )
    ),
    Function.from_func(
        show_subcategories,
        args_schema=create_model(
            "show_subcategories_schema",
            category=(str, ...)
        )
    ),
    Function.from_func(
        category_search,
        args_schema=create_model(
            "category_search",
            search=(str, ...)
        )
    ),
    Function.from_func(
        subscribe,
        args_schema=create_model(
            "subscribe_schema",
            category=(str, ...)
        )
    ),
    Function.from_func(
        unsubscribe,
        args_schema=create_model(
            "unsubscribe_schema",
            category=(str, ...)
        )
    ),
    Function.from_func(
        unsubscribe_from_all,
        args_schema=create_model(
            "unsubscribe_from_all_schema",
        )
    ),
    Function.from_func(
        subscribe_all,
        args_schema=create_model(
            "subscribe_all_schema",
        )
    ),
    Function.from_func(
        show_subscribed_categories,
        args_schema=create_model(
            "show_subscribed_categories_schema",
        )
    ),
    Function.from_func(
        search_knowledge_base,
        args_schema=create_model(
            "search_knowledge_base_schema",
            title=(str, ...)
        )
    ),
]
