from agentcore.actions import Action
from agentcore.base import aplan, arun
from agentcore.config import get_global_config
from agentcore.messages import AbstractMessage, to_langchain_messages, SysMessage
from langchain.schema import BaseMessage

from providers.base.models import BaseMHPMessage
from settings import settings
from utils.logger import logger_manager
from agents.operators.base import OPERATOR_TEMPERATURE, BaseOperator, operator_functions
import agents.common as common

logger = logger_manager.get_logger()


class Operator(BaseOperator):
    def __init__(
        self,
        bind_functions: bool = True
    ):
        if bind_functions:
            functions = operator_functions
        else:
            functions = []

        super().__init__(
            functions=functions,
            config=get_global_config().copy_with(temperature=OPERATOR_TEMPERATURE),
        )

    async def plan(self, user_id: str, history: list[AbstractMessage], events: list[BaseMHPMessage], inter_steps: list[AbstractMessage], advice: str | None) -> Action:
        '''events parameter is ignored. All the events must be included in the history.'''
        full_history = history + inter_steps
        if advice:
            full_history.append(SysMessage(advice))

        return await self._plan(settings.BOT_NAME, common.RULES, to_langchain_messages(full_history))

    @aplan
    async def _plan(self, name: str, rules: str, history: list[BaseMessage]) -> Action:
        ...

    async def run(
        self,
        user_id: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
        advice: str | None,
    ) -> str | None:
        '''events parameter is ignored. All the events must be included in the history.'''
        full_history = history + inter_steps
        if advice:
            full_history.append(SysMessage(advice))

        return await self._run(settings.BOT_NAME, common.RULES, to_langchain_messages(full_history)) # type: ignore

    @arun
    async def _run(self, name: str, rules: str, history: list[BaseMessage]) -> str | None:
        ...
