from agentcore.base import arun
from agentcore.config import get_global_config
from agentcore.messages import AbstractMessage, AgentMessage, to_langchain_messages, from_langchain_messages, SysMessage
from agentcore.roles.conversational import Conversational
from langchain.schema import BaseMessage
from langchain.prompts import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    MessagesPlaceholder,
)

from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from providers.base.models import BaseMHPMessage
from settings import settings
from utils.logger import logger_manager
import agents.common as common

logger = logger_manager.get_logger()

EDITING_TASK = """
Now, look at your last message. It's not sent yet, so you can change it. 
There is some information, that is not mentioned in the knowledge base or the conversation:
{data}

Please double-check your last message to make sure it only contains reliable information. Edit it before sending.
Remember that you can only use terms and names that have already been mentioned in the conversation
"""

class Editor(Conversational):
    def __init__(
        self,
    ):
        super().__init__(
            config=get_global_config().copy_with(temperature=0.5),
        )
        self.prompt_template = ChatPromptTemplate.from_messages(
            [
                MessagesPlaceholder(variable_name=self.HISTORY),
                SystemMessagePromptTemplate.from_template(template="You {language_advice}" + EDITING_TASK)
            ]
        )
 
    async def edit_data_in_reply(self, language_advice: str, prev_messages: list[AbstractMessage], events: list[BaseMHPMessage], reply: str) -> str:
        operator = get_roles_mgr().get_role(RoleNames.OPERATOR_MAIN, bind_functions=False)
        messages_and_events =  prev_messages
        if events:
            events_formatted = common.format_events(events)
            messages_and_events = prev_messages + [SysMessage(events_formatted)]
        operator_prompt = from_langchain_messages(
            operator.prompt_template.format_messages(
                name=settings.BOT_NAME, rules=common.RULES, history=to_langchain_messages(messages_and_events)
            )
        )

        data_extractor = get_roles_mgr().get_role(RoleNames.DATA_EXTRACTOR)
        data = await data_extractor.extract_data(reply)
        if data.data_items:
            data_checker = get_roles_mgr().get_role(RoleNames.DATA_CHECKER)
            checked_data = await data_checker.check_data(operator_prompt, data)
            unreliable_data = list(filter(lambda item: not item.is_present, checked_data.data_items))

            if unreliable_data:
                unreliable_data_str = "* " + "\n* ".join([f"{item.data} ({item.type})" for item in unreliable_data])
                full_history = operator_prompt + [AgentMessage(reply)]

                return await self._edit(settings.BOT_NAME, common.RULES, language_advice, to_langchain_messages(full_history), unreliable_data_str) # type: ignore

        return reply

    @arun
    async def _edit(self, name: str, rules: str, language_advice: str, history: list[BaseMessage], data: str) -> str:
        ...