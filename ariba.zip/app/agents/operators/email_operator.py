from langchain.schema import BaseMessage, SystemMessage
from langchain.prompts import SystemMessagePromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from agentcore.actions import Action
from agentcore.base import aplan, arun
from agentcore.config import get_global_config
from agentcore.messages import AbstractMessage, to_langchain_messages

from settings import settings
from agents.operators.base import OPERATOR_TEMPERATURE, BaseOperator, operator_functions
from utils.logger import logger_manager
import agents.common as common
from providers.base.models import BaseMHPMessage

logger = logger_manager.get_logger()

class EmailOperator(BaseOperator):
    def __init__(
        self,
        bind_functions: bool = True
    ):
        if bind_functions:
            functions = operator_functions
        else:
            functions = []

        super().__init__(
            functions=functions,
            config=get_global_config().copy_with(temperature=OPERATOR_TEMPERATURE),
        )
        system = self.get_local_file("system.md")
        self.prompt_template = ChatPromptTemplate.from_messages(
            [
                SystemMessagePromptTemplate.from_template(template=system),
                MessagesPlaceholder(variable_name="context"),
                MessagesPlaceholder(variable_name=self.HISTORY),
                MessagesPlaceholder(variable_name="events"),
                MessagesPlaceholder(variable_name="inter_steps"),
                MessagesPlaceholder(variable_name="commands"),
            ]
        )

    async def plan(
        self,
        user_id: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
        advice: str | None,
    ) -> Action:
        commands = [SystemMessage(content=advice)] if advice else []
        events_formatted = common.format_events(events)

        return await self._plan(
            name=settings.BOT_NAME,
            rules=common.RULES,
            context=[SystemMessage(content=common.format_email_context("you", user_id, history[-1]))] if history else [],
            history=to_langchain_messages(history),
            events=[SystemMessage(content=events_formatted)],
            inter_steps=to_langchain_messages(inter_steps),
            commands=commands,
        )

    @aplan
    async def _plan(
        self,
        name: str,
        rules: str,
        context: list[SystemMessage],
        history: list[BaseMessage],
        events: list[BaseMessage],
        inter_steps: list[BaseMessage],
        commands: list[SystemMessage],
    ) -> Action: ...

    async def run(
        self,
        user_id: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
        advice: str | None,
    ) -> str | None:
        commands = [SystemMessage(content=advice)] if advice else []
        events_formatted = common.format_events(events)

        return await self._run(
            name=settings.BOT_NAME,
            rules=common.RULES,
            context=[SystemMessage(content=common.format_email_context("you", user_id, history[-1]))] if history else [],
            history=to_langchain_messages(history),
            events=[SystemMessage(content=events_formatted)],
            inter_steps=to_langchain_messages(inter_steps),
            commands=commands)  # type: ignore

    @arun
    async def _run(
        self,
        name: str,
        rules: str,
        context: list[SystemMessage],
        history: list[BaseMessage],
        events: list[BaseMessage],
        inter_steps: list[BaseMessage],
        commands: list[SystemMessage],
    ) -> str | None: ...
