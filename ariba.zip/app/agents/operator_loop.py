from enum import StrEnum
from agentcore.actions import Call
from agentcore.loop import Loop
from agentcore.messages import (
    AbstractMessage,
)
from agentcore.plugins.knowledge_base import KnowledgeBase

from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from agents.advisers.base import BaseAdviser
from agents.operators.base import BaseOperator
from chats.base import BaseUserChat
from chats.email_admin_chat import AdminChatsRegister
from tenders.repo import TenderRepository
from tools.custom_loop import custom_loop

class OLMode(StrEnum):
    WITH_ADVISER = "WITH_ADVISER"
    NO_ADVISER = "NO_ADVISER"

class OperatorLoop(Loop):
    def __init__(
        self,
        start_mode: OLMode,
        language_advice: str,
        user_chat: BaseUserChat,
        admin_chats_register: AdminChatsRegister,
        adviser: BaseAdviser,
        operator: BaseOperator,
        operator_main: BaseOperator,
        tender_repo: TenderRepository,
        knowledge_base: KnowledgeBase,
    ):
        super().__init__(escape_func=self.escape_func_f)
        self.language_advice = language_advice
        self.user_chat = user_chat
        self.admin_chats_register = admin_chats_register
        self.adviser = adviser
        self.operator = operator
        self.operator_main = operator_main
        self.tender_repo = tender_repo
        self.knowledge_base = knowledge_base

        # The first of Lazy creating the Operator
        get_roles_mgr().get_role(RoleNames.EMAIL_OPERATOR_OL)

        self.messages_to_manager: list[AbstractMessage] = []
        self.mode = start_mode

    async def escape_func_f(self) -> str | None:
        return await self.operator_main.run(
            user_id=self.user_chat.user.chat_id,
            history=self.user_chat.history,
            events=self.user_chat.events,
            inter_steps=self.inter_steps,
            advice=f"You {self.language_advice}"
        )

    @custom_loop(loop_kwargs_names=['admin_chats_register', 'tender_repo', 'user_chat', 'knowledge_base'])
    async def reply(self) -> str | None:
        advice = ""
        if self.mode == OLMode.WITH_ADVISER:
            advice = await self.adviser.advise(
                knowledge_base_titles = await self.knowledge_base.titles,
                user_id = self.user_chat.user.chat_id,
                language_advice = self.language_advice,
                history = self.user_chat.history,
                events = self.user_chat.events,
                inter_steps = self.inter_steps,
            )

        action = await self.operator.plan(
            user_id=self.user_chat.user.chat_id,
            history=self.user_chat.history,
            events=self.user_chat.events,
            inter_steps=self.inter_steps,
            advice= f"You {self.language_advice}\n\n{advice}"
        )

        self.mode = OLMode.WITH_ADVISER

        if isinstance(action, Call):
            if action.function.name == "ask_manager":
                self.messages_to_manager.append(action.message)

            elif action.function.name in ["show_top_level_categories", "show_subcategories"]:
                self.mode = OLMode.NO_ADVISER

        return action

    def clear(self):
        self.user_chat = None
        self.tender_repo = None
        self.knowledge_base = None
        self.admin_chats_register = None
        self.inter_steps.clear()
        # clear ref

        self.escape_func = None
