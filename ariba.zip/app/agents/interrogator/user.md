Conversation between {name} and the user delimited by triple quotes:
"""
{bot_user_messages}
"""

Conversation between {name} and the admin delimited by triple quotes:
"""
{bot_admin_messages}
""

Now write new question to the admin