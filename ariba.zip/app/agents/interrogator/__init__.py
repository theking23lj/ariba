from agentcore.base import arun
from agentcore.history_template import HistoryTemplate
from agentcore.messages import MessageType, AbstractMessage
from agentcore.roles.basic import BasicRole

from settings import settings


class Interrogator(BasicRole):
    def __init__(self):
        super().__init__()
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: settings.BOT_NAME + ":\n{text}",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )

    async def interrogate(self, bot_user_messages: list[AbstractMessage], bot_admin_messages: list[AbstractMessage]) -> str:
        bot_user_messages = self.history_template.format(bot_user_messages)
        bot_admin_messages = self.history_template.format(bot_admin_messages)
        return await self._interrogate(settings.BOT_NAME, bot_user_messages, bot_admin_messages)

    @arun
    async def _interrogate(self, name: str, bot_user_messages: str, bot_admin_messages: str) -> str:
        ...