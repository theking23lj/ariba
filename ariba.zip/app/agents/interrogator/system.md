You have access to the recent correspondence between {name} and a user and the communication between {name} and the admin. It appears that the admin's response didn't completely address {name}'s inquiry.

Formulate a new question directed towards the admin. This question should fill in the missing information and provide {name} with a complete understanding of the subject. 

Be concise. Only write the new question. Don't apologize, don't ask permission, don't say please, don't say "Admin,", etc.