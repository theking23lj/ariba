from agentcore.config import get_global_config
from agentcore.function import Function
from agentcore.roles.basic import BasicRole
from langchain.output_parsers.openai_functions import PydanticOutputFunctionsParser
from langchain.pydantic_v1 import BaseModel
from langsmith import traceable

from settings import settings
import agents.common as common
from utils.logger import logger_manager

logger = logger_manager.get_logger()


class DataItem(BaseModel):
    data: str
    type: str


class DataExtractorOutput(BaseModel):
    data_items: list[DataItem]


class DataExtractor(BasicRole):
    def __init__(self):
        super().__init__(
            config=get_global_config().copy_with(temperature=0.1),
            functions=[Function.from_func(self.output)],
        )

    # The function can't really be called. It's used just to define the output schema
    async def output(self, data_items: list[DataItem]):
        """Output the extracted data"""
        ...

    @traceable(name='DataExtractor.extract_data')
    async def extract_data(self, reply: str) -> DataExtractorOutput:
        messages = self.prompt_template.format_messages(
            name=settings.BOT_NAME, introduction = common.INTRODUCTION, reply=reply
        )
        # TODO handle invalid output
        chain = self.llm.bind(function_call={"name": self.output.__name__}) | PydanticOutputFunctionsParser(pydantic_schema=DataExtractorOutput)
        return await chain.ainvoke(messages)
