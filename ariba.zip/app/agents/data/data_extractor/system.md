There is an ongoing conversation between the User and {name}. {introduction}

{name} is about to send a reply:
"""
{reply}
"""

Now, your task is to look carefully at {name}'s reply and identify every data item: names, phone numbers, addresses, links, emails, etc. Also, decide what type of information each data item is. Output an empty list, if there is no data