import yaml
from agentcore.config import get_global_config
from agentcore.roles.basic import BasicRole
from agentcore.messages import AbstractMessage, MessageType
from agentcore.history_template import HistoryTemplate
from agentcore.function import Function
from langchain.schema import SystemMessage
from langchain.pydantic_v1 import BaseModel
from langchain.output_parsers.openai_functions import PydanticOutputFunctionsParser
from agents.data.data_extractor import DataExtractorOutput
from agents import common
from settings import settings
from langsmith import traceable
from providers.base.models import BaseMHPMessage
from utils.logger import logger_manager

logger = logger_manager.get_logger()


class DataItem(BaseModel):
    data: str
    type: str
    is_present: bool

class DataCheckerOutput(BaseModel):
    data_items: list[DataItem]

class DataChecker(BasicRole):
    def __init__(self, *_, **__):
        super().__init__(config=get_global_config().copy_with(temperature=0.1), functions=[Function.from_func(self.output)])
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: settings.BOT_NAME + ":\n{text}",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )

    # The function can't really be called. It's used just to define the output schema
    async def output(self, data_items: list[DataItem]):
        """Output the result"""
        ...

    @traceable(name='DataChecker.check_data')
    async def check_data(self, prev_messages: list[AbstractMessage], data: DataExtractorOutput) -> DataCheckerOutput:
        prev_messages_str = self.history_template.format(prev_messages)
        # Filter out those data items that are present verbatim in the previous messages
        filtered_data_items = [d for d in data.data_items if d.data not in prev_messages_str]
        if filtered_data_items:
            data_to_check = DataExtractorOutput(data_items=filtered_data_items)
            messages = self.prompt_template.format_messages(
                name=settings.BOT_NAME, prev_messages=prev_messages_str,
                data=yaml.dump(data_to_check.dict(), allow_unicode=True)
            )
            # TODO handle invalid output 
            chain = self.llm.bind(function_call={"name": self.output.__name__}) | PydanticOutputFunctionsParser(pydantic_schema=DataCheckerOutput)
            return await chain.ainvoke(messages)
        return DataCheckerOutput(data_items=[DataItem(data=d.data, type=d.type, is_present=True) for d in data.data_items])
