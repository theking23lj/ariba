You are provided with data items (words, phrases, terms, names, numbers, symbols, etc.)
{data}

You are also provided with the Text delimited by triple quotes

Your task is to decide for each data item whether it's present in the Text. The data item may be present in the Text verbatim or in a modified form or in another language