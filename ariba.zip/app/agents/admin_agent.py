from agentcore.messages import AgentMessage, MessageType
from agentcore.history_template import HistoryTemplate
from agents.knowledge_base import KnowledgeBaseLoop
from repos.knowledge_base import KnowledgeBaseRepository
from langsmith import traceable
from pydantic import BaseModel
from settings import settings

from chats.email_admin_chat import EmailAdminChat


class AdminAgent(BaseModel):
    admin_chat: EmailAdminChat
    knowledge_base_repo: KnowledgeBaseRepository

    @traceable(name="AdminAgent.answer")
    async def answer(self) -> None:
        history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "Admin:\n{text}",
                MessageType.AGENT: settings.BOT_NAME + ":\n{text}",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )
        conversation = history_template.format(self.admin_chat.history)
        kb_loop = KnowledgeBaseLoop(self.knowledge_base_repo)
        await kb_loop.go(conversation)
        self.admin_chat.append(AgentMessage("Дякую за відповідь!"))
        await self.admin_chat.commit()
        await self.admin_chat.close_thread()
        kb_loop.clear()

    class Config:
        arbitrary_types_allowed = True
