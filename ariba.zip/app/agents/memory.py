from typing import Self

from agentcore.plugins.memory import SummaryMemory
from agentcore.providers.messages import BaseProviderMessage

from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from repos.base import BaseUserRepository
from settings import settings


class MHPSummaryMemory(SummaryMemory):
    repo: BaseUserRepository

    async def _save_message(self, message: BaseProviderMessage):
        await self.repo.save_message(message)

    async def _mark_messages_as_summarized(self, messages: list[BaseProviderMessage]) -> None:
        await self.repo.mark_messages_as_summarized([m.db_msg_id for m in messages])

    async def _update_summary(self, chat_id: str, summary: str) -> None:
        await self.repo.update_summary(chat_id, summary)

    @classmethod
    async def build(cls, repo: BaseUserRepository, chat_id: str) -> Self:
        history = await repo.get_history(chat_id)
        summary = await repo.get_summary(chat_id)
        return cls(
            repo=repo,
            prev_messages=history,
            current_summary=summary,
            summarizer=get_roles_mgr().get_role(RoleNames.MESSAGE_SUMMARIZER, settings.BOT_NAME),
        )

    async def load_new_history(self, chat_id: str):
        self.prev_messages = await self.repo.get_history(chat_id)
        self.current_summary = await self.repo.get_summary(chat_id)

    def clear(self):
        self.prev_messages.clear()
        self.current_messages.clear()