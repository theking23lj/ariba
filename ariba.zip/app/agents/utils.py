import asyncio
from contextlib import contextmanager
from enum import Enum


@contextmanager
def suppress_asyncio_cancel():
    try:
        yield
    except asyncio.CancelledError:
        # Catch the CancelledError, so we don't cancel the task on commit.
        pass


class RoleNames(Enum):
    KNOWLEDGE_BASE = "KNOWLEDGE_BASE"
    ADVISER = "ADVISER"
    EMAIL_ADVISER = "EMAIL_ADVISER"
    OPERATOR_MAIN = "OPERATOR_MAIN"
    OPERATOR_OL = "OPERATOR_OL"
    EMAIL_OPERATOR_OL = "EMAIL_OPERATOR_OL"
    EMAIL_OPERATOR_MAIN = "EMAIL_OPERATOR_MAIN"
    EDITOR = "EDITOR"
    EMAIL_HUMANIZER = "EMAIL_HUMANIZER"
    HUMANIZER = "HUMANIZER"
    EMAIL_CRITIC = "EMAIL_CRITIC"
    CRITIC = "CRITIC"
    MESSAGE_SUMMARIZER = "MESSAGE_SUMMARIZER"
    DATA_CHECKER = "DATA_CHECKER"
    DATA_EXTRACTOR = "DATA_EXTRACTOR"
    KB_ADVISER = "KB_ADVISER"
    KB_UPDATER = "KB_UPDATER"
    LANGUAGE_CHECKER = "LANGUAGE_CHECKER"
