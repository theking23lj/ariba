from langchain.schema import BaseMessage, SystemMessage
from langchain.prompts import SystemMessagePromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from agentcore.base import arun
from agentcore.messages import AbstractMessage, to_langchain_messages, MessageType
from agentcore.config import get_global_config
from agentcore.history_template import HistoryTemplate

from .base import BaseAdviser
import agents.common as common
from providers.base.models import BaseMHPMessage
from settings import settings

class EmailAdviser(BaseAdviser):
    def __init__(self):
        super().__init__(
            config=get_global_config().copy_with(temperature=0),
        )
        self.inter_steps_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "",
                MessageType.USER: "",
                MessageType.AGENT: "",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )
        system = self.get_local_file("system.md")
        self.prompt_template = ChatPromptTemplate.from_messages(
            [
                SystemMessagePromptTemplate.from_template(template=system),
                MessagesPlaceholder(variable_name="context"),
                MessagesPlaceholder(variable_name="history"),
                MessagesPlaceholder(variable_name="events"),
                MessagesPlaceholder(variable_name="inter_steps_formatted"),
                SystemMessagePromptTemplate.from_template(template="{name} {language_advice}\n" + common.ADVISER_TASK)
            ]
        )

    async def advise(
        self,
        knowledge_base_titles: list[str],
        user_id: str,
        language_advice: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
    ) -> str:
        inter_steps_formatted = []
        if inter_steps:
            inter_steps_formatted.append(SystemMessage(content = f"Actions {settings.BOT_NAME} has already performed:\n" + self.inter_steps_template.format(inter_steps)))

        events_formatted = common.format_events(events)

        result = await self._advise(
            name = settings.BOT_NAME,
            introduction = common.INTRODUCTION,
            knowledge_base_titles = knowledge_base_titles,
            language_advice = language_advice,
            events = [SystemMessage(content=events_formatted)],
            context=[SystemMessage(content=common.format_email_context(settings.BOT_NAME, user_id, history[-1]))] if history else [],
            history = to_langchain_messages(history),
            inter_steps_formatted = inter_steps_formatted,
        )
        return result + "\nRemember to execute all actions before providing the answer"

    @arun
    async def _advise(
        self,
        name: str,
        introduction: str,
        knowledge_base_titles: list[str],
        language_advice: str,
        events: list[BaseMessage],
        context: list[BaseMessage],
        history: list[BaseMessage],
        inter_steps_formatted: list[BaseMessage],
    ) -> str: ...
