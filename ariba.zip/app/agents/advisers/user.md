These are the last messages in the ongoing conversation between {name} and the user:
"""
{agent_messages}
"""

{name} {language_advice}
Now talk as if you talk directly to {name}. First, if you see any problems in the latest messages, in one sentence point them out and provide a hint on how to solve them. Then if you believe that one of the search procedures should be performed, suggest doing it. To suggest the knowledge base search procedure you must consider only the last message from the user. 

If the KNOWLEDGE BASE SEARCH PROCEDURE should be executed, give the title of a single section from the knowledge base like so:
{name}, search the knowledge base for title: "{{TITLE}}"
