from agentcore.base import arun
from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, MessageType
from agentcore.config import get_global_config

import agents.common as common
from providers.base.models import BaseMHPMessage
from .base import BaseAdviser
from settings import settings

N_LAST_MESSAGES = 7


class Adviser(BaseAdviser):
    def __init__(self):
        super().__init__(
            config=get_global_config().copy_with(temperature=0),
        )
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: settings.BOT_NAME + ":\n{text}",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )

    async def advise(
        self,
        knowledge_base_titles: list[str],
        user_id: str,
        language_advice: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
    ) -> str:
        filtered_messages = history[-N_LAST_MESSAGES:] + inter_steps
        result = await self._advise(
            settings.BOT_NAME,
            common.INTRODUCTION,
            knowledge_base_titles,
            language_advice,
            self.history_template.format(filtered_messages)
        )
        return result + " Remember to execute all actions before providing the answer."

    @arun
    async def _advise(self, name: str, introduction: str, knowledge_base_titles: list[str], language_advice: str, agent_messages: str) -> str:
        ...
