from abc import abstractmethod
from agentcore.messages import AbstractMessage
from agentcore.roles.basic import BasicRole

from providers.base.models import BaseMHPMessage

class BaseAdviser(BasicRole):
    @abstractmethod
    async def advise(
        self,
        knowledge_base_titles: list[str],
        user_id: str,
        language_advice: str,
        history: list[AbstractMessage],
        events: list[BaseMHPMessage],
        inter_steps: list[AbstractMessage],
    ) -> str: ...
