import re

from agentcore.messages import AgentMessage
from agentcore.plugins.knowledge_base import KnowledgeBase
from langsmith import traceable
from pydantic import BaseModel

from agents.operator_loop import OperatorLoop, OLMode
from agents.roles_manager import get_roles_mgr
from agents.utils import suppress_asyncio_cancel, RoleNames
from chats.email_user_chat import EmailUserChat
from chats.base import BaseUserChat
from chats.email_admin_chat import AdminChatsRegister
from tenders.repo import TenderRepository
from repos.base import BaseLanguageRepository
from repos.language_converter import language_converter, BaseLang


class MainAgent(BaseModel):
    user_chat: BaseUserChat
    knowledge_base: KnowledgeBase
    tender_repo: TenderRepository
    language_repo: BaseLanguageRepository
    advice_uk_speak: str = ("should answer the user in Ukrainian and "
                            "use the respectful form of 'you' - 'Ви', starting with a capital letter. "
                            "The names of tender categories also need to be translated into the user's language.")
    advice_en_speak: str = "should answer the user in English. The names of tender categories also need to be translated into the user's language."

    async def _run_ol_with_mode(self, mode: OLMode) -> str | None:
        repo = await AdminChatsRegister.get_repo()
        admin_chats_register = AdminChatsRegister(repo=repo, user_chat=self.user_chat)

        language_checker = get_roles_mgr().get_role(RoleNames.LANGUAGE_CHECKER)

        language_checker_reply = BaseLang.UKRAINIAN
        match self.user_chat:
            case EmailUserChat():
                if self.user_chat.unique_history_messages:
                    language_checker_reply = await language_checker.check(self.user_chat.unique_history_messages)
                adviser = get_roles_mgr().get_role(RoleNames.EMAIL_ADVISER)
                operator = get_roles_mgr().get_role(RoleNames.EMAIL_OPERATOR_OL)
                operator_main = get_roles_mgr().get_role(RoleNames.EMAIL_OPERATOR_MAIN, bind_functions=False)
            case _:
                language_checker_reply = await language_checker.check(self.user_chat.history)
                adviser = get_roles_mgr().get_role(RoleNames.ADVISER)
                operator = get_roles_mgr().get_role(RoleNames.OPERATOR_OL)
                operator_main = get_roles_mgr().get_role(RoleNames.OPERATOR_MAIN, bind_functions=False)

        language = await language_converter(language_checker_reply)
        await self.language_repo.update_language(self.user_chat.user.chat_id, language)

        language_advice = self.advice_uk_speak
        if language != BaseLang.UKRAINIAN:
            language_advice = self.advice_en_speak

        ol = OperatorLoop(
            mode,
            language_advice,
            self.user_chat,
            admin_chats_register,
            adviser,
            operator,
            operator_main,
            self.tender_repo,
            self.knowledge_base
        )
        reply = await ol.reply()
        for msg in ol.messages_to_manager:
            self.user_chat.append(msg)

        editor = get_roles_mgr().get_role(RoleNames.EDITOR)

        #TODO if OperatorLoop.reply() returns empty string, it should also be ignored
        if reply is not None:
            match self.user_chat:
                case EmailUserChat():
                    humanizer = get_roles_mgr().get_role(RoleNames.EMAIL_HUMANIZER)
                    reply = await humanizer.humanize(self.user_chat.user.chat_id, language_advice, self.user_chat.history, self.user_chat.events, reply)
                case _:
                    humanizer = get_roles_mgr().get_role(RoleNames.HUMANIZER)
                    reply = await humanizer.humanize(language_advice, self.user_chat.history, reply)

            reply = await editor.edit_data_in_reply(language_advice, self.user_chat.history + ol.inter_steps, self.user_chat.events, reply)
            self.user_chat.append(AgentMessage(await self.filter_reply_text(reply)))

        with suppress_asyncio_cancel():
            await ol.admin_chats_register.commit()
            await self.user_chat.commit()
            self.user_chat.clear()
            ol.clear()

        return reply

    @traceable(name="MainAgent.reply")
    async def reply(self) -> str | None:
        return await self._run_ol_with_mode(OLMode.WITH_ADVISER)

    @traceable(name="MainAgent.pass_admin_response")
    async def pass_admin_response(self) -> str | None:
        return await self._run_ol_with_mode(OLMode.NO_ADVISER)

    @staticmethod
    async def filter_reply_text(message):
        pattern = r'\[(.*?)\]\((.*?)\)'
        plain_reply = re.sub(pattern, r'\2', message)
        return plain_reply

    class Config:
        arbitrary_types_allowed = True
