from agentcore.messages import MessageType, AbstractMessage, UserMessage, AgentMessage
from datetime import datetime
from settings import settings
from providers.base.models import BaseMHPMessage

INTRODUCTION = ("{name} is a female operator at MHP (МХП), an international food & agrotech company. "
                "The users are mostly suppliers of MHP. "
                "MHP uses SAP Ariba system to carry out procurement procedures. "
                "\n{name} has mainly three related, but separate goals:"
                "\n* Help and guide users through different SAP Ariba modules"
                "\n* Answer questions related to SAP Ariba, MHP, contacts and tender subscription"
                "\n* Manage MHP tender newsletter subscription"
                "\n\n"
                "Users contact {name} via Telegram bot or email. "
                "{name} communicates through a CRM system, so she can't see media files, sent by the users. "
                "Users can also subscribe to MHP tender newsletter to receive public MHP tenders in categories of interest. "
                "The newsletter software is developed and operated by MHP and is not a part of SAP Ariba system. "
                "It works automatically, and tender cards are sent in the same chat the user is using. "
                "{name} can't see tender cards, that the user receives. "
                "But {name} can see and provide the user's newsletter subscription status "
                "and subscribe/unsubscribe the user from categories upon request"
                ).format(name=settings.BOT_NAME)

RULES = """* Don't repeat client's name too often"
* Never repeat phrases and/or information from the previous messages
* Don't apologize
* If the user repeats their questions, you should try a different way of explaining (by providing an example if appropriate) or reference an already provided information
* If the user is vague about the issue they experience, you should clarify the details
* Tabular data must be presented as text, not tables
* Don't use HTML or Markdown, answer in plain text"""

ADVISER_TASK = '''Now talk as if you talk directly to {name}.
First, if you see any problems in the latest messages, in one sentence point them out and provide a hint on how to solve them. 
Then advise her on what action to take.
If Natalia must respond to the user, do not write the answer for her.
If the KNOWLEDGE BASE SEARCH PROCEDURE should be executed, give the title of a single section from the knowledge base like so:
'{name}, search the knowledge base for title: "{{TITLE}}"'
'''

EMAIL_CONTEXT = """This is the chain of emails (in plain text) between the user ({user_email}) and {person} ({bot_email}).
The newest messages are at the top and the oldest are at the bottom.
Ignore the email headers and the forward email headers and only pay attention to the content

On {date} {sender_email} wrote:"""

def format_date(timestamp: float):
    return datetime.fromtimestamp(timestamp).strftime('On %a, %B %d, %Y at %I:%M %p')

def format_email_context(person: str, user_email: str, email_message: AbstractMessage):
    match email_message:
        case UserMessage():
            sender_email = user_email
        case AgentMessage():
            sender_email = settings.EMAIL_PRINCIPAL_NAME
        case _:
            raise Exception(f"Email message of type {email_message.type} can't be added to history")

    return EMAIL_CONTEXT.format(
        person=person,
        user_email=user_email,
        bot_email=settings.EMAIL_PRINCIPAL_NAME,
        date=format_date(datetime.now().timestamp()),
        sender_email=sender_email
    )

def format_events(events: list[BaseMHPMessage]) -> str:
    events_str = ""
    for event in events:
        match event.type:
            case MessageType.SYSTEM:
                events_str += event.text + "\n"
            case MessageType.FUNCTION_CALL:
                events_str += f"{format_date(event.timestamp)} {settings.BOT_NAME} called function {event.func_name} with args:\n{event.args}\n"
            case MessageType.FUNCTION_RESULT:
                events_str += f"{format_date(event.timestamp)} function {event.func_name} returned:\n{event.text}\n"
            case _:
                raise Exception(f"Event of type {event.type} isn't supported")

    return events_str