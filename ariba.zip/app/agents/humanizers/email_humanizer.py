from agentcore.base import arun
from agentcore.roles.basic import BasicRole
from agentcore.config import get_global_config
from agentcore.messages import AbstractMessage, to_langchain_messages
from langchain.schema import BaseMessage, SystemMessage
from langchain.prompts import (
    SystemMessagePromptTemplate,
    MessagesPlaceholder,
    HumanMessagePromptTemplate,
)

from settings import settings
from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from providers.base.models import BaseMHPMessage
import agents.common as common


class EmailHumanizer(BasicRole):
    def __init__(self):
        super().__init__(config=get_global_config().copy_with(temperature=0.2))
        system = self.get_local_file("system.md")
        self.prompt_template = SystemMessagePromptTemplate.from_template(system)+ [
            MessagesPlaceholder(variable_name="context"),
            MessagesPlaceholder(variable_name="history"),
            MessagesPlaceholder(variable_name="events"),
            SystemMessagePromptTemplate.from_template("This is the critique of the conversation between {name} and the user:\n{critique}"),
            SystemMessagePromptTemplate.from_template("This is the last message from {name}:\n{last_agent_message}"),
            SystemMessagePromptTemplate.from_template(
                "Now change {name}'s last message based on the provided critique or leave it the same"
            ),
        ]

    async def humanize(self, user_email: str, language_advice: str, history: list[AbstractMessage], events: list[BaseMHPMessage], reply: str) -> str:
        critic = get_roles_mgr().get_role(RoleNames.EMAIL_CRITIC)
        critique = await critic.critique(user_email, language_advice, history, reply)
        if critique:
            events_formatted = common.format_events(events)
            result = await self._humanize(
                name = settings.BOT_NAME,
                introduction = common.INTRODUCTION,
                rules = common.RULES,
                language_advice = language_advice,
                context=[SystemMessage(content=common.format_email_context(settings.BOT_NAME, user_email, history[-1]))] if history else [],
                history = to_langchain_messages(history),
                events = [SystemMessage(content=events_formatted)],
                last_agent_message = reply,
                critique = critique,
            )  # type: ignore
        else:
            result = reply

        return result

    @arun
    async def _humanize(
        self,
        name: str,
        introduction: str,
        rules: str,
        language_advice: str,
        context: list[BaseMessage],
        history: list[BaseMessage],
        events: list[BaseMessage],
        last_agent_message: str,
        critique: str,
    ) -> str: ...
