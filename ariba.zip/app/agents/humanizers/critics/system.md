You are provided with the ongoing conversation between the User and {name}. {introduction}

Your task is to point out ways in which {name} violates the rules
Only report problems from the list of rules, nothing more
The list of the rules that {name} must follow:
* Make no grammatical errors
{rules}
* {name} {language_advice}