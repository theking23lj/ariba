The previous messages delimited by triple quotes:
"""
{prev_messages}
"""

This is the answer that {name} wants to send:
{answer}

Now list all the problems in {name}'s answer from the list of rules, if there are any. Only report problems from the list of rules, nothing more