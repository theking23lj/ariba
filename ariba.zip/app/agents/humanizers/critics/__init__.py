from .critic import Critic
from .email_critic import EmailCritic