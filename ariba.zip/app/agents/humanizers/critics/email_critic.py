from agentcore.base import arun
from agentcore.function import Function
from agentcore.roles.basic import BasicRole

from langchain.schema import BaseMessage, SystemMessage
from langchain.prompts import SystemMessagePromptTemplate, MessagesPlaceholder,  HumanMessagePromptTemplate
from agentcore.base import arun
from agentcore.messages import AbstractMessage, to_langchain_messages
from agentcore.config import get_global_config

import agents.common as common
from settings import settings


class EmailCritic(BasicRole):
    def __init__(self):
        super().__init__(
            config=get_global_config().copy_with(temperature=0.2),
            functions=[Function.from_func(self.no_problems)]
        )

        system = self.get_local_file("system.md")
        self.prompt_template = SystemMessagePromptTemplate.from_template(system) + [
            MessagesPlaceholder(variable_name="context"),
            MessagesPlaceholder(variable_name="history"),
            SystemMessagePromptTemplate.from_template("This is the answer {name} wants to send:"),
            HumanMessagePromptTemplate.from_template("{answer}"),
            SystemMessagePromptTemplate.from_template("Now list all the problems in {name}'s answer from the list of rules, if there are any. Only report problems from the list of rules, nothing more")
        ]

    async def no_problems(self):
        """Call if there are no problems in the message"""
        return None

    async def critique(self, user_email: str, language_advice: str, history: list[AbstractMessage], answer: str):
        last_email = history[-1] if history else None
        return await self._critique(
            name = settings.BOT_NAME,
            introduction = common.INTRODUCTION,
            rules = common.RULES,
            language_advice = language_advice,
            context=[SystemMessage(content=common.format_email_context(settings.BOT_NAME, user_email, last_email))] if last_email else [],
            history = to_langchain_messages([last_email]) if last_email else [],
            answer = answer
            )

    @arun
    async def _critique(
        self,
        name: str,
        introduction: str,
        rules: str,
        language_advice: str,
        context: list[BaseMessage],
        history: list[BaseMessage],
        answer: str
    ) -> str: ...
