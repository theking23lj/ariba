from agentcore.base import arun
from agentcore.function import Function
from agentcore.config import get_global_config
from agentcore.roles.basic import BasicRole


class Critic(BasicRole):
    def __init__(self):
        super().__init__(
            config=get_global_config().copy_with(temperature=0.2),
            functions=[Function.from_func(self.no_problems)]
        )

    async def no_problems(self):
        """Call if there are no problems in the message"""
        return None

    @arun
    async def critique(self, name: str, introduction: str, rules: str, language_advice: str, prev_messages: str, answer: str) -> str:
        ...
