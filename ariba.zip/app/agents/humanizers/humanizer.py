from agentcore.base import arun
from agentcore.config import get_global_config
from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, MessageType
from agentcore.roles.basic import BasicRole

from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from settings import settings
import agents.common as common

N_PREV_MESSAGES = 7


class Humanizer(BasicRole):

    def __init__(self):
        super().__init__(config=get_global_config().copy_with(temperature=0.2))
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: settings.BOT_NAME + ":\n{text}",
                MessageType.FUNCTION_CALL: settings.BOT_NAME + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )

    async def humanize(self, language_advice: str, prev_messages: list[AbstractMessage], reply: str) -> str:
        filtered_prev_messages = prev_messages[-N_PREV_MESSAGES:]
        prev_messages_str = "No messages" if len(filtered_prev_messages) == 0 else self.history_template.format(filtered_prev_messages)
        critic = get_roles_mgr().get_role(RoleNames.CRITIC)
        critique = await critic.critique(settings.BOT_NAME, common.INTRODUCTION, common.RULES, language_advice, prev_messages_str, reply)
        if critique:
            result = await self._humanize(settings.BOT_NAME, common.INTRODUCTION, common.RULES, language_advice, prev_messages_str, reply, critique) # type: ignore
        else:
            result = reply

        return result
    
    @arun
    async def _humanize(self, name: str, introduction: str, rules: str, language_advice: str, prev_messages: str, last_agent_message: str, critique: str) -> str:
        ...
