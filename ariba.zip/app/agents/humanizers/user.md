This is the critique of the conversation between {name} and the user delimited by triple quotes:
"""
{critique}
"""

Previous messages from the conversation delimited by triple quotes:
"""
{prev_messages}
"""

This is the last message from {name}:
{last_agent_message}

Now change {name}'s last message based on the provided critique or leave it the same