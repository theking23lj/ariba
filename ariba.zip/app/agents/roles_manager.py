from typing import Any

from agentcore.plugins.knowledge_base import KnowledgeBase
from agentcore.plugins.memory import Summarizer
from agents.utils import RoleNames


class RolesManager:

    def __init__(self):
        self.__cache: dict[RoleNames, Any] = {}
        self.__roles_map: dict | None = None

    def get_role(self, role_name: RoleNames, *args, **kwargs):
        role = self.__cache.get(role_name)
        if role is None:
            role = self.__create_role(role_name, *args, **kwargs)

        return role

    @property
    def roles_map(self) -> dict:
        if self.__roles_map is None:
            self.__roles_map = self.__create_map()

        return self.__roles_map

    @staticmethod
    def __create_map():
        from agents.advisers.adviser import Adviser
        from agents.advisers import Adviser, EmailAdviser
        from agents.data.data_checker import DataChecker
        from agents.data.data_extractor import DataExtractor
        from agents.humanizers import Humanizer, EmailHumanizer
        from agents.humanizers.critics import Critic, EmailCritic
        from agents.operators import Operator, Editor, EmailOperator
        from agents.knowledge_base.adviser import Adviser as KB_Adviser
        from agents.knowledge_base.updater import Updater as KB_Updater
        from agents.language_checker import LanguageChecker

        return {
            RoleNames.KNOWLEDGE_BASE: KnowledgeBase,
            RoleNames.ADVISER: Adviser,
            RoleNames.EMAIL_ADVISER: EmailAdviser,
            RoleNames.OPERATOR_MAIN: Operator,
            RoleNames.OPERATOR_OL: Operator,
            RoleNames.EMAIL_OPERATOR_OL: EmailOperator,
            RoleNames.EMAIL_OPERATOR_MAIN: EmailOperator,
            RoleNames.EDITOR: Editor,
            RoleNames.HUMANIZER: Humanizer,
            RoleNames.EMAIL_HUMANIZER: EmailHumanizer,
            RoleNames.CRITIC: Critic,
            RoleNames.EMAIL_CRITIC: EmailCritic,
            RoleNames.MESSAGE_SUMMARIZER: Summarizer,
            RoleNames.DATA_CHECKER: DataChecker,
            RoleNames.DATA_EXTRACTOR: DataExtractor,
            RoleNames.KB_ADVISER: KB_Adviser,
            RoleNames.KB_UPDATER: KB_Updater,
            RoleNames.LANGUAGE_CHECKER: LanguageChecker,
        }

    def __create_role(self, role_name: RoleNames, *args, **kwargs):
        role = self.__cache[role_name] = self.roles_map[role_name](*args, **kwargs)

        return role


g_roles_mgr = RolesManager()

def get_roles_mgr():
    global g_roles_mgr
    if g_roles_mgr is None:
        g_roles_mgr = RolesManager()

    return g_roles_mgr
