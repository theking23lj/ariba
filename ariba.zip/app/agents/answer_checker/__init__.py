from agentcore.base import arun
from agentcore.roles.basic import BasicRole


class AnswerChecker(BasicRole):
    @arun
    async def check(self, question: str, message: str) -> str:
        ...