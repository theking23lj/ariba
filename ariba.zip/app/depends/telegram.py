import asyncio
from datetime import datetime

import telebot.async_telebot as telebot
from telebot import types
from telebot.asyncio_helper import ApiTelegramException

from settings import settings

from utils.logger import logger_manager


logger = logger_manager.get_logger()


def get_tg_client() -> 'TgClient':
    global _g_tg_client
    if _g_tg_client is None:
        _g_tg_client = TgClient()
        logger.info(f"Created telegram client = {_g_tg_client}")

    return _g_tg_client


class TgClient:

    def __init__(self):
        self._telebot = telebot.AsyncTeleBot(
            settings.BOT_TELEGRAM_TOKEN,
        )
        self.__last_message_sent_at = {}

    async def polling(self):
        offset = None
        while True:
            try:
                updates = await self._telebot.get_updates(offset=offset, timeout=10)
                if updates:
                    await self._telebot.process_new_updates(updates)
                    offset = updates[-1].update_id + 1
            except Exception as e:
                logger.error(f"Error while polling telegram: {e}")
            finally:
                await asyncio.sleep(1)

    @property
    def telebot(self) -> telebot.AsyncTeleBot:
        return self._telebot

    def can_send_notification_for_user(self, chat_id: str):
        last_message_at = self.__last_message_sent_at.get(chat_id)
        if last_message_at is None:
            return True

        delta = datetime.utcnow() - last_message_at
        return delta.seconds >= 60

    async def send_message(self, chat_id: str, text: str, html: bool = False) -> types.Message | None:
        result = None
        while True:
            try:
                if html:
                    result = await self.send_html_message(chat_id=chat_id, text=text)
                else:
                    result = await self.send_simple_message(chat_id=chat_id, text=text)
                self.__last_message_sent_at[chat_id] = datetime.utcnow()
            except ApiTelegramException as e:
                if e.error_code == 400:
                    logger.warning(
                        f"Can not send message to user by id: {chat_id}. Description of exception: {e.description}"
                    )
                elif e.error_code == 403:
                    logger.info(f"The user {chat_id} has blocked the bot. Description of exception: {e.description}")
                elif e.error_code == 429:
                    logger.warning(f"Catch exception: {e}")
                    try:
                        retry_after = e.result_json.get('parameters', {}).get('retry_after')
                        if retry_after is not None:
                            await asyncio.sleep(retry_after)
                    except Exception as e:
                        logger.error(f"Cannot get 'retry_after' parameter: {e}")
                    continue

            break

        return result

    async def send_simple_message(self, chat_id: str, text: str) -> types.Message | None:
        result = await self._telebot.send_message(
            chat_id=chat_id,
            text=text,
        )
        return result

    async def send_html_message(self, chat_id: str, text: str) -> types.Message | None:
        result = await self._telebot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode='HTML'
        )
        return result


_g_tg_client = None
