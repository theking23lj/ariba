from broadcast.client import GlobalBroadcast

from utils.logger import logger_manager

logger = logger_manager.get_logger()


def get_broadcast_obj() -> GlobalBroadcast:
    global _g_broadcast
    if _g_broadcast is None:
        _g_broadcast = GlobalBroadcast()
        logger.info(f"Created global broadcast = {_g_broadcast}")

    return _g_broadcast


def clear_broadcast_obj():
    global _g_broadcast
    _g_broadcast = None

_g_broadcast = None
