from typing import Optional
from msgraph import GraphServiceClient
from msgraph_core import GraphClientFactory
from azure.identity import ClientSecretCredential
from msgraph.graph_request_adapter import GraphRequestAdapter, options
from kiota_http.kiota_client_factory import KiotaClientFactory
from kiota_authentication_azure.azure_identity_authentication_provider import (
    AzureIdentityAuthenticationProvider,
)

from settings import settings


def get_graph_client() -> GraphServiceClient:
    credential = ClientSecretCredential(settings.GRAPH_TENANT_ID, settings.GRAPH_CLIENT_ID, settings.GRAPH_CLIENT_SECRET)
    graph_client = GraphServiceClient(credentials=credential)

    return graph_client

def get_request_adapter(
    credentials: ClientSecretCredential, scopes: Optional[list[str]] = None
) -> GraphRequestAdapter:
    if scopes:
        auth_provider = AzureIdentityAuthenticationProvider(
            credentials=credentials, scopes=scopes)
    else:
        auth_provider = AzureIdentityAuthenticationProvider(
            credentials=credentials)

    return GraphRequestAdapter(
        auth_provider=auth_provider,
        client=GraphClientFactory.create_with_default_middleware(
            options=options, client=KiotaClientFactory.get_default_client()
        ),
    )

# issue: https://github.com/microsoftgraph/msgraph-sdk-python/issues/366#issuecomment-1922252592
def create_graph_client() -> GraphServiceClient:
    credential = ClientSecretCredential(
        settings.GRAPH_TENANT_ID, settings.GRAPH_CLIENT_ID, settings.GRAPH_CLIENT_SECRET)
    return GraphServiceClient(
        request_adapter=get_request_adapter(
            credentials=credential,
            scopes=['https://graph.microsoft.com/.default']
        )
    )
