import redis.asyncio as redis

from settings import settings
from utils.logger import logger_manager

logger = logger_manager.get_logger()


def get_redis() -> redis.Redis:
    client = redis.from_url(settings.REDIS_URI, db=1)
    logger.info(f"Created redis client = {client}")
    return client