# Base URI without parameters
BASE_URI=$(echo "${MONGO_URI}" | awk -F "?" '{print $1}')

# Parameters string extracted from MONGO_URI, assuming you might need it
PARAMS=$(echo "${MONGO_URI}" | awk -F "?" '{print $2}')

# Construct the final URL with the database name and parameters
FINAL_URL="${BASE_URI}${MONGO_DB_NAME}?${PARAMS}"

# Use the constructed URL with mongodb-migrate command
mongodb-migrate --url "${FINAL_URL}"

echo "Migrations applyed"
