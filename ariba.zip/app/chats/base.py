from abc import abstractmethod, ABC
from os import path
from typing import ClassVar, Self

from agentcore.messages import AbstractMessage
from msgraph.generated.models.body_type import BodyType
from msgraph.generated.models.email_address import EmailAddress
from msgraph.generated.models.file_attachment import FileAttachment
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.message import Message
from msgraph.generated.models.recipient import Recipient
from msgraph.generated.users.item.messages.item.create_forward.create_forward_post_request_body import \
    CreateForwardPostRequestBody
from msgraph.generated.users.item.messages.item.create_forward.create_forward_request_builder import \
    CreateForwardRequestBuilder
from msgraph.generated.users.item.messages.item.create_reply_all.create_reply_all_post_request_body import \
    CreateReplyAllPostRequestBody
from msgraph.generated.users.item.messages.item.create_reply_all.create_reply_all_request_builder import \
    CreateReplyAllRequestBuilder
from msgraph.generated.users.item.messages.messages_request_builder import MessagesRequestBuilder
from msgraph.graph_service_client import GraphServiceClient
from pydantic import BaseModel

from broadcast.repo import BroadcastCache
from providers.base.models import BaseMHPMessage, BaseProviderMessage, BaseUser
from providers.email.models import BaseEmailMessage
from repos.base import BaseRepository, BaseUserRepository
from settings import settings, APP_PATH
from tenders.models import Tender, TenderCategory
from tenders.repo import TenderRepository
from utils.logger import logger_manager

logger = logger_manager.get_logger()

DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


class BaseChat(BaseModel, ABC):
    repo: BaseRepository
    repo_class: ClassVar[type[BaseRepository]]
    id: str
    last_message: BaseProviderMessage | None = None

    @classmethod
    @abstractmethod
    async def build(cls, chat_id: str, **kwargs) -> Self:
        """Build chat from repo"""

    @abstractmethod
    def append(self, message: AbstractMessage) -> None:
        ...

    @abstractmethod
    async def commit(self) -> None:
        ...

    @abstractmethod
    def clear(self):
        ...

    class Config:
        arbitrary_types_allowed = True


class BaseUserChat(BaseChat, ABC):
    repo: BaseUserRepository
    repo_class: ClassVar[type[BaseUserRepository]]
    type: ClassVar[str]
    user: BaseUser
    events: list[BaseMHPMessage]

    @property
    @abstractmethod
    def history(self) -> list[AbstractMessage]:
        ...

class SendEmailChatMixin:
    MESSAGE_TEMPLATE_PATH = path.join(APP_PATH, "tools/email-signature.html")
    IMAGE_PATH = path.join(APP_PATH, "tools/ariba_logo.png")

    @staticmethod
    def read_html_file(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            html_content = file.read()
        return html_content

    @staticmethod
    def read_image(file_path):
        with open(file_path, 'rb') as file:
            content = file.read()
        return content

    @staticmethod
    def plain_text_to_html(text: str) -> str:
        return text.replace("&", "&amp").replace("<", "&lt").replace(">", "&gt").replace("\n\r", "<br>").replace("\n", "<br>")

    @staticmethod
    async def _send_email_message(message: BaseEmailMessage, client: GraphServiceClient, plain_text: bool = False) -> None:
        message_template = SendEmailChatMixin.read_html_file(SendEmailChatMixin.MESSAGE_TEMPLATE_PATH)
        if plain_text:
            # Convert plain text to html and update message obj
            message.text = SendEmailChatMixin.plain_text_to_html(message.text)
        content = message_template.replace("$content$", message.text)

        logger.info(f"Sending email - {message}")
        email_message = Message(
            subject=message.subject,
            attachments=[
                FileAttachment(
                    content_type="image/png",
                    content_bytes=SendEmailChatMixin.read_image(SendEmailChatMixin.IMAGE_PATH),
                    content_id="logo",
                    name="logoImage.png",
                    is_inline=True,
                ),
            ]
        )
        email_user = client.users.by_user_id(settings.EMAIL_PRINCIPAL_NAME)

        if message.forward_message_id:
            request_config = CreateForwardRequestBuilder.CreateForwardRequestBuilderPostRequestConfiguration()
            request_config.headers.add("Prefer", "IdType='ImmutableId'")
            draft_message = await email_user.messages.by_message_id(message.forward_message_id).create_forward.post(
                body=CreateForwardPostRequestBody(
                    comment=content,
                    message=email_message,
                    to_recipients=[Recipient(email_address=EmailAddress(address=message.to_email))]
                ),
                request_configuration=request_config
            )
        elif message.in_reply_to:
            request_config = CreateReplyAllRequestBuilder.CreateReplyAllRequestBuilderPostRequestConfiguration()
            request_config.headers.add("Prefer", "IdType='ImmutableId'")
            draft_message = await email_user.messages.by_message_id(message.in_reply_to).create_reply_all.post(
                body=CreateReplyAllPostRequestBody(
                    message=email_message,
                    comment=content
                ),
                request_configuration=request_config
            )
        else:
            request_config = MessagesRequestBuilder.MessagesRequestBuilderPostRequestConfiguration()
            request_config.headers.add("Prefer", "IdType='ImmutableId'")
            # Add content to message
            email_message.body = ItemBody(
                content=content,
                content_type=BodyType.Html,
            )
            # Add recipients
            email_message.to_recipients = [Recipient(email_address=EmailAddress(address=message.to_email))]
            # Create the draft message
            draft_message = await email_user.messages.post(email_message, request_config)

        # Send the draft message from the previous step
        await email_user.messages.by_message_id(draft_message.id).send.post()
        sent_message = await email_user.messages.by_message_id(draft_message.id).get()
        # Save message ID and conversation ID in our message obj.
        message.message_id = sent_message.id
        message.chat_id = sent_message.conversation_id


class AbstractMessageDistributor(BaseModel, ABC):
    repo: BaseUserRepository
    repo_class: ClassVar[type[BaseUserRepository]]

    @classmethod
    @abstractmethod
    async def build(cls, **kwargs) -> Self:
        """Build sender from repo"""

    @abstractmethod
    async def send_tenders_to_all(
        self,
        tenders: list[Tender],
        all_categories: list[TenderCategory] | None,
        **kwargs,
    ) -> None:
        """Send tenders to all users by chosen categories"""

    @abstractmethod
    async def send_tenders_to_one(
        self,
        user_id: str,
        tenders: list[Tender],
        all_categories: list[TenderCategory] | None,
        **kwargs,
    ) -> None:
        """Send tenders to the users by chosen categories"""

    @abstractmethod
    async def send_text_to_all(self, texts: list[str]) -> None:
        """Send text or list of texts to all users from repo"""

    @abstractmethod
    async def send_text_to_one(self, texts: list[str], user_id: str) -> None:
        """Send text to the user by id"""

    @abstractmethod
    async def _send_texts(self, texts: list[str], user: BaseUser) -> None:
        """Send texts to the user by id"""

    @abstractmethod
    async def _send_tenders(
            self, tenders: list[Tender],
            categories: dict[str, TenderCategory],
            user: BaseUser,
            **kwargs,
    ) -> None:
        """Send tenders to the user by id"""

    class Config:
        arbitrary_types_allowed = True


class BaseMessageDistributor(AbstractMessageDistributor, ABC):
    broadcast_cache: BroadcastCache

    @classmethod
    async def build(cls, broadcast_cache: BroadcastCache, **kwargs) -> Self:
        repo = await cls.repo_class.get_instance()
        return cls(
            repo=repo,
            broadcast_cache=broadcast_cache,
            **kwargs
        )

    async def send_tenders_to_all(
        self,
        tenders: list[Tender],
        all_categories: list[TenderCategory] | None = None,
        **kwargs
    ) -> None:
        if all_categories is None:
            repo = await TenderRepository.get_instance()
            all_categories = await repo.get_categories()

        users = await self.repo.get_all_users()
        for user in users:
            await self._send_tenders_to_user(user, tenders, all_categories, **kwargs)

    async def send_tenders_to_one(
        self,
        user_id: str,
        tenders: list[Tender],
        all_categories: list[TenderCategory] | None = None,
        **kwargs
    ) -> None:
        if all_categories is None:
            repo = await TenderRepository.get_instance()
            all_categories = await repo.get_categories()

        user = await self.repo.get_user_by_chat_id(user_id)
        if user is None:
            logger.warning(f"Not found user in repo by id = {user_id}")
            return

        await self._send_tenders_to_user(user, tenders, all_categories, **kwargs)

    async def send_text_to_all(self, texts: list[str]) -> None:
        users = await self.repo.get_all_users()

        for user in users:
            await self._send_texts(texts, user)

    async def send_text_to_one(self, texts: list[str], user_id: str) -> None:
        user = await self.repo.get_user_by_chat_id(user_id)
        if user is None:
            return

        await self._send_texts(texts, user)

    async def _send_tenders_to_user(
        self,
        user: BaseUser,
        tenders: list[Tender],
        all_categories: list[TenderCategory],
        skip_watched: bool = False,
        **kwargs,
    ):
        tender_messages = await self.broadcast_cache.get_all_tg_notification_tenders_by_user_id(user.chat_id)
        user_tenders = user.filter_tenders(
            tenders,
            [m.id for m in tender_messages],
            skip_watched=skip_watched
        )
        if not user_tenders:
            return

        all_categories_by_dict = {c.unique_name: c for c in all_categories}
        # await self.repo.add_waiting_tenders(user, user_tenders)
        await self._send_tenders(
            user_tenders, all_categories_by_dict, user, skip_watched=skip_watched
        )
