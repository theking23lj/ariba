import asyncio
from copy import deepcopy
from datetime import datetime
from typing import ClassVar
from collections.abc import Sequence
from agentcore.messages import FunctionCall, FunctionResult, SysMessage, UserMessage, AgentMessage, AbstractMessage


from chats.base import BaseUserChat, BaseMessageDistributor
from depends import get_tg_client
from providers.tg.models import TgMessage, TgUser
from repos.tg_user import TgUserMongoRepository
from tenders.models import Tender, TenderCategory
from utils.logger import logger_manager
from agents.memory import MHPSummaryMemory

logger = logger_manager.get_logger()


class TgChat(BaseUserChat):
    type: ClassVar[str] = 'tg'
    repo_class = TgUserMongoRepository
    memory: MHPSummaryMemory

    @staticmethod
    async def build(chat_id: str) -> 'TgChat':
        repo = await TgUserMongoRepository.get_instance()
        user = await repo.get_user_by_chat_id(chat_id)
        if user is None:
            raise Exception(f'User with chat_id "{chat_id}" not found')
        memory = await MHPSummaryMemory.build(repo=repo, chat_id=chat_id)
        last_message = memory.prev_messages[-1] if memory.prev_messages else None

        return TgChat(
            repo=repo,
            id=chat_id,
            user=user,
            events=[],
            memory=memory,
            last_message=last_message
        )

    @property
    def history(self) -> list[AbstractMessage]:
        return self.memory.history
    
    def append(self, message: AbstractMessage) -> None:
        self.memory.append(message)

    async def commit(self) -> None:
        messages: Sequence[TgMessage] = []
        for msg in self.memory.current_messages:
            tg_message = self._create_chat_message_based_on_last(msg)
            messages.append(tg_message)
            if isinstance(msg, AgentMessage):
                await self._send_reply(tg_message)

        #TODO change the type of the first parameter to Sequence[BaseProviderMessage] in agentcore to avoid type error
        await self.memory.commit(messages, self.id)

    def _create_chat_message_based_on_last(self, message: AbstractMessage) -> TgMessage:
        text, func_name, args = None, None, None
        match message:
            case FunctionCall() as m:
                text = m.text
                func_name = m.func_name
                args = m.args
            case FunctionResult() as m:
                text = m.value
                func_name = m.func_name
            case SysMessage() | UserMessage() | AgentMessage() as m:
                text = m.text
            case _:
                raise Exception(f'Unsupported message type "{message}"')

        return TgMessage(
            chat_id=self.id,
            text=text,
            date=datetime.now().isoformat(),
            type=message.type,
            func_name=func_name,
            args=args,
        )
    
    def clear(self):
        self.memory.clear()

    async def _send_reply(self, reply_message: TgMessage) -> None:
        if reply_message.text:
            tg_client = get_tg_client()
            await tg_client.send_message(self.id, reply_message.text)


class TgMessageDistributor(BaseMessageDistributor):
    repo_class = TgUserMongoRepository

    async def _send_texts(self, texts: list[str], user: TgUser) -> None:
        tg_client = get_tg_client()
        texts = deepcopy(texts)
        while texts:
            text = texts.pop()
            await tg_client.send_message(user.chat_id, text, html=True)
            if texts:
                await asyncio.sleep(30)

    async def _send_tenders(
            self, tenders: list[Tender], categories: dict[str, TenderCategory], user: TgUser, **kwargs
    ) -> None:
        await self.broadcast_cache.save_tg_notification_tenders(user.chat_id, tenders, **kwargs)
