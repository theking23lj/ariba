from datetime import datetime
from typing import ClassVar
from agentcore.messages import (
    AbstractMessage,
    FunctionCall,
    FunctionResult,
    SysMessage,
    UserMessage,
    AgentMessage,
    MessageType,
)
from agentcore.providers.messages import BaseProviderMessage

from repos.events import EventsRepository
from chats.base import BaseUserChat, SendEmailChatMixin, BaseMessageDistributor
from providers.base.models import BaseMHPMessage, BaseUser
from providers.email.models import UserEmailMessage, EmailUser
from tenders.models import Tender, TenderCategory
from repos.email_user import EmailUserMongoRepository
from settings import settings
from depends import get_graph_client

from utils.logger import logger_manager
from repos.base import BaseLanguageRepository
from repos.language_converter import language_converter, BaseLang

logger = logger_manager.get_logger()

TRUNCATED_LENGTH = 10000

class EmailUserChat(SendEmailChatMixin, BaseUserChat):
    type: ClassVar[str] = 'email'
    user: EmailUser
    appended_messages: list[AbstractMessage]  = []
    repo_class = EmailUserMongoRepository
    last_message: UserEmailMessage | None = None
    truncated_last_message: UserEmailMessage | None = None
    unique_history_messages: list[AbstractMessage] | None = None
    events: list[BaseMHPMessage]

    @staticmethod
    async def build(user_id: str, chat_id: str) -> 'EmailUserChat':
        repo = await EmailUserMongoRepository.get_instance()

        #TODO user.chat_id should be renamed to user.id
        user = await repo.get_user_by_chat_id(user_id)
        if user is None:
            raise Exception(f'User with email "{user_id}" not found')

        history = await repo.get_history(chat_id)
        last_message = None
        truncated_last_message = None

        for message in reversed(history):
            if message.type in [MessageType.USER, MessageType.AGENT]:
                last_message = message
                truncated_last_message = message.model_copy()
                truncated_last_message.text = message.text[:TRUNCATED_LENGTH]
                break
            else:
                logger.warning(f"History should only contain messages of type USER or AGENT, but got {message.type}")

        # Change argument type from list to Sequence to avoid type error
        unique_history_messages = []
        for message in history:
            converted_message = BaseMHPMessage.from_provider_message_to_ac(message)
            match converted_message :
                case AgentMessage() | UserMessage():
                    if message.unique_text:
                        converted_message.text = message.unique_text
                        unique_history_messages.append(converted_message)
                case _:
                    logger.warning(f"History should only contain messages of type USER or AGENT, but got {message.type}")
        

        events_repo = await EventsRepository.get_instance()
        return EmailUserChat(
            repo=repo,
            id=chat_id,
            user=user,
            last_message=last_message,
            truncated_last_message=truncated_last_message,
            unique_history_messages = unique_history_messages,
            events=await events_repo.get_events(chat_id)
        )

    @property
    def history(self) -> list[AbstractMessage]:
        return [BaseProviderMessage.from_provider_message_to_ac(self.truncated_last_message)] if self.truncated_last_message else []

    def append(self, message: AbstractMessage) -> None:
        self.appended_messages.append(message)

    async def commit(self) -> None:
        for msg in self.appended_messages:
            match msg:
                case AgentMessage():
                    provider_message = self._create_chat_message_based_on_last(msg)
                    await self._send_email_message(provider_message, client=get_graph_client(), plain_text=True)
                    await self.repo.save_message(provider_message)
                case FunctionCall() | FunctionResult() |SysMessage():
                    events_repo = await EventsRepository.get_instance()
                    await events_repo.insert(events_repo.create_event(self.id, msg))
                case _:
                    raise Exception(f"Email message of type {msg.type} can't be added to history")

    def _create_chat_message_based_on_last(self, message: AbstractMessage) -> UserEmailMessage:
        body, func_name, args = None, None, None
        from_email = None
        to_email = None

        if isinstance(message, UserMessage):
            from_email = self.user.chat_id
            to_email = settings.EMAIL_PRINCIPAL_NAME
        else:
            from_email = settings.EMAIL_PRINCIPAL_NAME
            to_email = self.user.chat_id

        match message:
            case FunctionCall() as m:
                body = m.text
                func_name = m.func_name
                args = m.args
            case FunctionResult() as m:
                body = m.value
                func_name = m.func_name
            case SysMessage() | UserMessage() | AgentMessage() as m:
                body = m.text
            case _:
                raise Exception(f'Unsupported message type "{message}"')

        if "Re:" in self.last_message.subject:
            reply_subject = self.last_message.subject
        else:
            reply_subject = f"Re: {self.last_message.subject}"

        return UserEmailMessage(
            _id = None,
            from_email=from_email,
            sender_name=settings.BOT_NAME,
            to_email=to_email,
            chat_id=self.last_message.chat_id,
            subject=reply_subject,
            in_reply_to=self.last_message.message_id,
            text=body,
            unique_text=body,
            date=datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            type=message.type,
            func_name=func_name,
            args=args,
        )

    def clear(self):
        self.appended_messages.clear()


class EmailMessageDistributor(BaseMessageDistributor, SendEmailChatMixin):
    repo_class = EmailUserMongoRepository

    async def _send_texts(self, texts: list[str], user: EmailUser) -> None:
        lang_repo = await BaseLanguageRepository.get_instance()
        language = await language_converter(await lang_repo.get_language_or_default(user.chat_id))
        if language == BaseLang.UKRAINIAN:
            subject = "Новий тендер"
        else:
            subject = "New tender"
        text = "<br>".join(texts)
        message = UserEmailMessage(
            _id = None,
            chat_id="dummy",
            from_email=settings.EMAIL_PRINCIPAL_NAME,
            sender_name=settings.BOT_NAME,
            to_email=user.chat_id,
            subject=subject,
            unique_text=text,
            text=text,
            date=datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            type=MessageType.NONE,
        )
        await self._send_email_message(message, client=get_graph_client())

    async def _send_tenders_to_user(
        self,
        user: BaseUser,
        tenders: list[Tender],
        all_categories: list[TenderCategory],
        skip_watched: bool = False,
        **kwargs,
    ):
        user_tenders = user.filter_tenders(
            tenders,
            user.waiting_tender_ids,  # TODO replace to the cache from Redis
            skip_watched=skip_watched
        )
        if not user_tenders:
            return

        all_categories_by_dict = {c.unique_name: c for c in all_categories}
        await self.repo.add_waiting_tenders(user, user_tenders)
        await self._send_tenders(user_tenders, all_categories_by_dict, user)
        await self.repo.pull_waiting_tenders(user, [t.internal_id for t in user_tenders])
        await self.repo.add_watched_tenders(user, user_tenders)

    async def _send_tenders(
            self, tenders: list[Tender],
            categories: dict[str, TenderCategory],
            user: BaseUser,
            **kwargs
    ) -> None:
        lang_repo = await BaseLanguageRepository.get_instance()
        language = await language_converter(await lang_repo.get_language_or_default(user.chat_id))
        if language == BaseLang.UKRAINIAN:
            await self._send_texts([t.to_short_ua_html_message(categories) for t in tenders], user)
        else:
            await self._send_texts([t.to_short_en_html_message(categories) for t in tenders], user)
