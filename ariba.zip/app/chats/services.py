from datetime import datetime, timedelta
from repos.events import EventsRepository
from chats.base import DATE_FORMAT
from chats.email_admin_chat import EmailAdminNotifier
from repos.email_admin import EmailAdminMongoRepository
from repos.email_user import EmailUserMongoRepository
from repos.tg_user import TgUserMongoRepository

from utils.logger import logger_manager

logger = logger_manager.get_logger()


async def notify_admin_about_open_threads(skip_time: bool = False):
    repo = await EmailAdminMongoRepository.get_instance()
    threads = await repo.get_open_threads()
    messages = []
    for thread in threads:
        history = await repo.get_history(thread.thread_id)
        if not history:
            continue

        last_message = history[-1]
        last_message_date = datetime.strptime(last_message.date, DATE_FORMAT)
        now = datetime.utcnow()
        if skip_time or now.date() - last_message_date.date() >= timedelta(days=1):
            messages.append(last_message)

    if messages:
        await EmailAdminNotifier.notify(messages)


async def scheduled_reset_tokens_and_unpause_users():
    tg_user_repo = await TgUserMongoRepository.get_instance()
    await tg_user_repo.reset_tokens_for_all_users()
    email_repo = await EmailUserMongoRepository.get_instance()
    await email_repo.reset_tokens_for_all_users()


async def clear_old_events(timestamp: int):
    repo = await EventsRepository.get_instance()
    await repo.clear_old_events(timestamp)