from dataclasses import dataclass
from datetime import datetime
from typing import Self
from pydantic import BaseModel
from agentcore.messages import (
    AbstractMessage, AgentMessage,
    MessageType
)

from chats.base import BaseChat, BaseUserChat, SendEmailChatMixin, DATE_FORMAT
from providers.base.models import BaseProviderMessage
from providers.email.models import AdminEmailMessage
from repos.email_admin import EmailAdminMongoRepository
from depends.email_client import create_graph_client, get_graph_client
from settings import settings


@dataclass
class QuestionMessage(AgentMessage):
    context: str | None = None


class AdminChatsRegister(SendEmailChatMixin, BaseModel):
    repo: EmailAdminMongoRepository
    user_chat: BaseUserChat
    first_messages_in_chats: list[QuestionMessage | AgentMessage] = []

    @classmethod
    async def get_repo(cls) -> EmailAdminMongoRepository:
        repo = await EmailAdminMongoRepository.get_instance()
        return repo

    def append(self, question: str, context: str | None = None) -> None:
        message = QuestionMessage(text=question, context=context)
        self.first_messages_in_chats.append(message)

    async def commit(self) -> None:
        if self.first_messages_in_chats:
            #TODO change self.user_chat.user.chat_id to self.user_chat.user.id
            thread = await self.repo.create_thread(self.user_chat.user.chat_id, self.user_chat.type, self.user_chat.id)
            forward_message_id = None
            if self.user_chat.type == "email":
                forward_message_id = self.user_chat.last_message.message_id if self.user_chat.last_message is not None else None

            for message in self.first_messages_in_chats:
                text=message.context + "\n\n" + message.text
                bot_message = AdminEmailMessage(
                    _id=None,
                    chat_id=self.user_chat.id,
                    from_email=settings.EMAIL_PRINCIPAL_NAME,
                    sender_name=settings.BOT_NAME,
                    to_email=settings.ADMIN_EMAIL,
                    subject=message.text,
                    text=text,
                    unique_text=text,
                    date=datetime.utcnow().strftime(DATE_FORMAT),
                    type=message.type,
                    forward_message_id=forward_message_id,
                    thread_id=thread.thread_id,
                )

                await self._send_email_message(bot_message, client=get_graph_client(), plain_text=True)
                await self.repo.add_message(bot_message)

    def clear(self):
        ...

    class Config:
        arbitrary_types_allowed = True


class EmailAdminChat(SendEmailChatMixin, BaseChat):
    repo: EmailAdminMongoRepository
    prev_history: list[AbstractMessage]
    new_messages: list[AbstractMessage] = []
    repo_class = EmailAdminMongoRepository

    @property
    def history(self) -> list[AbstractMessage]:
        return self.prev_history + self.new_messages

    @classmethod
    async def build(cls, thread_id: str, **kwargs) -> Self:
        repo = await cls.repo_class.get_instance()
        prev_history = await repo.get_history(thread_id)
        last_message = prev_history[-1] if prev_history else None
        prev_history = BaseProviderMessage.from_provider_messages_to_ac(prev_history)
        return cls(
            repo=repo,
            id=thread_id,
            prev_history=prev_history,
            last_message=last_message,
            **kwargs
        )

    def _create_chat_message_based_on_last(self, message: AgentMessage) -> AdminEmailMessage:
        if not self.last_message:
            # EmailAdminChat will be created when actual chat(email thread) is already created,
            # so there will be at least one message
            raise Exception('EmailAdminChat must have last_message to use _create_chat_message_based_on_last')

        return AdminEmailMessage(
            _id=None,
            sender_name=settings.BOT_NAME,
            from_email=settings.EMAIL_PRINCIPAL_NAME,
            to_email=settings.ADMIN_EMAIL,
            subject=self.last_message.subject,
            in_reply_to=self.last_message.message_id,
            text=message.text,
            unique_text=message.text,
            date=datetime.utcnow().strftime(DATE_FORMAT),
            type=message.type,
            thread_id=self.id,
            chat_id=self.last_message.chat_id
        )

    def append(self, message: AbstractMessage) -> None:
        self.new_messages.append(message)

    async def commit(self) -> None:
        for msg in self.new_messages:
            if isinstance(msg, AgentMessage):
                email_message = self._create_chat_message_based_on_last(msg)
                await self._send_email_message(email_message, client=get_graph_client(), plain_text=True)
                await self.repo.add_message(email_message)
            else:
                raise Exception(f"Email message of type {msg.type} can't be added to history")

    async def close_thread(self):
        await self.repo.close_thread(self.id)

    def clear(self):
        self.new_messages = []

    class Config:
        arbitrary_types_allowed = True


class EmailAdminNotifier(SendEmailChatMixin):

    @classmethod
    async def notify(cls, messages: list[AdminEmailMessage]) -> None:
        message = cls.create_notify_message(messages)
        await cls._send_email_message(message, client=create_graph_client())

    @staticmethod
    def create_notify_message(messages: list[AdminEmailMessage]) -> AdminEmailMessage:
        body = ""
        for idx, message in enumerate(messages, start=1):
            body += f"{idx}. {message.subject};<br>"

        body += "<br>Увага! Відповідь потрібно надати окремо на кожен лист, щоб вона дійшла користувачу."

        return AdminEmailMessage(
            _id=None,
            chat_id="dummy",
            from_email=settings.EMAIL_PRINCIPAL_NAME,
            sender_name=settings.BOT_NAME,
            to_email=settings.ADMIN_EMAIL,
            subject=f"Ви маєте {len(messages)} повідомлення/повідомлень від бота, які потребують відповіді на цій поштовій скриньці!",
            text=body,
            unique_text=body,
            date=datetime.utcnow().strftime(DATE_FORMAT),
            type=MessageType.NONE,
        )
