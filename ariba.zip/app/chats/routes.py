from fastapi import APIRouter, HTTPException
from starlette import status

from broadcast.constants import BroadcastType
from celery_worker import task_notify_admin
from repos.email_user import EmailUserMongoRepository
from repos.tg_user import TgUserMongoRepository

router = APIRouter(
    prefix="/chats",
    tags=["chats"],
)


@router.get("/force_notify_admin")
async def force_notify_admin(skip_time: bool = False):
    result = task_notify_admin.delay(skip_time=skip_time)

    return {"task_id": result.id}


@router.get("/get_all_users_by_type/")
async def get_all_users_by_type(user_type: BroadcastType):
    repo = None
    match user_type:
        case BroadcastType.TELEGRAM:
            repo = await TgUserMongoRepository.get_instance()
        case BroadcastType.EMAIL:
            repo = await EmailUserMongoRepository.get_instance()
        case BroadcastType.ALL:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bad user_type.",
            )

    return await repo.get_all_users()


@router.post("/reset_user_history/")
async def reset_user_history(username: str, user_type: BroadcastType):
    user, repo = None, None
    match user_type:
        case BroadcastType.TELEGRAM:
            repo = await TgUserMongoRepository.get_instance()
            user = await repo.get_user_by_username(username)
        case BroadcastType.EMAIL:
            repo = await EmailUserMongoRepository.get_instance()
            user = await repo.get_user_by_chat_id(username)
        case BroadcastType.ALL:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bad user_type.",
            )

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Can not find user.",
        )

    await repo.delete_messages(user)

    return f"History for user {username} has been reset successfully."


@router.post("/reset_tokens/")
async def reset_tokens(user_type: BroadcastType, username: str = None):
    tg_repo = await TgUserMongoRepository.get_instance()
    email_repo = await EmailUserMongoRepository.get_instance()

    user, repo = None, None
    match user_type:
        case BroadcastType.TELEGRAM:
            repo = tg_repo
            user = await tg_repo.get_user_by_username(username)
        case BroadcastType.EMAIL:
            repo = email_repo
            user = await email_repo.get_user_by_chat_id(username)
        case BroadcastType.ALL:
            await tg_repo.reset_tokens_for_all_users()
            await email_repo.reset_tokens_for_all_users()
            return "Tokens for all users have been reset."

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Can not find user.",
        )

    await repo.reset_tokens_for_user(user.chat_id)

    return f"Tokens for the user {username} have been reset."
