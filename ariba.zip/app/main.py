import sys
import asyncio
from contextlib import asynccontextmanager

from fastapi.responses import JSONResponse
import uvicorn
from agentcore.config import set_global_config, AzureConfig, OpenAIConfig
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, Request


from chats.routes import router as chats_router
from tenders.routes import router as tenders_router
from depends import get_tg_client
from settings import settings
from security import verify_api_key

from utils.logger import logger_manager

logger = logger_manager.get_logger()


async def set_config():
    # necessary for langsmith support
    load_dotenv(".env.dev")
    load_dotenv(".env")
    if settings.LLM_API_TYPE == "openai":
        config = OpenAIConfig(
            api_key=settings.OPENAI_KEY,
            model=settings.LLM_MODEL,
            temperature=settings.TEMPERATURE,
            log_name=settings.LOG_NAME,
        )
    elif settings.LLM_API_TYPE == "azure":
        config = AzureConfig(
            api_key=settings.AZURE_KEY,
            endpoint=settings.AZURE_ENDPOINT,
            api_version=settings.AZURE_API_VERSION,
            deployment_name=settings.AZURE_DEPLOYMENT_NAME,
            model=settings.LLM_MODEL,
            temperature=settings.TEMPERATURE,
            log_name=settings.LOG_NAME,
        )
    else:
        raise ValueError("Unsupported API type")

    set_global_config(config)


@asynccontextmanager
async def lifespan(_):
    # Startup
    try:
        logger.info("Starting up...")
        await set_config()

        from message_handler import MessageHandler
        # MessageHandler is the "server inside a server" - it's a central hub, through which all messages pass
        # Therefore it's a singleton
        message_handler = MessageHandler()

        # start imap, check for new emails, then run imap
        from providers.tg.listeners import TgListener
        from providers.email.listeners import EmailListener

        tg_client = get_tg_client()

        tg_listen_task = asyncio.create_task(tg_client.polling())
        tg_listener = TgListener(tg_client, message_handler)

        email_listener = None
        if settings.ENABLE_EMAIL:
            email_listener = EmailListener(message_handler=message_handler)
            email_listener.start()
        # Run FastAPI
        yield
        logger.info("Shutting down...")
        if email_listener is not None:
            email_listener.stop()
        tg_listen_task.cancel()

        del tg_listener
    except Exception as e:
        logger.exception(e)
        # Give it time to log the exception
        await asyncio.sleep(1)


app = FastAPI(lifespan=lifespan)

app.include_router(chats_router, dependencies=[Depends(verify_api_key)])
app.include_router(tenders_router, dependencies=[Depends(verify_api_key)])

@app.exception_handler(Exception)
async def request_exception_handler(request: Request, exc: Exception):
    logger.exception(exc)

    return JSONResponse(
        status_code=500,
        content={"message": "Internal server error"},
    )

if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=443,
        log_level="info",
        forwarded_allow_ips="*",
        proxy_headers=True,
    )
