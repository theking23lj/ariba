from pydantic import BaseModel


class TenderMessage(BaseModel):
    id: str
    skip_watched: bool = False

