from enum import Enum


class BroadcastType(Enum):
    TELEGRAM = "TELEGRAM"
    EMAIL = "EMAIL"
    ALL = "ALL"
