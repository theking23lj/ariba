import asyncio

from chats.base import BaseMessageDistributor
from chats.email_user_chat import EmailMessageDistributor
from chats.tg_chat import TgMessageDistributor
from tenders.models import Tender
from .constants import BroadcastType
from .repo import BroadcastCache

class GlobalBroadcast:
    sender_clazz_map = {
        BroadcastType.TELEGRAM: TgMessageDistributor,
        BroadcastType.EMAIL: EmailMessageDistributor,
        # Add other
    }

    def __init__(self):
        self.__senders: dict[BroadcastType, BaseMessageDistributor] = {}

    async def send_tenders(self, broadcast_type: BroadcastType, tenders: list[Tender], **kwargs):
        senders = await self._get_senders(broadcast_type)
        tasks = [s.send_tenders_to_all(tenders, **kwargs) for s in senders]
        await asyncio.gather(*tasks)

    async def _get_senders(self, broadcast_type: BroadcastType) -> list[BaseMessageDistributor]:
        if broadcast_type == BroadcastType.ALL:
            all_types = list(BroadcastType)
            all_types.remove(BroadcastType.ALL)

            return [await self._build_sender(t) for t in all_types]

        return [await self._build_sender(broadcast_type)]

    async def _build_sender(self, broadcast_type: BroadcastType) -> BaseMessageDistributor:
        if broadcast_type in self.__senders:
            return self.__senders[broadcast_type]

        sender_clazz = self.sender_clazz_map.get(broadcast_type)
        if sender_clazz is None:
            raise Exception(f'Can not find class of sender for broadcast type "{broadcast_type.value}"')

        self.__senders[broadcast_type] = await sender_clazz.build(broadcast_cache=BroadcastCache.get_instance())

        return self.__senders[broadcast_type]
