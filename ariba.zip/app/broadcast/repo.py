from typing import Self

from redis.asyncio import Redis

from depends import get_redis
from tenders.models import Tender
from .models import TenderMessage


class BroadcastCache:
    USER_TG_NOTIFICATIONS_TENDERS_PATTERN = "tg:notifications:tenders:"
    USER_TG_NOTIFICATIONS_TENDERS_KEY = USER_TG_NOTIFICATIONS_TENDERS_PATTERN + "{user_id}"
    USER_TG_NOTIFICATIONS_TENDERS_SEARCH = USER_TG_NOTIFICATIONS_TENDERS_PATTERN + "*"

    def __init__(self, redis_client: Redis):
        self._redis_client = redis_client

    @classmethod
    def get_instance(cls) -> Self:
        return cls(get_redis())

    async def save_tg_notification_tenders(self, user_id: str, tenders: list[Tender], skip_watched: bool = False):
        await self._redis_client.lpush(
            self.USER_TG_NOTIFICATIONS_TENDERS_KEY.format(user_id=user_id),
            *[
                TenderMessage(id=t.internal_id, skip_watched=skip_watched).model_dump_json()
                for t in tenders
            ],
        )

    async def get_tg_notification_tenders_users_ids(self):
        result = await self._redis_client.keys(self.USER_TG_NOTIFICATIONS_TENDERS_SEARCH)

        return [k.decode().replace(self.USER_TG_NOTIFICATIONS_TENDERS_PATTERN, "") for k in result]

    async def pop_tg_notification_tender_by_user_id(self, user_id: str) -> TenderMessage | None:
        b_value = await self._redis_client.rpop(
            self.USER_TG_NOTIFICATIONS_TENDERS_KEY.format(user_id=user_id)
        )

        return TenderMessage.model_validate_json(b_value) if b_value else None

    async def get_all_tg_notification_tenders_by_user_id(self, user_id: str) -> list[TenderMessage]:
        tenders_messages =  await self._redis_client.lrange(
            self.USER_TG_NOTIFICATIONS_TENDERS_KEY.format(user_id=user_id),
            0, -1
        )

        return [TenderMessage.model_validate_json(m) for m in tenders_messages]
