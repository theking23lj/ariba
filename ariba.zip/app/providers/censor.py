# Words that might trigger Azure filtering. Note that they are case-sensitive
REPLACEMENTS = {
    "свиноферм": "свино ферм"
}

def censor(string: str):
    for key, value in REPLACEMENTS.items():
        string = string.replace(key, value)
    return string
