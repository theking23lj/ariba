import asyncio
from langchain.callbacks import get_openai_callback
from msgraph.generated.models.message import Message
from msgraph.generated.users.item.messages.messages_request_builder import MessagesRequestBuilder
from pydantic import BaseModel, PrivateAttr
from agentcore.messages import AgentMessage

from bot_tasks_manager import task_manager, TaskRunningType, TaskSecureType
from chats.email_admin_chat import EmailAdminChat
from chats.email_user_chat import EmailUserChat
from depends import get_graph_client
from message_handler import MessageHandler
from providers.censor import censor
from providers.email.models import AdminEmailMessage, UserEmailMessage
from providers.email.models import BaseEmailMessage
from repos.email_admin import EmailAdminMongoRepository
from settings import settings, app_config
from token_handler import TokenHandler
from utils.logger import logger_manager

logger = logger_manager.get_logger()



class EmailListener(BaseModel):
    message_handler: MessageHandler
    _is_stopped: bool = PrivateAttr(True)
    _running_task: asyncio.Task | None = PrivateAttr(None)

    async def _reply_message_task(self, email_address: str, conversation_id: str) -> None:
        logger.info(f"Starting reply_message_task for {email_address}")
        user_chat = await EmailUserChat.build(email_address, conversation_id)
        await self.message_handler.handle_user_message(user_chat)

    async def _handle_email_from_admin(self, message: AdminEmailMessage) -> None:
        if message is None:
            logger.warning("get None instead object AdminEmailMessage")
            return

        message.text = censor(message.text)

        admin_repo = await EmailAdminMongoRepository.get_instance()
        thread_id = await admin_repo.find_thread_id(message)
        if thread_id is None:
            # New direct message from admin

            thread = await admin_repo.create_thread()
            message.thread_id = thread.thread_id
            await admin_repo.add_message(message)
            admin_chat = await EmailAdminChat.build(thread.thread_id)
            await MessageHandler().handle_admin_message(admin_chat)
        else:
            # The message from admin is in the existing thread

            thread = await admin_repo.get_thread_by_id(thread_id)
            message.thread_id = thread_id
            await admin_repo.add_message(message)
            admin_chat = await EmailAdminChat.build(thread_id)

            if thread.user_id and thread.chat_type and thread.chat_id:
                # Admin responded to bot's question
                await MessageHandler().handle_admin_response(thread.user_id, thread.chat_type, thread.chat_id, admin_chat, message.text)
            else:
                # Admin wrote a direct message in the existing thread
                if thread.user_id or thread.chat_type or thread.chat_id:
                    logger.warning(f"Thread data is corrupted {thread.user_id} {thread.chat_type} {thread.chat_id}")
                await MessageHandler().handle_admin_message(admin_chat)


    async def _handle_email_from_user(self, message: 'UserEmailMessage') -> None:
        from repos.email_user import EmailUserMongoRepository
        if message is None:
            logger.warning("get None instead object UserEmailMessage")
            return

        message.text = censor(message.text)

        repo = await EmailUserMongoRepository.get_instance()
        await repo.save_message(message)

        if message.from_email == settings.EMAIL_PRINCIPAL_NAME:
            return

        email_user = await repo.get_user_by_chat_id(message.from_email)
        if email_user.is_paused:
            logger.info(f"User {message.from_email} is paused")
            return

        tokens_data = await repo.get_tokens_data(message.from_email)
        total_tokens_cost = tokens_data['prompt_tokens_cost'] + tokens_data['completion_tokens_cost']

        if total_tokens_cost >= settings.PER_USER_BUDGET:
            await repo.set_user_pause_status(message.from_email, True)

            user_chat = await EmailUserChat.build(message.from_email, message.chat_id)
            user_chat.append(AgentMessage(app_config.support_contacts.message))
            await user_chat.commit()

        else:
            with get_openai_callback() as cb:
                try:
                    # this message is an incoming message, so message.chat_id is not None
                    await self._reply_message_task(message.from_email, message.chat_id) # type: ignore
                except asyncio.CancelledError:
                    logger.info("Task was cancelled")
                finally:
                    await TokenHandler.handle_token_usage(
                        repo, message.from_email, cb.prompt_tokens, cb.completion_tokens
                    )

    async def mark_email_as_read(self, email_id: str) -> None:
        reply = await get_graph_client().users.by_user_id(settings.EMAIL_PRINCIPAL_NAME).mail_folders.by_mail_folder_id(
            'Inbox'
        ).messages.by_message_id(email_id).patch(
            body=Message(
                is_read=True
            )
        )

    async def _check_email(self) -> None:
        request_config = MessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration(
            query_parameters=MessagesRequestBuilder.MessagesRequestBuilderGetQueryParameters(
                filter="isRead eq false",
                select = ["body", "uniqueBody", "sender", "from", "toRecipients", "subject", "sentDateTime", "conversationId"]
            )
        )
        request_config.headers.add("Prefer", "outlook.body-content-type='text'")
        result = await get_graph_client().users.by_user_id(
            settings.EMAIL_PRINCIPAL_NAME
        ).mail_folders.by_mail_folder_id('Inbox').messages.get(request_config)
        if not result:
            return

        messages = result.value
        if not messages:
            logger.debug("There is no any new mails")
            return

        for message_data in messages:
            email_id = message_data.id
            sender_email = message_data.from_.email_address.address
            logger.info(f"Raw data of new email: {message_data}")

            if sender_email == settings.ADMIN_EMAIL:
                email_message = AdminEmailMessage.from_fetch_response(message_data, "user")
                coroutine = self._handle_email_from_admin(email_message)
            else:
                email_message = UserEmailMessage.from_fetch_response(message_data, "user")
                coroutine = self._handle_email_from_user(email_message)

            task_manager.register_chat_instruction(
                'email',
                sender_email,
                coroutine,
                TaskRunningType.QUEUE,
                TaskSecureType.SAFETY,
            )
            await self.mark_email_as_read(email_id)

    def start(self):
        self._is_stopped = False
        self._running_task = asyncio.create_task(self._run())

    def stop(self):
        self._is_stopped = True
        self._running_task.cancel()

    async def _run(self) -> None:
        while not self._is_stopped:
            try:
                logger.info("Checking for new emails")
                await self._check_email()
            except Exception as e:
                logger.exception(e)
            finally:
                await asyncio.sleep(30)

        logger.info("Email checking is stopped.")

    class Config:
        arbitrary_types_allowed = True
