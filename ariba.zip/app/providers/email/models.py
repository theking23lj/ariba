import re
import uuid
from typing import ClassVar, Self

from msgraph.generated.models.message import Message
from pydantic import BaseModel, Field

from providers.base.models import BaseMHPMessage, BaseUser

class EmailUser(BaseUser):
    chat_id: str
    sender_name: str


class AdminThread(BaseModel):
    user_id: str | None = None
    chat_type: str | None = None
    chat_id: str | None = None
    is_closed: bool = False
    thread_id: str = Field(default_factory=lambda: str(uuid.uuid4()))

def replace_safelinks(text: str):
    pattern = r"<https://\w+\.safelinks\.protection\.outlook\.com/[^>]+>"
    return re.sub(pattern, "", text)

def remove_external_sender(body: str):
    return body.replace("Зовнішній відправник | External sender\r\n", "")

class BaseEmailMessage(BaseMHPMessage):
    """class to parse message from email client, and store it in database"""

    message_id: str | None = None  # Set after sending email
    unique_text: str
    from_email: str
    sender_name: str
    to_email: str
    subject: str | None
    in_reply_to: str | None = None
    forward_message_id: str | None = None
    date: str | None = None

    @classmethod
    def from_fetch_response(cls, graph_response: Message, msg_type) -> Self:
        sender_name = graph_response.sender.email_address.name
        to_email = graph_response.to_recipients[0].email_address.address
        subject = graph_response.subject
        date = graph_response.sent_date_time.strftime("%Y-%m-%d %H:%M:%S")
        body = ""
        unique_body = ""
        if graph_response.body and graph_response.body.content:
            body = replace_safelinks(remove_external_sender(graph_response.body.content)).strip()
        if graph_response.unique_body and graph_response.unique_body.content:
            unique_body = replace_safelinks(remove_external_sender(graph_response.unique_body.content)).strip()
        
        return cls(
            _id= None,
            message_id=graph_response.id,
            chat_id=graph_response.conversation_id,
            from_email=graph_response.from_.email_address.address,
            sender_name=sender_name,
            to_email=to_email,
            subject=subject,
            # in_reply_to is used only for messages from bot to user
            in_reply_to=None,
            text=BaseMHPMessage.text_filter(body),
            unique_text = BaseMHPMessage.text_filter(unique_body),
            date=date,
            type=msg_type,
        )

class UserEmailMessage(BaseEmailMessage):
    def get_user(self) -> EmailUser:
        return EmailUser(
            chat_id=self.from_email,
            sender_name=self.sender_name,
        )


class AdminEmailMessage(BaseEmailMessage):
    thread_id: str | None = None