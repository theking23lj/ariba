from typing import Self
from datetime import datetime
from telebot.types import Message
from pydantic import Field

from providers.base.models import BaseMHPMessage, BaseUser


class TgUser(BaseUser):
    chat_id: str
    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None


class TgMessage(BaseMHPMessage):
    # exclude True to not save them in db
    username: str | None = Field(None, exclude=True)
    first_name: str | None = Field(None, exclude=True)
    last_name: str | None = Field(None, exclude=True)

    @classmethod
    def from_telebot_message(cls, message: Message, msg_type: str, content_type: str = "text") -> Self:
        return cls(
            chat_id=str(message.from_user.id),
            text=BaseMHPMessage.text_filter(message.text),
            date=datetime.fromtimestamp(message.date).isoformat(),
            type=msg_type,
            content_type=content_type,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name,
        )

    def get_user(self) -> TgUser:
        return TgUser(
            chat_id=self.chat_id,
            username=self.username,
            first_name=self.first_name,
            last_name=self.last_name,
        )