import asyncio
import weakref
from contextlib import contextmanager
from datetime import datetime

import telebot.async_telebot as telebot
from langchain.callbacks import get_openai_callback

from bot_tasks_manager import task_manager, TaskRunningType, TaskSecureType
from chats.tg_chat import TgChat
from depends.telegram import TgClient
from message_handler import MessageHandler
from providers.tg.models import TgMessage
from providers.censor import censor
from repos.tg_user import TgUserMongoRepository
from settings import settings, app_config
from token_handler import TokenHandler
from utils.logger import logger_manager

logger = logger_manager.get_logger()


class TgListener:
    tg_client: TgClient
    message_handler: MessageHandler

    def __init__(self, tg_client: TgClient, message_handler: MessageHandler):
        self.tg_client = tg_client
        self.message_handler = message_handler

        self.tg_client.telebot.add_message_handler(
            {'function': self.start_chat_handler, 'filters':
                {'commands': ['start']}
             })
        self.tg_client.telebot.add_message_handler(
            {'function': TgAllMessagesHandler(weakref.ref(self)), 'filters':
                {'chat_types': ['private'], 'content_types': ['text']}
             }
        )

    async def reply_message_task(self, chat_id: str) -> None:
        logger.info(f"Starting reply_message_task for {chat_id}")
        user_chat = await TgChat.build(chat_id)
        await self.message_handler.handle_user_message(user_chat)

    async def send_typing_event(self, chat_id: str):
        logger.info(f"Sending typing event to chat {chat_id}")
        # while task_manager.is_typing_task_running(chat_type="tg", chat_id=chat_id):
        while True:
            await self.tg_client.telebot.send_chat_action(chat_id, action='typing')
            await asyncio.sleep(5)
            logger.debug(f"Typing event sent to chat {chat_id}, sleeping for 5 seconds")

    @contextmanager
    def typing_context(self, chat_id: str):
        typing_task = asyncio.create_task(self.send_typing_event(chat_id))
        yield
        typing_task.cancel()

    async def handle_message(self, chat_id: str, user_repo: TgUserMongoRepository):
        with get_openai_callback() as cb:
            with self.typing_context(chat_id):
                try:
                    await self.reply_message_task(chat_id)
                except asyncio.CancelledError:
                    logger.info("Task was cancelled")
                finally:
                    await TokenHandler.handle_token_usage(
                        user_repo, chat_id, cb.prompt_tokens, cb.completion_tokens
                    )

    async def start_chat_handler(self, message: telebot.types.Message) -> None:
        greeting = "Вітаю! Якщо у вас є питання по участі в тендерах МХП - готова Вам допомогти."
        await self.tg_client.telebot.send_message(chat_id=message.chat.id, text=greeting)
        logger.info(f"Start conversation with user ID {message.chat.id}")


class TgAllMessagesHandler:

    def __init__(self, tg_listener_ref):
        self.tg_listener_ref = tg_listener_ref

    async def __call__(self, message: telebot.types.Message):
        logger.info(self.tg_listener_ref)
        logger.info(self.tg_listener_ref())
        tg_listener_obj = self.tg_listener_ref()
        if (
            message.from_user is None or
            message.from_user.is_bot
        ):
            logger.info(
                "Message from %s ignored.",
                'bot' if message.from_user and message.via_bot else 'Telegram'
            )
            return

        chat_id = str(message.from_user.id)
        logger.info(f"Got message from {chat_id} with text: {message.text}")
        repo = await TgUserMongoRepository.get_instance()

        if message.text:
            message.text = censor(message.text)

        tg_message = TgMessage.from_telebot_message(message, msg_type="user")
        if message.reply_to_message:
            message.text = message.reply_to_message.text
            reply_tg_message = TgMessage.from_telebot_message(message, msg_type="user", content_type="forward")
            await repo.save_message(reply_tg_message)
        elif message.forward_from:
            tg_message = TgMessage.from_telebot_message(message, msg_type="user", content_type="forward")
        await repo.save_message(tg_message)

        tg_user = await repo.get_user_by_chat_id(chat_id)
        if tg_user.is_paused:
            logger.info(f"User {chat_id} is paused")
            return

        tokens_data = await repo.get_tokens_data(chat_id)
        total_tokens_cost = tokens_data['prompt_tokens_cost'] + tokens_data['completion_tokens_cost']

        if total_tokens_cost >= settings.PER_USER_BUDGET:
            tg_user.is_paused = True
            repo = await TgUserMongoRepository.get_instance()
            await repo.set_user_pause_status(chat_id, True)

            result = await tg_listener_obj.tg_client.send_message(
                chat_id, app_config.support_contacts.message
            )
            sent_message = TgMessage(
                chat_id=chat_id,
                text=app_config.support_contacts.message,
                date=datetime.now().isoformat(),
                type='agent',
            )
            await repo.save_message(sent_message)
            return

        task_manager.register_chat_instruction(
            'tg',
            chat_id,
            tg_listener_obj.handle_message(chat_id, repo),
            TaskRunningType.IMMEDIATELY,
            TaskSecureType.CAN_BREAK,
        )
