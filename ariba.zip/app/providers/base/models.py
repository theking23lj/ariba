from bson import ObjectId
from pydantic import Field
from agentcore.providers.messages import BaseProviderMessage, BaseProviderUser

from tenders.models import Tender

class BaseMHPMessage(BaseProviderMessage):
    db_msg_id: ObjectId | None = Field(None, alias="_id", exclude=True)
    chat_id: str

    @staticmethod
    def text_filter(message: str) -> str:
        message = message.replace("<|", "< | ")
        message = message.replace("|>", " | >")
        return message


class BaseUser(BaseProviderUser):
    #TODO rename to user_id or id
    chat_id: str
    chosen_category_ids: list[str] = []
    watched_tender_ids: list[str] = []
    waiting_tender_ids: list[str] = []  # There are tenders that didn't receive confirmation of sending to the user.
    is_paused: bool = False

    def filter_tenders(
        self,
        tenders: list[Tender],
        pending_tender_ids: list[str],
        skip_watched: bool = False,
    ) -> list[Tender]:
        return [
            t for t in tenders
            if self.is_user_subscribed_to_tender(t) and
               (skip_watched or t.internal_id not in self.watched_tender_ids) and
               t.internal_id not in pending_tender_ids
        ]

    def is_user_subscribed_to_tender(self, tender: Tender) -> bool:
        tender_categories = {c.unique_name for c in tender.commodities}
        user_categories = set(self.chosen_category_ids)

        if user_categories.intersection(tender_categories):
            return True

        for u_c in user_categories:
            if any(filter(lambda t_c: t_c.startswith(u_c), tender_categories)):
                return True

        return False
