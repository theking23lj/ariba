import asyncio 
from motor.motor_asyncio import AsyncIOMotorClient
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from settings import settings

def upgrade(db):
    db.admin_threads.delete_many({})
    db.email_messages.delete_many({})
    db.admin_thread_messages.delete_many({})
    db.events.delete_many({})

async def main():
    client = AsyncIOMotorClient(settings.MONGO_URI)
    await client.admin.command('ping')

    db = client.get_database(settings.MONGO_DB_NAME)
    upgrade(db)
    print("Success")

asyncio.run(main())