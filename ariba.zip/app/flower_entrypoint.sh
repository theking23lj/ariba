#!/bin/sh

echo "Starting flower server"
exec uvicorn health_check:health_check_app --host 0.0.0.0 --port 80 &
celery -A celery_worker flower --port=5555
