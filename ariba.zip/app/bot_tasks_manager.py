import asyncio
from asyncio import Task
from collections import defaultdict
from enum import Enum
from typing import ClassVar, Coroutine

from pydantic import BaseModel

from utils.logger import logger_manager

logger = logger_manager.get_logger()


class TaskRunningType(Enum):
    IMMEDIATELY = "IMMEDIATELY"
    QUEUE = "QUEUE"


class TaskSecureType(Enum):
    SAFETY = "SAFETY"
    CAN_BREAK = "CAN_BREAK"


class BaseInstruction(BaseModel):
    running_type: TaskRunningType = TaskRunningType.QUEUE
    secure_type: TaskSecureType = TaskSecureType.SAFETY

    class Config:
        arbitrary_types_allowed = True


class ChatInstruction(BaseInstruction):
    coroutine: Coroutine


class BotTask(BaseInstruction):
    task: Task


class ChatHandler:
    def __init__(self, chat_id: str):
        self.chat_id = chat_id
        self.current_task: BotTask | None = None
        self.queue_instructions: dict[TaskRunningType, list[ChatInstruction]] = defaultdict(list)

    def add_instruction(self, new_instruction: ChatInstruction):
        match new_instruction.running_type:
            case TaskRunningType.IMMEDIATELY:
                instructions = self.queue_instructions[new_instruction.running_type]
                if instructions:
                    last_instr = instructions[-1]
                    if last_instr.secure_type == TaskSecureType.SAFETY:
                        # Don't touch SAFETY instructions
                        instructions.append(new_instruction)
                    else:
                        # If not SAFETY, we can replace last instruction
                        last_instr.coroutine.close()
                        instructions.pop()
                        instructions.append(new_instruction)
                else:
                    instructions.append(new_instruction)
            case TaskRunningType.QUEUE:
                self.queue_instructions[new_instruction.running_type].append(new_instruction)

        self.try_run()

    def try_run(self):
        if self.current_task is not None:
            match self.current_task.secure_type:
                case TaskSecureType.SAFETY:
                    return
                case TaskSecureType.CAN_BREAK:
                    logger.info(f"Try cancel current task - {self.current_task}")
                    self.current_task.task.cancel()
            return

        instruction = None
        for running_type in (TaskRunningType.IMMEDIATELY, TaskRunningType.QUEUE):
            # first immediately, second by queue
            instructions = self.queue_instructions[running_type]
            if instructions:
                instruction = instructions.pop(0)
                break

        if instruction is None:
            return

        task = asyncio.create_task(instruction.coroutine)
        task.add_done_callback(self.task_callback)
        self.current_task = BotTask(
            task=task,
            running_type=instruction.running_type,
            secure_type=instruction.secure_type,
        )

    def task_callback(self, task: Task):
        logger.debug(f"Task done. chat_id - {self.chat_id} - {task}")
        self.current_task = None
        task.remove_done_callback(self.task_callback)
        if ex := task.exception():
            logger.error("Task failed", exc_info=ex)

        self.try_run()


class BotTasksManager(BaseModel):
    chat_handlers: ClassVar[dict[str, dict[str, ChatHandler]]] = {
        "tg": {},
        "email": {},
    }

    def register_chat_instruction(
        self,
        chat_type: str,
        chat_id: str,
        coroutine: Coroutine,
        running_type: TaskRunningType,
        secure_type: TaskSecureType,
    ) -> None:
        handler = self.chat_handlers[chat_type].get(chat_id)
        if handler is None:
            handler = self.chat_handlers[chat_type][chat_id] = ChatHandler(chat_id)

        handler.add_instruction(
            ChatInstruction(
                coroutine=coroutine,
                running_type=running_type,
                secure_type=secure_type,
            )
        )


task_manager = BotTasksManager()

__all__ = [
    "task_manager",
    "ChatInstruction",
    "TaskRunningType",
    "TaskSecureType",
    "ChatHandler",
]
