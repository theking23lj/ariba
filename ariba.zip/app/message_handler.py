from agentcore.messages import SysMessage
from agentcore.plugins.knowledge_base import KnowledgeBase
from pydantic import BaseModel

from agents.admin_agent import AdminAgent
from agents.main_agent import MainAgent
from agents.roles_manager import get_roles_mgr
from agents.utils import RoleNames
from bot_tasks_manager import task_manager, TaskSecureType, TaskRunningType
from chats.base import BaseUserChat
from chats.email_admin_chat import EmailAdminChat
from chats.email_user_chat import EmailUserChat
from chats.tg_chat import TgChat
from repos.knowledge_base import KnowledgeBaseRepository
from tenders.repo import TenderRepository
from utils.logger import logger_manager
from repos.base import BaseLanguageRepository

logger = logger_manager.get_logger()

ADMIN_ANSWER_WRAPPER = "Now you are talking to a client. Pass on the information that the manager wrote:\n"


class MessageHandler(BaseModel):

    knowledge_base: KnowledgeBase | None = None

    async def get_knowledge_base(self):
        if self.knowledge_base is None:
            KB_repo = await KnowledgeBaseRepository.get_instance()
            self.knowledge_base = get_roles_mgr().get_role(RoleNames.KNOWLEDGE_BASE, KB_repo)

        return self.knowledge_base
    
    async def _create_user_chat(self, user_id: str, chat_type: str, chat_id: str) -> BaseUserChat:
        if chat_type == "tg":
            return await TgChat.build(chat_id)
        elif chat_type == "email":
            return await EmailUserChat.build(user_id, chat_id)
        else:
            raise Exception(f"Unsupported chat type {chat_type}")

    async def handle_user_message(self, user_chat: BaseUserChat) -> None:
        try:
            await MainAgent(
                user_chat=user_chat,
                knowledge_base=await self.get_knowledge_base(),
                tender_repo=await TenderRepository.get_instance(),
                language_repo=await BaseLanguageRepository.get_instance()
            ).reply()
        except Exception as e:
            logger.exception("Handling user message has failed", exc_info=e)

    async def handle_admin_message(self, admin_chat: EmailAdminChat) -> None:
        try:
            await AdminAgent(
                admin_chat=admin_chat,
                knowledge_base_repo=await KnowledgeBaseRepository.get_instance(),
            ).answer()
        except Exception as e:
            logger.exception("Handling admin message has failed", exc_info=e)

    async def handle_admin_response(self, user_id: str, user_chat_type: str, user_chat_id: str, admin_chat: EmailAdminChat, admin_message: str) -> None:
        await self.handle_admin_message(admin_chat)

        user_chat = await self. _create_user_chat(user_id, user_chat_type, user_chat_id)
        user_chat.append(SysMessage(ADMIN_ANSWER_WRAPPER + admin_message))
        await user_chat.commit()

        task_manager.register_chat_instruction(
            user_chat_type,
            user_chat_id,
            self._send_admin_reply(user_id, user_chat_type, user_chat_id),
            TaskRunningType.IMMEDIATELY,
            TaskSecureType.CAN_BREAK,
        )

    async def _send_admin_reply(self, user_id: str, user_chat_type: str, user_chat_id: str):
        try:
            user_chat = await self._create_user_chat(user_id, user_chat_type, user_chat_id)

            await MainAgent(
                user_chat=user_chat,
                knowledge_base=await self.get_knowledge_base(),
                tender_repo=await TenderRepository.get_instance(),
                language_repo=await BaseLanguageRepository.get_instance()
            ).pass_admin_response()
        except Exception as e:
            logger.exception("Handling admin message has failed", exc_info=e)

    class Config:
        arbitrary_types_allowed = True
