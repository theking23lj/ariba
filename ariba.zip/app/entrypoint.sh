#!/bin/sh

# Stop on any error
set -e

# Get current date and time in YYYYMMDD-HHMMSS format
current_datetime=$(date +%Y%m%d-%H%M%S)

if [ "$USE_DEBUGGER" = "true" ]; then
    echo "Starting debug mode"
    python -m debugpy --listen 0.0.0.0:8002 --wait-for-client -m uvicorn main:app --host 0.0.0.0 --port 8001 --reload --forwarded-allow-ips='*' --proxy-headers
elif [ "$MEMRAY" = "true" ]; then
    echo "Memray enabled"
    # Install Memray if not already installed
    python3 -m pip install memray
    # Use the current date and time in the dump file name
    python -m memray run -o "memray/dump_$current_datetime.bin" main.py 

else
    echo "Starting production mode"
    # Run pre-migration Python script
    python pre_migration.py
    sh migrate.sh
    exec uvicorn main:app --host 0.0.0.0 --port 80 --reload --forwarded-allow-ips='*' --proxy-headers 
fi
