from typing import Any, Dict, List

from langchain.chains.llm import LLMChain
from langchain.prompts import PromptTemplate
from langchain.schema import BaseMemory
from langchain.schema.language_model import BaseLanguageModel

from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, SystemMessage, to_langchain_messages
from langchain.schema import HumanMessage, AIMessage, FunctionMessage, SystemMessage
from langchain.schema import BaseMessage



class UpperLowerLimitSummaryBufferMemory(BaseMemory):
    """Buffer with summarizer for storing conversation memory."""

    user_prompt: str
    upper_limit: int = 3000
    lower_limit: int = 1500
    llm: BaseLanguageModel

    raw_messages: list[AbstractMessage] = []
    messages: list[AbstractMessage] = []
    moving_summary_buffer: str = ""

    history_template: HistoryTemplate
    history_key: str
    raw_history_key: str
    functions: dict = {}

    @property
    def memory_variables(self) -> List[str]:
        return [self.history_key, self.raw_history_key]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Return history buffer."""
        buffer = self.messages
        if self.moving_summary_buffer != "":
            first_messages: List[AbstractMessage] = [SystemMessage(self.moving_summary_buffer)]
            buffer = first_messages + buffer
        return {
            self.history_key: to_langchain_messages(buffer),
            self.raw_history_key: to_langchain_messages(self.raw_messages),
        }

    # unlike LangChain's memory this one does not save messages to memory automatically
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """Save context from this conversation to buffer."""
        pass

    def set(self, messages: list[AbstractMessage]):
        self.raw_messages = messages.copy()
        self.messages = messages.copy()
        self.prune()

    def append(self, message: AbstractMessage):
        self.raw_messages.append(message)
        self.messages.append(message)
        self.prune()

    def prune(self) -> None:
        """Prune buffer if it exceeds upper token limit"""
        buffer = to_langchain_messages(self.messages)
        curr_buffer_length = self.llm.get_num_tokens_from_messages(buffer)
        if curr_buffer_length > self.upper_limit:
            pruned_memory: list[AbstractMessage] = []
            while curr_buffer_length > self.lower_limit:
                buffer.pop(0)
                pruned_memory.append(self.messages.pop(0))
                curr_buffer_length = self.llm.get_num_tokens_from_messages(buffer)
            self.moving_summary_buffer = self.predict_new_summary(pruned_memory, self.moving_summary_buffer)

    def predict_new_summary(self, messages: List[AbstractMessage], existing_summary: str) -> str:
        new_lines = self.history_template.format(messages)

        chain = LLMChain(llm=self.llm, prompt=PromptTemplate.from_template(self.user_prompt))
        # has to be blocking right now to prevent race condition
        # TODO: make it async
        return chain.predict(summary=existing_summary, new_lines=new_lines)

    def clear(self) -> None:
        self.messages = []
        self.raw_messages = []
        self.moving_summary_buffer = ""
