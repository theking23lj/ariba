from dataclasses import dataclass
from typing import Any
from agentcore.function import Function
from agentcore.messages import AbstractMessage


@dataclass
class Action:
    message: AbstractMessage


@dataclass
class Call(Action):
    text: str
    function: Function
    kwargs: dict


@dataclass
class Finish(Action):
    text: str


class Continue(Action):
    ...
