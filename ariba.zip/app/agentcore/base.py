import functools
import inspect
from pathlib import Path
from typing import Any, Type
from langchain.prompts.chat import (
    ChatPromptTemplate,
)
from langchain.tools import StructuredTool
from langchain_core.utils.function_calling import convert_to_openai_function
from agentcore.actions import Action, Call, Finish
from agentcore.config import BaseLLMConfig, get_global_config
from agentcore.messages import (
    AbstractMessage,
    FunctionCall,
    AgentMessage,
    from_langchain_ai_message,
)
from agentcore.function import Function, FunctionOutput
from agentcore.utils import args_to_dict
from langsmith import traceable


def function_to_tool(function: Function) -> StructuredTool:
    return StructuredTool(
        name=function.name,
        func=function.func,
        description=function.desc,
        args_schema=function.args_schema,
    )


def str_to_type(t: Type, s: str):
    if t == str or t == Any or t == inspect._empty:
        return s
    if t == bool:
        s = s.strip().replace('"', "")
        if s == "True" or s == "true":
            return True
        elif s == "False" or s == "false":
            return False
        else:
            raise Exception(f"could not convert string to bool: '{s}'")
    try:
        return t(s)
    except Exception:
        raise Exception(f"could not convert string to {t}: '{s}'")


class BaseRole:
    def __init__(self, prompt_template: ChatPromptTemplate, 
                 functions: list[Function] = [], 
                 config: BaseLLMConfig | None = None,
                 forbid_functions: bool = False,
                 ):
        self.prompt_template = prompt_template
        self.functions = functions
        self.config = config if config else get_global_config()
        self.llm = self.config.get_llm()
        self.forbid_functions = forbid_functions
        if self.functions and len(self.functions) > 0:
            tools = [function_to_tool(function) for function in self.functions]
            self.functions_to_names = dict(
                [(function.name, function) for function in self.functions]
            )
            # TODO format differently depending on the LLM type
            self.llm = self.llm.bind(
                functions=[convert_to_openai_function(tool) for tool in tools]
            )

    def get_local_file(self, filename):
        class_file_dir = Path(inspect.getfile(self.__class__)).parent.resolve()
        with open(class_file_dir / filename, encoding="utf-8") as f:
            return f.read()

    def local_file_exits(self, filename: str) -> bool:
        filepath = Path(inspect.getfile(self.__class__)).parent.resolve() / filename
        if filepath.is_file():
            return True
        else:
            return False

    def _message_to_action(self, message: AbstractMessage) -> Action:
        if isinstance(message, FunctionCall):
            if self.functions is None or len(self.functions) == 0:
                raise Exception(
                    "LLM returned FunctionCall, but no functions are registered"
                )  # TODO improve exception
            function = self.functions_to_names.get(message.func_name)
            if function:
                # args = function.args_schema.parse_obj(message.args)
                # TODO validate args with function.args_schema
                return Call(message, message.text, function, message.args)
            else:
                # TODO add logging
                # self.llm.invoke(messages)
                # warning = InvalidTool().run(
                #     {
                #         "requested_tool_name": message.func_name,
                #         "available_tool_names": list(self.functions_to_names.keys()),
                #     },
                #     verbose=False,
                #     color=None,
                # )
                # messages.append(langchain_message)
                # messages.append(FunctionMessage(name=message.func_name, content=warning))
                raise Exception(
                    f"LLM wanted to call unknown function {message.func_name}. Available functions: {list(self.functions_to_names.keys())}"
                )  # TODO improve exception
        elif isinstance(message, AgentMessage):
            return Finish(message, message.text)
        else:
            raise Exception(
                "Langchain LLM invoke returned unexpected type of message"
            )  # TODO improve exception

    async def _aplan(self, **kwargs) -> Action:
        messages = self.prompt_template.format_messages(**kwargs)
        # TODO: also it would be cool to deserialize content to the return type of the func
        kwargs = {}
        if self.forbid_functions:
                kwargs["function_call"] = "none"
        message = from_langchain_ai_message(await self.llm.ainvoke(messages, **kwargs))
        return self._message_to_action(message)


def aplan(func):
    # TODO check that the func's return type is Action or Any
    @traceable(name=func.__qualname__)
    @functools.wraps(func)
    async def wrapper(self: BaseRole, *args, **kwargs) -> Action:
        sig = inspect.signature(func)
        kwargs = args_to_dict(sig, *args, **kwargs)
        # TODO validate kwargs
        return await self._aplan(**kwargs)

    return wrapper


def arun(func):
    @traceable(name=func.__qualname__)
    @functools.wraps(func)
    async def wrapper(self: BaseRole, *args, **kwargs) -> FunctionOutput:
        sig = inspect.signature(func)
        kwargs = args_to_dict(sig, *args, **kwargs)
        # TODO validate kwargs
        # TODO decide whether people will need to write custom code for plan method in the classes derived from BaseRole
        #     if yes, then this implementation will ignore their custom code
        action = await self._aplan(**kwargs)
        if isinstance(action, Finish):
            return action.text
        elif isinstance(action, Call):
            return await action.function.arun(action.text, **action.kwargs)
        else:
            raise Exception("Unknown action")  # TODO improve exception

    return wrapper
