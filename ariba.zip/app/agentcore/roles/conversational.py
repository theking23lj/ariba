from langchain.prompts import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    MessagesPlaceholder,
)
from agentcore.config import BaseLLMConfig, get_global_config
from agentcore.function import Function
from agentcore.base import BaseRole, BaseRole


class Conversational(BaseRole):
    HISTORY = "history"

    def __init__(
        self,
        system: str | None = None,
        functions: list[Function] = [],
        config: BaseLLMConfig | None = None,
        forbid_functions: bool = False,
    ):
        system = system if system else self.get_local_file("system.md")
        prompt_template = ChatPromptTemplate.from_messages(
            [
                SystemMessagePromptTemplate.from_template(template=system),
                MessagesPlaceholder(variable_name=self.HISTORY),
            ]
        )

        config = config if config else get_global_config()
        super().__init__(prompt_template=prompt_template, 
                         functions=functions, 
                         config=config,
                         forbid_functions=forbid_functions,
                         )