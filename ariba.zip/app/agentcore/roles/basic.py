from langchain.prompts import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from agentcore.config import BaseLLMConfig, get_global_config
from agentcore.function import Function
from agentcore.base import BaseRole


class BasicRole(BaseRole):
    def __init__(
        self,
        system: str | None = None,
        user: str | None = None,
        functions: list[Function] = [],
        config: BaseLLMConfig | None = None,
        forbid_functions: bool = False,
    ):
        prompt_template = ChatPromptTemplate(input_variables=[], messages=[])
        if system is None:
            system_file = "system.md"
            if self.local_file_exits(system_file):
                prompt_template += SystemMessagePromptTemplate.from_template(template=self.get_local_file(system_file)),
        else:
            prompt_template += SystemMessagePromptTemplate.from_template(template=system),
        
        if user is None:
            user_file = "user.md"
            if self.local_file_exits(user_file):
                prompt_template += HumanMessagePromptTemplate.from_template(template=self.get_local_file(user_file)),
        else:
            prompt_template += HumanMessagePromptTemplate.from_template(template=user),

        user_file = "user.md"

        config = config if config else get_global_config()
        super().__init__(prompt_template=prompt_template, 
                         functions=functions, 
                         config=config,
                         forbid_functions=forbid_functions,
                         )
