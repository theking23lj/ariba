from langchain.schema import BaseMessage
from agentcore.base import arun
from agentcore.function import Break
from agentcore.messages import to_langchain_messages, AbstractMessage, SysMessage
from agentcore.roles.conversational import Conversational
from agentcore.config import get_global_config
import json
import logging
import re


class Analyzer(Conversational):
    role_name = "ANALYZER"

    def __init__(self, unfilled_example: dict, fulfilled_example: dict, partfilled_example: dict, history: list[AbstractMessage] = None):
        super().__init__(
            system=" ",
            config=get_global_config().copy_with(temperature=.1, log_name=Analyzer.role_name),
        )
        self.history = history
        self.metadata = {}

        self.unfilled_example = unfilled_example
        self.fulfilled_example = fulfilled_example
        self.partfilled_example = partfilled_example

    async def analyze(self, session_data: dict) -> dict:
        self.history = [message for message in self.history if message.text is not None]

        self.history.append(
            SysMessage(
                text=self.get_local_file("analyzer.md").format(
                    unfilled_example=self.unfilled_example,
                    filled_example=self.fulfilled_example,
                    partfilled_example=self.partfilled_example,
                )
            )
        )

        r = await self._areply(history=to_langchain_messages(self.history))
        reply = r.text if isinstance(r, Break) else r

        try:
            reply = reply.replace("'", "\"")
            reply = re.search(r'\{.*\}', reply, re.DOTALL)
            if reply:
                reply = reply.group(0)

            self.metadata = json.loads(reply)
            self.metadata = {key: self.metadata[key] for key in self.metadata if key in session_data}
            for key, value in self.metadata.items():
                session_data[key] = self.metadata.get(key, None)
            if self.metadata == {}:
                return session_data
            return self.metadata
        except Exception as ex:
            logging.warning(f"Error in {Analyzer.role_name}: {ex}")
            return session_data

    @arun
    async def _areply(self, history: list[BaseMessage]) -> str:
        ...
