You should analyze the dialogue and return the information about user in json format. 
Leave unknown data missing (""). Use the example form to fill it out.

All possible fields:

{unfilled_example}

EXAMPLES ANSWER:
{filled_example}

{partfilled_example}