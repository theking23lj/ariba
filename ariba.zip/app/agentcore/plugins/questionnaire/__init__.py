from langchain.schema import BaseMessage
from agentcore.base import arun
from agentcore.function import Break
from agentcore.messages import to_langchain_messages, AbstractMessage, SysMessage
from agentcore.roles.conversational import Conversational
from agentcore.config import get_global_config
from agentcore.plugins.questionnaire.analyzer import Analyzer


class Questionnaire(Conversational):
    role_name = "QUESTIONNAIRE"

    def __init__(self, questionnaire_sysprompt, history: list[AbstractMessage] = None):
        super().__init__(
            system=" ",
            config=get_global_config().copy_with(temperature=1, log_name=Questionnaire.role_name),
        )
        self.history = history
        self.questionnaire_sysprompt = questionnaire_sysprompt

    async def areply(self, session_data: dict) -> str | None:
        self.history = [message for message in self.history if message.text is not None]

        self.history.append(SysMessage(text=self.questionnaire_sysprompt))
        self.history.append(SysMessage(text=f"No need to query known items from the form: {session_data}."))

        r = await self._areply(to_langchain_messages(self.history), session_data)
        reply = r.text if isinstance(r, Break) else r
        return reply

    @arun
    async def _areply(self, history: list[BaseMessage], session_data: dict) -> str:
        ...

    @staticmethod
    def check(session_data: dict):
        check = True
        for key, value in session_data.items():
            if not value or value == "":
                check = False
                break
        return check
