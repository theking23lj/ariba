from agentcore.base import arun
from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, MessageType
from agentcore.roles.basic import BasicRole


class Summarizer(BasicRole):
    name: str

    def __init__(self, name: str):
        super().__init__()
        self.name = name
        self.history_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: self.name + ":\n{text}",
                MessageType.FUNCTION_CALL: self.name + " called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )

    async def summarize(self, summary: str, new_lines: list[AbstractMessage]) -> str:
        new_lines = self.history_template.format(new_lines)
        return await self._summarize(summary, new_lines)

    @arun
    async def _summarize(self, summary: str, new_lines: str) -> str:
        ...
