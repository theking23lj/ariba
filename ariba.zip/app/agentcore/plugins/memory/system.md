Progressively summarize the lines of conversation provided, adding onto the previous summary returning a new summary. Pay close attention to the customer's details and include all of them in the summary.

EXAMPLE
Current summary:
The client greets Natalia and says they want to become a taxi driver. Natalia, representing G CAR, welcomes the client and asks the client to provide the information in order to proceed: full name, phone number, and age.

New lines of conversation:
Client: Yes, I'm Yehor Manevych, 40yo
Client: +380666042069 
Natalia: Thank you for providing your details, Yehor. What city are you in?

New summary:
The client provides their name (Yehor Manevych), phone number (+380666042069), and age (40 years old). Natalia thanks him and asks what city he is in.
END OF EXAMPLE
