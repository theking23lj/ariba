from abc import ABC, abstractmethod
from collections.abc import Sequence

from langchain_openai.chat_models.base import BaseChatOpenAI
from pydantic import BaseModel, Field, field_validator

from agentcore.messages import AbstractMessage, SysMessage, to_langchain_messages
from agentcore.plugins.memory.summarizer import Summarizer
from agentcore.plugins.memory.summary_pruner import SummaryPruner
from agentcore.providers.messages import BaseProviderMessage


class SummaryMemory(BaseModel, ABC):
    """Summary memory.

    Example of usage:
    class MHPSummaryMemory(SummaryMemory):
        repo: BaseUserRepository

        async def _save_message(self, message: BaseProviderMessage):
            await self.repo.save_message(message)

        async def _mark_messages_as_summarized(self, messages: list[BaseProviderMessage]) -> None:
            await self.repo.mark_messages_as_summarized([m.db_msg_id for m in messages])

        async def _update_summary(self, chat_id: str, summary: str) -> None:
            await self.repo.update_summary(chat_id, summary)

    memory = MHPSummaryMemory(
        repo=repo,
        prev_messages=history, # fetched from db
        current_summary=summary, # fetched from db
        summarizer=Summarizer(name=settings.BOT_NAME)
    )

    memory.history - to get all history of chat
    memory.append(message) - to append message to current history


    class SomeUserChat:
        async def commit(self) -> None:
            messages = []
            for msg in self.memory.current_messages: # iterate over current messages
                tg_message = self.create_chat_message_based_on_last(msg) # create provider message
                messages.append(tg_message)

            await self.memory.commit(messages, self.id) # commit with current messages casted to provider messages
            # and with chat id, to indicate to which chat messages should be saved

            reply_msg = messages[-1] if messages else None

            if reply_msg:
                await self._send_reply(reply_msg) # send reply to some provider from bot

    VERY IMPORTANT NOTE: use memory.commit only with a guarantee that the commit will proceed to the end,
    otherwise it could lead to some inconsistency in db and agents

    if we run agent under some asyncio task, and we can cancel the task if user sends another message
    there is an example how to handle this situation:

    @contextmanager
    def suppress_asyncio_cancel():
        try:
            yield
        except asyncio.CancelledError:
            # Catch the CancelledError, so we don't cancel the task on commit.
            pass

    with suppress_asyncio_cancel():
        await memory.commit(messages, self.id)


    """

    summarizer: Summarizer
    """Summarizer instance, used to summarize messages if token limit is exceeded"""
    summary_pruner: SummaryPruner = Field(default_factory=lambda: SummaryPruner())
    """Summary pruner instance, used to prune summary if it's too long"""

    upper_limit: int = 3000
    """Upper limit of tokens of messages, if exceeded, history is summarized"""
    lower_limit: int = 1500
    """Lower limit of tokens of messages,
    if upper limit is exceeded, history is summarized until lower limit is reached"""
    summary_limit: int = 1000
    """Summary limit, if summary is too long, it's pruned"""

    prev_messages: list[BaseProviderMessage]
    """List of messages from some database"""
    current_messages: list[AbstractMessage] = []
    """List of messages from current bot session"""
    current_summary: str
    """Current summary from some database"""

    @field_validator("prev_messages")
    def validate_prev_messages(cls, v):
        for msg in v:
            if msg.is_summarized:
                raise ValueError("prev_messages should not contain summarized messages")

        return v

    @property
    def history(self) -> list[AbstractMessage]:
        summary_message = SysMessage(self.current_summary)
        prev_history = BaseProviderMessage.from_provider_messages_to_ac(self.prev_messages)
        current_history = self.current_messages
        return [summary_message] + prev_history + current_history

    @property
    def llm(self) -> BaseChatOpenAI:
        return self.summarizer.llm

    def append(self, message: AbstractMessage):
        self.current_messages.append(message)

    @abstractmethod
    async def _save_message(self, message: BaseProviderMessage):
        """save message to db"""

    async def commit(self, new_messages: list[BaseProviderMessage], chat_id: str) -> None:
        await self.prune(chat_id)

        for msg in new_messages:
            await self._save_message(msg)

    @abstractmethod
    async def _mark_messages_as_summarized(self, messages: list[BaseProviderMessage]) -> None:
        """mark messages as summarized in db"""

    @abstractmethod
    async def _update_summary(self, chat_id: str, summary: str) -> None:
        """update summary in db"""

    @property
    def msg_history_len(self) -> int:
        prev_history = BaseProviderMessage.from_provider_messages_to_ac(self.prev_messages)
        current_history = self.current_messages
        msg_history = prev_history + current_history
        lc_history = to_langchain_messages(msg_history)
        return self.llm.get_num_tokens_from_messages(lc_history)

    async def prune(self, chat_id: str) -> None:
        """summaries history if it's too long, if summary is too long, prunes it"""
        history_len = self.msg_history_len
        if history_len > self.upper_limit:
            history_to_summarize = []
            while history_len > self.lower_limit:
                if len(self.prev_messages) == 0:
                    break

                history_to_summarize.append(self.prev_messages.pop(0))
                # recount history_len
                history_len = self.msg_history_len

            if history_to_summarize:
                ac_summarized_history = BaseProviderMessage.from_provider_messages_to_ac(history_to_summarize)
                new_summary = await self.summarizer.summarize(self.current_summary, ac_summarized_history)
                combined_summary = self.current_summary + new_summary

                await self._mark_messages_as_summarized(history_to_summarize)

                if len(combined_summary) > self.summary_limit:
                    combined_summary = await self.summary_pruner.prune_summary(combined_summary)

                await self._update_summary(chat_id, combined_summary)

    class Config:
        arbitrary_types_allowed = True
