from agentcore.base import arun
from agentcore.roles.basic import BasicRole


class SummaryPruner(BasicRole):
    @arun
    async def prune_summary(self, summary: str) -> str:
        ...
