Summary:
{summary}

Pruned summary:
