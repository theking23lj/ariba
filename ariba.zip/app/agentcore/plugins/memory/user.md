DO NOT repeat information from Current Summary in New summary. Only summarize the New Lines.
Keep in mind all the details(errors, names etc.) and add them to the Summary.

Current Summary:
{summary}

New Lines:
{new_lines}

New summary:
