from typing import List, Dict, Any
from abc import ABC, abstractmethod


class AbstractRepository(ABC):
    @abstractmethod
    async def get_sections(self) -> Dict[str, Any]:
        pass

    async def get_section(self, title) -> str:
        pass

    @abstractmethod
    async def save_section(self, title: str, content: Any):
        pass

    @abstractmethod
    async def update_section(self, title: str, content: str):
        pass

    @abstractmethod
    async def delete_section(self, title: str):
        pass

    @abstractmethod
    async def get_section_titles(self) -> List[str]:
        pass
