The user had the following conversation with the agent

{user_chat}

The agent was missing the information, so it asked the admin for help

{admin_chat}

Extract the information that the agent was missing from its chat with the admin. Write this information as a fact without any additional words