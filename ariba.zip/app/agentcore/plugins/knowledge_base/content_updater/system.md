There is text that may need to be updated to reflect new information

This is the text:

{current_content}


This is the new information:

{new_info}


If the text needs updating, write its updated version, incorporating the new information in it. Preserve the overall structure of the text.
If the text doesn't need updating, just write it as it is word by word
Write only the content of the text, don't use any additional words