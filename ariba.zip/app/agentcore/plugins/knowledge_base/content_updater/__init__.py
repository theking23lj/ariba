from agentcore.base import arun
from agentcore.roles.basic import BasicRole


class ContentUpdater(BasicRole):
    @arun
    async def aupdate(self, current_content: str, new_info: str) -> str:
        ...