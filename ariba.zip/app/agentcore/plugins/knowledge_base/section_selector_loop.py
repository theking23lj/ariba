from dataclasses import dataclass
import logging
from agentcore.actions import Action, Continue, Finish
from agentcore.loop import Loop, loop
from agentcore.plugins.knowledge_base.content_updater import ContentUpdater
from agentcore.plugins.knowledge_base.section_selector import SectionSelector
from agentcore.plugins.knowledge_base.repository import AbstractRepository


@dataclass
class SectionSelectorLoop(Loop):
    repository: AbstractRepository
    before_titles: list[str]

    def __post_init__(self):
        self.max_iterations = 7
        self.updated_sections_titles: list[str] = []
        self.new_sections_titles: list[str] = []
        self.new_or_updated_info: dict[str, str] = {}

    @loop
    async def update_sections(self, info) -> Action:
        # Selects an already exiting section to put the info in. Or, alternatively creates a new one. Or calls a function to break from the loop
        action = await SectionSelector().select(
            content=info,
            titles=self.before_titles,
            updated_sections=self.updated_sections_titles+self.new_sections_titles
        )

        if isinstance(action, Finish):
            title = action.text.replace("*", "").strip()
            if title in self.before_titles:
                self.updated_sections_titles.append(title)
            else:
                self.new_sections_titles.append(title)

            # If SectionSelector selected an already existing section, than we incorporate the new information into it
            if title in self.before_titles:
                logging.info(f"Selected an existing section:\n{title}")
                # Update the existing
                content = await ContentUpdater().aupdate(
                    current_content=await self.repository.get_section(title),
                    new_info=info
                )
                logging.info(f"Updated its content:\n{content}")

            # SectionSelector decided to create a new section
            else:
                logging.info(f"Created a new section:\n{title}")
                self.before_titles.append(title)
            self.new_or_updated_info[title] = info
            return Continue(action.message)
        else:
            return action
