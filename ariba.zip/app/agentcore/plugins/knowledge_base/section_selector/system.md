There is an information document, containing different sections. There is also some new information that has to be added to the document. You have to decide whether the new information should go into a totally new section of the document or should be added to already existing one.

List of already existing sections:
{titles}

And this is the new information:
{content}

You've already added the information to sections:
{updated_sections}

Now write a name of a new section for the information or a name of an existing section to put the information in or signal that you are done.
Be careful when choosing an existing section. You should pick an already existing section only if you are sure that the new information should be placed there
More often you should just come up with a name for a new section or signal that you are done
You have to pick or come up with only one section and write only it's name without any additional words. If you've already added information to all the relevant sections, or if you don't think the information is worth adding anywhere, call the function to signal that you're done.