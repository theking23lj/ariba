import logging
from agentcore.base import aplan
from agentcore.actions import Action
from agentcore.function import Break, Function
from agentcore.roles.basic import BasicRole


class SectionSelector(BasicRole):
    def __init__(self):
        super().__init__(functions=[
            Function.from_func(self._signal_done, after=self._after_done)
            ])

    async def _signal_done(self):
        '''Signal that you've already added the new information to all the relevant sections'''
        logging.info("SectionSelector decided that the info was successfully added")

    def _after_done(self, *args, **kwargs):
        return Break()
        

    async def select(self, content: str, titles: list[str], updated_sections:list[str]) -> Action:
        return await self._select(content, "*" + "\n* ".join(titles), "*" + "\n* ".join(updated_sections))

    @aplan
    async def _select(self, content: str, titles: str, updated_sections:str) -> Action:
        ...
