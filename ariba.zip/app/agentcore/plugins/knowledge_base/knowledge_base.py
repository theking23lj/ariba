import logging

from agentcore.base import arun
from agentcore.history_template import HistoryTemplate
from agentcore.messages import AbstractMessage, MessageType
from agentcore.plugins.knowledge_base.section_selector_loop import SectionSelectorLoop
from agentcore.roles.basic import BasicRole
from agentcore.plugins.knowledge_base.repository import AbstractRepository
from typing import List


class KnowledgeBase(BasicRole):
    def __init__(self, repository: AbstractRepository):
        super().__init__()
        self.repository = repository
        self.user_chat_template = HistoryTemplate(
            {
                MessageType.SYSTEM: "Context:\n{text}",
                MessageType.USER: "User:\n{text}",
                MessageType.AGENT: "Agent:\n{text}",
                MessageType.FUNCTION_CALL: "Agent called function {func_name} with args:\n{args}",
                MessageType.FUNCTION_RESULT: "Function {func_name} returned:\n{value}",
            }
        )
        self.admin_chat_template = HistoryTemplate(
            {
                MessageType.USER: "Admin:{text}",
                MessageType.AGENT: "Agent:{text}",
            }
        )

    async def read(self, title: str):
        # Instead of getting all sections in the constructor, get the required section on demand
        content = await self.repository.get_section(title)
        return content if content else "Nothing found"

    async def awrite(self, user_chat: List[AbstractMessage], admin_chat: List[AbstractMessage]) -> str:
        # Extracts the information, missing from the document, based on the conversations with the user and admin
        content = await self._extract_info(
            self.user_chat_template.format(user_chat), self.admin_chat_template.format(admin_chat)
        )
        logging.info(f"Extracted info:\n{content}")

        # Iteratively update ALL the sections that should contain the info and add new sections if necessary
        a = SectionSelectorLoop(repository=self.repository, before_titles=await self.repository.get_section_titles())
        await a.update_sections(content)

        for title in a.updated_sections_titles:
            await self.repository.update_section(title=title, content=a.new_or_updated_info.get(title))
        for title in a.new_sections_titles:
            await self.repository.save_section(title=title, content=a.new_or_updated_info.get(title))

        # Return the new info, so that the agent could reply immediately using this info
        return content

    @property
    async def titles(self):
        # Get section titles from the repository
        return await self.repository.get_section_titles()

    @arun
    async def _extract_info(self, user_chat: str, admin_chat: str) -> str:
        ...
