import asyncio

from functools import wraps

from langchain.callbacks import get_openai_callback
from openai import RateLimitError

from agentcore.messages import (
    AbstractMessage,
)

class Context:
    """Context for the current message from the user"""
    def __init__(
            self,
            chat_id: int,
            user_id: int,
            message_id: int,
            message: AbstractMessage,
            current_tokens: int = 0,
    ):
        self.current_tokens: int = current_tokens
        self.tokens_per_request: int = 0
        self.chat_id: int = chat_id
        self.user_id: int = user_id
        self.message_id: int = message_id
        self.message: AbstractMessage = message


def token_counter(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            with get_openai_callback() as cb:
                result = await func(*args, **kwargs)
                context = kwargs.get("context")
                if context is not None:
                    context.current_tokens += cb.total_tokens
                    context.tokens_per_request = cb.total_tokens
                    print(f"Spent for current request: {cb.total_tokens} tokens")
                    print(f"Total spent in this context: {context.current_tokens} tokens")
        except RateLimitError as e:
            print(e)  # TODO: log
            await asyncio.sleep(10)
        return result
    return wrapper
