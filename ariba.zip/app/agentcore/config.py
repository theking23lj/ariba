from abc import abstractmethod
import asyncio
from dataclasses import dataclass
from datetime import date
import json
from logging import Logger
import logging
import os
from pathlib import Path
from typing import Tuple
from langchain_openai.chat_models.base import BaseChatOpenAI, ChatOpenAI
from langchain_openai.chat_models.azure import AzureChatOpenAI


def get_loggers(name: str, logs_path: Path) -> Tuple[Logger, Logger]:
    if not logs_path.exists():
        os.makedirs(logs_path)

    def logger(file, name):
        f_handler = logging.FileHandler(logs_path / file, encoding="utf-8")
        f_handler.setLevel(logging.DEBUG)
        f_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%H:%M:%S"
            )
        )
        logger = logging.getLogger(name)
        logger.handlers.clear()
        logger.setLevel(logging.DEBUG)
        logger.addHandler(f_handler)
        logger.propagate = False
        return logger

    return logger(str(date.today()) + ".log", name.lower()), logger(
        str(date.today()) + "_long.log", name.upper()
    )


def get_llm(llm: BaseChatOpenAI, logger: Logger, long_logger: Logger):
    # class that wraps another class and logs all function calls being executed
    class Wrapper:
        def __init__(self, wrapped_class, logger: Logger, long_logger: Logger):
            self.wrapped_class = wrapped_class
            self.logger = logger
            self.long_logger = long_logger

        def __getattr__(self, attr):
            original_func = getattr(self.wrapped_class, attr)

            def log_request(**kwargs):
                m = kwargs.get("messages")
                self.logger.debug(f"Request: {json.dumps(m, indent=2, ensure_ascii=False)}")
                self.long_logger.debug(
                    f"Request: {json.dumps(kwargs, indent=2, ensure_ascii=False)}"
                )

            def log_response(result):
                if hasattr(result, "choices"):
                    c = result.choices
                    if len(c) > 0:
                        self.logger.debug(f"Response: {c[0].message.json()}")
                        self.long_logger.debug(c[0].message.json())

            async def awrapper(*args, **kwargs):
                log_request(**kwargs)
                result = await original_func(*args, **kwargs)
                log_response(result)
                return result

            def wrapper(*args, **kwargs):
                log_request(**kwargs)
                result = original_func(*args, **kwargs)
                log_response(result)
                return result

            func = original_func
            if hasattr(original_func, "__wrapped__"):
                func = original_func.__wrapped__

            if asyncio.iscoroutinefunction(func):
                return awrapper
            else:
                return wrapper

    # overwrite the private `client` attribute inside of the LLM that contains the API client with our wrapped class
    llm.client = Wrapper(llm.client, logger, long_logger)
    llm.async_client = Wrapper(llm.async_client, logger, long_logger)

    return llm


@dataclass(kw_only=True)
class BaseLLMConfig:
    model: str = "gpt-4-0613"
    temperature: float = 0.5
    log_name: str = "agentcore"
    max_tokens: int | None = None

    @abstractmethod
    def get_llm(self) -> BaseChatOpenAI:
        ...

    def copy(self):
        return self.__class__(**self.__dict__)

    def copy_with(
        self,
        model: str | None = None,
        temperature: float | None = None,
        log_name: str | None = None,
        max_tokens: int | None = None,
    ):
        new = self.copy()
        new.model = model or self.model
        new.temperature = temperature if temperature is not None else self.temperature
        new.log_name = log_name or self.log_name
        new.max_tokens = max_tokens or self.max_tokens
        return new


@dataclass
class OpenAIConfig(BaseLLMConfig):
    api_key: str

    def get_llm(self):
        llm = ChatOpenAI(model=self.model, temperature=self.temperature, api_key=self.api_key)
        return get_llm(llm, *get_loggers(self.log_name, Path("./logs")))


@dataclass
class AzureConfig(BaseLLMConfig):
    api_key: str
    endpoint: str
    api_version: str
    deployment_name: str

    def get_llm(self):
        llm = AzureChatOpenAI(
            model=self.model,
            temperature=self.temperature,
            api_key=self.api_key,
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
            azure_deployment=self.deployment_name
        )
        return get_llm(llm, *get_loggers(self.log_name, Path("./logs")))


global_config: BaseLLMConfig | None = None


# TODO: rename to init_global_config to emphasize that it should only be called once
def set_global_config(c: BaseLLMConfig):
    global global_config
    global_config = c


def get_global_config():
    if global_config:
        return global_config
    else:
        raise Exception(f"The global config is not set, call {set_global_config.__name__} first")
