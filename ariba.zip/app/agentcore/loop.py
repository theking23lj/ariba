from dataclasses import field, dataclass
from typing import Callable, Awaitable
import functools
import inspect
import logging
from agentcore.actions import Call, Continue, Finish
from agentcore.context import Context
from agentcore.messages import AbstractMessage, FunctionResult, FunctionCall
from agentcore.function import Break
from agentcore.utils import args_to_dict
from langsmith import traceable


@dataclass(kw_only=True)
class Loop:
    context: Context | None = None
    inter_steps: list[AbstractMessage] = field(default_factory=lambda: [])
    escape_func: Callable[[], Awaitable[str | None]] | None = None
    max_iterations: int = 10

def loop(func):
    # TODO: check that func returns Result
    @traceable(name=func.__qualname__)
    @functools.wraps(func)
    async def awrapper(self: Loop, *args, **kwargs) -> str | None:
        sig = inspect.signature(func)
        kwargs = args_to_dict(sig, *args, **kwargs)
        # TODO validate kwargs
        # TODO decide whether people will need to write custom code for plan method in the classes derived from BaseRole
        #     if yes, then this implementation will ignore their custom code
        for _ in range(self.max_iterations):
            action = await func(self, **kwargs)
            logging.debug("\n" + str(action) + "\n")
            if isinstance(action, Finish):
                return action.text
            if isinstance(action, Continue):
                continue
            elif isinstance(action, Call):
                result = await action.function.arun(action.text, **action.kwargs)
                logging.debug("\n" + str(result) + "\n")
                match result:
                    case Break():
                        if result.text is not None:
                            return result.text
                        else:
                            return
                    case _:
                        self.inter_steps.append(
                            FunctionCall(action.text, action.function.name, action.kwargs)
                        )
                        value = result if result is not None else "Complete"
                        self.inter_steps.append(
                            FunctionResult(func_name=action.function.name, value=value)
                        )
            else:
                raise Exception("Unknown action")  # TODO improve exception
        if self.escape_func:
            return await self.escape_func()
        else:
            raise Exception("Too many iterations")

    return awrapper
