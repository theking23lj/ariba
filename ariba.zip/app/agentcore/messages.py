import json
from dataclasses import dataclass
from enum import StrEnum
from langchain.output_parsers.json import SimpleJsonOutputParser

from langchain.schema.messages import (
    AIMessage,
    BaseMessage,
    FunctionMessage,
    HumanMessage,
    SystemMessage,
)


class MessageType(StrEnum):
    NONE = "none"
    SYSTEM = "system"
    USER = "user"
    AGENT = "agent"
    FUNCTION_CALL = "function_call"
    FUNCTION_RESULT = "function_result"


class MessageTypeContent(StrEnum):
    TEXT = "text"
    VOICE = "voice"
    FORWARD = "forward"
    IMAGE = "image"


@dataclass
class AbstractMessage:
    type = MessageType.NONE


@dataclass
class SysMessage(AbstractMessage):
    type = MessageType.SYSTEM
    text: str


@dataclass
class UserMessage(AbstractMessage):
    type = MessageType.USER
    text: str


@dataclass
class AgentMessage(AbstractMessage):
    type = MessageType.AGENT
    text: str


@dataclass
class FunctionCall(AbstractMessage):
    type = MessageType.FUNCTION_CALL
    text: str
    func_name: str
    args: dict


@dataclass
class FunctionResult(AbstractMessage):
    type = MessageType.FUNCTION_RESULT
    func_name: str
    value: str


@dataclass
class VoiceMessage(SysMessage):
    """The message type to handle when the user has sent a voice message."""
    content_type = MessageTypeContent.VOICE

    def __post_init__(self):
        self.text = "The user sent a voice message with the following content:\n\n> " + self.text.replace("\n", "\n> ")


@dataclass
class ImageMessage(SysMessage):
    """The type of message processed when the user submits an image."""
    content_type = MessageTypeContent.IMAGE

    def __post_init__(self):
        self.text = "The user sent an image with the following content::\n\n> " + self.text.replace("\n", "\n> ")


@dataclass
class ForwardMessage(SysMessage):
    """The message type to handle when a user forwards a message."""
    content_type = MessageTypeContent.FORWARD

    def __post_init__(self):
        self.text = "The user forwarded a message with the following content:\n\n> " + self.text.replace("\n", "\n> ")

# TODO: In the future, it may be necessary to handle cases where the AI will use different types of content


def to_langchain_message(m: AbstractMessage):
    match m:
        case SysMessage() as m:
            return SystemMessage(content=m.text)
        case UserMessage() as m:
            return HumanMessage(content=m.text)
        case AgentMessage() as m:
            return AIMessage(content=m.text)
        case FunctionCall() as m:
            return AIMessage(
                content="",
                additional_kwargs={
                    "function_call": {
                        "name": m.func_name,
                        "arguments": json.dumps(m.args, indent=2, ensure_ascii=False)
                    }
                },
            )
        case FunctionResult() as m:
            return FunctionMessage(content=m.value, name=m.func_name)
        case ForwardMessage() as m:
            return SystemMessage(content=m.text)
        case VoiceMessage() as m:
            return SystemMessage(content=m.text)
        case ImageMessage() as m:
            return SystemMessage(content=m.text)
        case _:
            raise Exception(f'Unsupported message type "{m}"')


def to_langchain_messages(messages: list[AbstractMessage]) -> list[BaseMessage]:
    return [to_langchain_message(m) for m in messages]


def from_langchain_message(m: BaseMessage):
    match m:
        case SystemMessage() as m:  # type: ignore[misc]
            return SysMessage(str(m.content))
        case HumanMessage() as m:  # type: ignore[misc]
            return UserMessage(str(m.content))
        case AIMessage() as m:
            return from_langchain_ai_message(m)
        case FunctionMessage() as m:  # type: ignore[misc]
            return FunctionResult(func_name=m.name, value=str(m.content))
        case _:
            raise Exception(f'Unsupported message type "{m.type}"')


def from_langchain_ai_message(message: AIMessage) -> AbstractMessage:
    if "function_call" in message.additional_kwargs:
        fname = message.additional_kwargs["function_call"]["name"]
        args = SimpleJsonOutputParser().parse(message.additional_kwargs["function_call"]["arguments"])
        return FunctionCall(func_name=fname, args=args, text=str(message.content))
    else:
        return AgentMessage(str(message.content))


def from_langchain_messages(messages: list[BaseMessage]) -> list[AbstractMessage]:
    return [from_langchain_message(m) for m in messages]
