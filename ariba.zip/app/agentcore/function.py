from dataclasses import dataclass
from typing import Awaitable, Callable, ParamSpec, Protocol, Generic
from pydantic.v1 import BaseModel
from langchain.tools.base import create_schema_from_function
from langsmith import traceable

@dataclass
class Break:
    text: str | None = None


P = ParamSpec("P")

FunctionOutput = str | Break | None


@dataclass
class Function(Generic[P]):
    class AfterCallable(Protocol):
        def __call__(
            self, result: str | None, text: str, *args: P.args, **kwargs: P.kwargs
        ) -> FunctionOutput:
            ...

    name: str
    desc: str
    func: Callable[P, Awaitable[str | None]]
    args_schema: type[BaseModel]
    after: AfterCallable | None = None

    async def arun(self, text: str = "", *args: P.args, **kwargs: P.kwargs) -> FunctionOutput:
        r = await self.func(*args, **kwargs)
        if self.after is not None:
            return self.after(r, text, *args, **kwargs)
        else:
            return r

    @classmethod
    def from_func(
        cls,
        func: Callable[P, Awaitable[str | None]],
        name: str | None = None,
        args_schema: type[BaseModel] | None = None,
        desc: str | None = None,
        after: AfterCallable | None = None,
    ):
        desc = desc if desc else func.__doc__
        if desc is None:
            raise Exception("Provide the description of the function or add a docstring to it")
        name = name if name else func.__name__
        if args_schema is None:
            args_schema = create_schema_from_function(f"{name}Schema", func)
        return cls(name, desc, traceable(run_type="tool")(func), args_schema, after)
