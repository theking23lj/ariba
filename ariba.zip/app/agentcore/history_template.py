from dataclasses import dataclass

from agentcore.messages import AbstractMessage, MessageType


def to_template_vars(obj):
    d = {}
    for k, v in vars(obj).items():
        if v.__class__.__module__ != "builtins":
            child_d = to_template_vars(v)
            for ik, iv in child_d.items():
                d[k + "_" + ik] = iv
        else:
            d[k] = v
    return d


@dataclass
class HistoryTemplate:
    message_templates: dict[MessageType, str]

    def format_message(self, message: AbstractMessage) -> str:
        prompt_template = self.message_templates[message.type]
        return prompt_template.format(**to_template_vars(message))

    def format(self, messages: list[AbstractMessage]) -> str:
        return "\n".join([self.format_message(m) for m in messages])
