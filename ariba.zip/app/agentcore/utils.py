import inspect


def args_to_dict(sig: inspect.Signature, *args, **kwargs) -> dict:
    params = list(sig.parameters.keys())
    if params[0] == "self":
        params.pop(0)

    for name, value in zip(params, args):
        kwargs[name] = value
    return kwargs
