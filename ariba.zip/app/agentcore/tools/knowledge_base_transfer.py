from os import path

from agentcore.plugins.knowledge_base.repository import AbstractRepository


async def copy_md_file_to_repo(md_file_path: str, repo: AbstractRepository):
    data = {}
    current_key = None

    if not path.exists(md_file_path):
        return f"File by path: '{md_file_path}' is not exist."

    with open(md_file_path, 'r') as file:
        lines = file.readlines()

    for line in lines:
        if line.startswith("# "):
            current_key = line[2:].strip()
            data[current_key] = ""
        elif current_key is not None:
            data[current_key] += line

    for title, content in data.items():
        await repo.save_section(title, content.strip())

    return True
