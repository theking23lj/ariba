from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from agentcore.messages import (
    AbstractMessage,
    AgentMessage,
    FunctionCall,
    FunctionResult,
    MessageType,
    SysMessage,
    UserMessage,
    MessageTypeContent,
    ForwardMessage,
    VoiceMessage,
    ImageMessage
)


class BaseProviderUser(BaseModel):
    """Base user model for provider users such as telegram, email, etc."""

    summary: str = ""
    """User summary"""


class BaseProviderMessage(BaseModel):
    """Base message model for provider messages such as telegram, email, etc."""

    db_msg_id: Any
    """Unique message id in db"""
    text: str
    """Message text, in tg - text, in email - body of email and etc."""
    date: str
    """Message date(from client)"""
    timestamp: int = Field(default_factory=lambda: int(round(datetime.now().timestamp())))
    """Message timestamp(from our side, could be used to sort messages)"""
    is_summarized: bool = Field(default=False)
    """Is message summarized, could be used to filter messages, used in summary memory"""

    # message type specific fields
    type: str
    """Message type - AbstractMessage.type"""
    content_type: str = MessageTypeContent.TEXT
    """Type of content in the message. Necessary if there is a need to process photos or voice messages"""
    func_name: str | None = None
    """Function name, used in FunctionCall and FunctionResult messages"""
    args: dict[str, Any] | None = None
    """Function args, used in FunctionCall messages"""

    def from_provider_message_to_ac(self) -> AbstractMessage:
        match self.content_type:
            case MessageTypeContent.TEXT:
                match self.type:
                    case MessageType.USER:
                        return UserMessage(self.text)
                    case MessageType.AGENT:
                        return AgentMessage(self.text)
                    case MessageType.SYSTEM:
                        return SysMessage(self.text)
                    case MessageType.FUNCTION_CALL:
                        return FunctionCall(
                            text=self.text,
                            func_name=self.func_name,
                            args=self.args,
                        )
                    case MessageType.FUNCTION_RESULT:
                        return FunctionResult(
                            value=self.text,
                            func_name=self.func_name,
                        )
                    case _:
                        raise Exception(f'Unsupported message type "{self.type}"')
            case MessageTypeContent.FORWARD:
                return ForwardMessage(self.text)
            case MessageTypeContent.VOICE:
                return VoiceMessage(self.text)
            case MessageTypeContent.IMAGE:
                return ImageMessage(self.text)
            case _:
                raise Exception(f'Unsupported message content type "{self.content_type}"')

    @staticmethod
    def from_provider_messages_to_ac(messages: list["BaseProviderMessage"]) -> list[AbstractMessage]:
        return [m.from_provider_message_to_ac() for m in messages]

    class Config:
        arbitrary_types_allowed = True
