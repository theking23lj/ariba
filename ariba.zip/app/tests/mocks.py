import json
from pprint import pprint
from tenders.models import Tender, TenderCategory

def mock_get_active_tenders() -> list[Tender]:
    """load tenders from json file"""
    with open('data/tenders.json', 'r') as f:
        fetched_tenders = json.load(f)
        return [Tender(**t) for t in fetched_tenders]
    

def mock_get_categories() -> list[TenderCategory]:
    """ load categories from json file"""
    with open('data/categories.json', 'r') as f:
        fetched_categories = json.load(f)
        return [TenderCategory(**t) for t in fetched_categories]

def mock_tg_send_reply(*args, **kwargs) -> None:
    pprint(args[1].text, width=100)