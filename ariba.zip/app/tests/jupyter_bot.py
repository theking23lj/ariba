
import os
import sys
import logging

app_dir = os.path.dirname(os.getcwd())
sys.path.append(app_dir)

from datetime import datetime
from dotenv import load_dotenv
from unittest.mock import patch

from langchain.callbacks import get_openai_callback
from agentcore.config import OpenAIConfig, set_global_config

from tests.mocks import mock_get_active_tenders, mock_get_categories, mock_tg_send_reply
from tools import create_knowledge_base
from repos.tg_user import TgUserMongoRepository
from tenders.services import fetch_tender_categories, fetch_tenders
from chats.tg_chat import TgChat
from providers.tg.models import TgMessage, TgUser
from message_handler import MessageHandler
from token_handler import TokenHandler

from utils.logger import logger_manager
logger = logger_manager.get_logger()

TEST_CHAT_ID = "123"
TEST_USER = TgUser(chat_id=TEST_CHAT_ID, username="test_user", first_name="Test", last_name="User")
load_dotenv(os.path.join(app_dir, ".env.dev"))
load_dotenv(os.path.join(app_dir, ".env"))
from settings import settings
set_global_config(OpenAIConfig(settings.OPENAI_KEY, model=settings.LLM_MODEL))


class JupyterBot:
    message_handler = MessageHandler()   
    
    async def setup(self, mock_tender_requests: bool = False):
        await create_knowledge_base(os.path.join(app_dir, "info.md"))
        if mock_tender_requests:
            with patch("tenders.mhp_client.MHPClient.get_active_tenders") as mock_get_tenders:
                mock_get_tenders.side_effect = mock_get_active_tenders
                await fetch_tenders()
            with patch("tenders.mhp_client.MHPClient.get_categories") as mock_categories:
                mock_categories.side_effect = mock_get_categories
                await fetch_tender_categories()
        else:
            await fetch_tenders()
            await fetch_tender_categories()

    async def reply_to(self, message: str) -> None:
        repo = await TgUserMongoRepository.get_instance()
        tg_message = TgMessage(
            chat_id=TEST_CHAT_ID,
            text=message,
            type="user",
            content_type="text",
            date=datetime.now().isoformat(),
            username="test_user",
            first_name="Test",
            last_name="User"
        )
        await repo.save_message(tg_message)

        with get_openai_callback() as cb:
            user_chat = await TgChat.build(TEST_CHAT_ID)
            with patch("chats.tg_chat.TgChat._send_reply", autospec=True) as send_reply:
                send_reply.side_effect = mock_tg_send_reply
                await self.message_handler.handle_user_message(user_chat)
            prompt_tokens = cb.prompt_tokens
            completion_tokens = cb.completion_tokens
            await TokenHandler.handle_token_usage(repo, TEST_CHAT_ID, prompt_tokens, completion_tokens)

    @staticmethod
    async def reset_chat() -> None:
        repo = await TgUserMongoRepository.get_instance()
        await repo.delete_tg_messages(TEST_CHAT_ID)
        await repo.clear_chosen_categories(TEST_USER)
