from fastapi import Security, HTTPException, status
from fastapi.security import APIKeyQuery, APIKeyHeader
from settings import settings


api_key_query = APIKeyQuery(name="api-key", auto_error=False)
api_key_header = APIKeyHeader(name="x-api-key", auto_error=False)


def verify_api_key(
    api_key_query: str = Security(api_key_query),
    api_key_header: str = Security(api_key_header),
):  
    if all([
        api_key_query != settings.ADMIN_API_KEY,
        api_key_header != settings.ADMIN_API_KEY,
    ]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, 
                            detail="Missing or invalid API key")
