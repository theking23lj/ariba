from fastapi import FastAPI

health_check_app = FastAPI()

@health_check_app.head("/")
async def health_check():
    return {"msg": "OK"}

