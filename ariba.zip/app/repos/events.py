from datetime import datetime
from agentcore.messages import (
    FunctionCall,
    FunctionResult,
    SysMessage,
    UserMessage,
    AgentMessage,
)
from providers.base.models import BaseMHPMessage
from repos.base import BaseRepository


class EventsRepository(BaseRepository):
    def create_event(self, chat_id: str, message: FunctionCall | FunctionResult | SysMessage) -> BaseMHPMessage:
        text, func_name, args = None, None, None
        match message:
            case FunctionCall() as m:
                text = m.text
                func_name = m.func_name
                args = m.args
            case FunctionResult() as m:
                text = m.value
                func_name = m.func_name
            case SysMessage() | UserMessage() | AgentMessage() as m:
                text = m.text
            case _:
                raise Exception(f"Email message of type {message.type} can't be added as an event")
            
        return BaseMHPMessage(
            _id=None,
            chat_id=chat_id,
            type=message.type,
            text=text,
            func_name=func_name,
            args=args,
            # TODO move datetime format to common
            date=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        )

    async def insert(self, event: BaseMHPMessage) -> None:
        await self.db.events.insert_one(event.model_dump())

    async def get_events(self, chat_id) -> list[BaseMHPMessage]:
        return [BaseMHPMessage(**e) for e in await self.db.events.find({"chat_id": chat_id, "is_summarized": False}).to_list(None)]


    async def clear_old_events(self, timestamp: int) -> None:
        await self.db.events.update_many(
            {"timestamp": {"$lt": timestamp}},
            {"$set": {"is_summarized": True}}
        )