from bson import ObjectId
from motor.core import AgnosticCollection

from providers.email.models import UserEmailMessage, EmailUser
from repos.base import BaseUserRepository


class EmailUserMongoRepository(BaseUserRepository):
    @property
    def users_collection(self) -> AgnosticCollection:
        return self.db.email_users

    @property
    def messages_collection(self) -> AgnosticCollection:
        return self.db.email_messages

    async def _add_email_user_if_not_exists(self, message: UserEmailMessage) -> None:
        user = await self.db.email_users.find_one({"chat_id": message.from_email})
        if not user:
            data = message.get_user().model_dump()
            await self.db.email_users.insert_one(data)

    async def _add_email_message(self, message: UserEmailMessage) -> None:
        data = message.model_dump()
        await self.db.email_messages.insert_one(data)

    async def save_message(self, message: UserEmailMessage):
        await self._add_email_user_if_not_exists(message)
        await self._add_email_message(message)

    async def get_history(self, chat_id: str) -> list[UserEmailMessage]:
        messages = await self.db.email_messages.find({"chat_id": chat_id, "is_summarized": False}).to_list(None)
        email_messages = []
        for message in messages:
            email_messages.append(UserEmailMessage(**message))

        return email_messages

    async def mark_messages_as_summarized(self, message_ids: list[ObjectId]) -> None:
        await self.db.email_messages.update_many({"_id": {"$in": message_ids}}, {"$set": {"is_summarized": True}})

    # TODO we need to split collections of users, chats and messages
    # summary should be a field in the chat
    # it's now critical right now, since email chats are never summarized
    async def get_summary(self, chat_id: str) -> str:
        user = await self.db.email_users.find_one({"chat_id": chat_id})
        user = EmailUser(**user)
        return user.summary

    async def get_all_users(self) -> list[EmailUser]:
        users = await self.db.email_users.find().to_list(None)

        return [EmailUser(**u) for u in users]

    #TODO rename to get_user_by_id or better find_user_by_id
    async def get_user_by_chat_id(self, chat_id: str) -> EmailUser | None:
        user = await self.db.email_users.find_one({"chat_id": chat_id})

        return EmailUser(**user) if user else None