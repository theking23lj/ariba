from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, VectorParams
from langchain.embeddings import OpenAIEmbeddings, AzureOpenAIEmbeddings

import uuid
from abc import ABC, abstractmethod
from typing import Self, List

from bson import ObjectId
from motor.core import AgnosticCollection
from motor.motor_asyncio import AsyncIOMotorDatabase, AsyncIOMotorClient
from repos.language_converter import BaseLang
from providers.base.models import BaseProviderMessage, BaseUser
from settings import settings
from tenders.models import Tender, TenderCategory


class BaseRepository(ABC):
    db: AsyncIOMotorDatabase

    def __init__(self, db: AsyncIOMotorDatabase):
        self.db = db

    @classmethod
    async def get_instance(cls) -> Self:
        client = AsyncIOMotorClient(settings.MONGO_URI)
        await client.admin.command('ping')

        db = client.get_database(settings.MONGO_DB_NAME)

        return cls(db=db)


class BaseQdrantRepository(ABC):

    @classmethod
    async def get_qdrant_client(cls, collection_name) -> AsyncQdrantClient:
        client = AsyncQdrantClient(url=settings.VECTOR_DB_URL, api_key=settings.VECTOR_DB_API_KEY)

        is_collection = await client.collection_exists(
            collection_name=collection_name
        )
        if not is_collection:
            await client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(size=1536, distance=Distance.COSINE),
            )
        return client

    @staticmethod
    async def get_embeddings_model() -> OpenAIEmbeddings:
        if settings.LLM_API_TYPE == "azure":
            return AzureOpenAIEmbeddings(
                deployment=settings.AZURE_EMBEDDING_NAME,
                azure_endpoint=settings.AZURE_ENDPOINT,
                api_key=settings.AZURE_KEY
            )
        else:
            return OpenAIEmbeddings(openai_api_key=settings.OPENAI_KEY)

    @staticmethod
    async def generate_id(content: str):
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, content))

    async def get_vector(self, text: str):
        embeddings_model = await self.get_embeddings_model()
        return embeddings_model.embed_query(text)

    async def get_list_of_vectors(self, list_of_text: List[str]):
        embeddings_model = await self.get_embeddings_model()
        return embeddings_model.embed_documents(list_of_text)


class BaseChatRepository(BaseRepository):
    async def get_history(self, chat_id: str) -> list[BaseProviderMessage]:
        """Get history of messages of some chat"""


class BaseUserRepository(BaseChatRepository):
    @property
    @abstractmethod
    def users_collection(self) -> AgnosticCollection:
        """Get mongo collection for storage users."""

    @property
    @abstractmethod
    def messages_collection(self) -> AgnosticCollection:
        """Get mongo collection for storage messages."""

    @abstractmethod
    async def save_message(self, message: BaseProviderMessage) -> None:
        """Save message to db"""

    @abstractmethod
    async def mark_messages_as_summarized(self, message_ids: list[ObjectId]) -> None:
        """Mark messages as summarized"""

    @abstractmethod
    async def get_summary(self, chat_id: str) -> str:
        """Get summary of chat"""

    async def update_summary(self, chat_id: str, summary: str) -> None:
        """Update summary of chat"""
        await self.users_collection.update_one(
            {"chat_id": chat_id},
            {"$set": {"summary": summary}}
        )

    @abstractmethod
    async def get_user_by_chat_id(self, chat_id: str) -> BaseUser:
        """Get the user by chat id"""

    @abstractmethod
    async def get_all_users(self) -> list[BaseUser]:
        """Get all users"""

    async def assert_user_exists(self, user: BaseUser):
        if not await self.users_collection.find_one({"chat_id": user.chat_id}):
            raise Exception(f"User with chat_id = {user.chat_id} not found")

    async def add_watched_tenders(self, user: BaseUser, tenders: list[Tender]):
        """Update watched_tenders for the user"""
        watched_tenders = [t.internal_id for t in tenders]
        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$addToSet": {"watched_tender_ids": {"$each": watched_tenders}}}
        )

    async def clear_watched_tenders(self, user: BaseUser):
        """Clear watched_tender_ids for the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$set": {"watched_tender_ids": []}}
        )

    async def clear_watched_tenders_for_all(self, active_tender_ids: list[str]):
        """Clear watched_tender_ids for all users"""

        await self.users_collection.update_many(
            {},
            {"$pull": {"watched_tender_ids": {"$not": {"$in": active_tender_ids}}}}
        )

    async def add_waiting_tenders(self, user: BaseUser, tenders: list[Tender]):
        """Add waiting_tenders for the user"""
        waiting_tender_ids = [t.internal_id for t in tenders]
        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$addToSet": {"waiting_tender_ids": {"$each": waiting_tender_ids}}}
        )

    async def pull_waiting_tenders(self, user: BaseUser, tenders_ids: list[str]):
        """Pull waiting_tenders for the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$pullAll": {"waiting_tender_ids": tenders_ids}}
        )

    async def clear_waiting_tenders(self, user: BaseUser):
        """Clear waiting_tenders for the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$set": {"waiting_tender_ids": []}}
        )

    async def add_chosen_category(self, user: BaseUser, category: TenderCategory):
        """Add a category to chosen_categories of the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$addToSet": {"chosen_category_ids": category.unique_name}}
        )

    async def delete_chosen_category(self, user: BaseUser, category: TenderCategory):
        """Delete a category from chosen_categories of the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$pull": {"chosen_category_ids": category.unique_name}}
        )

    async def clear_chosen_categories(self, user: BaseUser):
        """Clear all the chosen_categories from the user"""
        await self.assert_user_exists(user)

        await self.users_collection.update_one(
            {"chat_id": user.chat_id},
            {"$set": {"chosen_category_ids": []}}
        )

    async def reset_tokens_for_user(self, chat_id: str):
        await self.db.tokens_spent.update_one(
            {"chat_id": chat_id},
            {"$set": {"prompt_tokens_cost": 0, "completion_tokens_cost": 0}}
        )
        await self.set_user_pause_status(chat_id, False)

    async def reset_tokens_for_all_users(self):
        """Attention! There are clearing the spent tokens for all users. Not only for current repo."""
        await self.db.tokens_spent.update_many(
            {},
            {"$set": {"prompt_tokens_cost": 0, "completion_tokens_cost": 0}}
        )
        await self.users_collection.update_many(
            {},
            {"$set": {"is_paused": False}}
        )

    async def update_token_usage(self, chat_id: str, prompt_tokens_cost: int, completion_tokens_cost: int):
        await self.db.tokens_spent.update_one(
            {"chat_id": chat_id},
            {"$inc": {"prompt_tokens_cost": prompt_tokens_cost, "completion_tokens_cost": completion_tokens_cost}},
            upsert=True
        )

    async def get_tokens_data(self, chat_id: str) -> dict:
        token_data = await self.db.tokens_spent.find_one({"chat_id": chat_id})
        if token_data is None:
            # Assume token counts are 0 if no data is found
            return {"prompt_tokens_cost": 0, "completion_tokens_cost": 0}

        return {
            "prompt_tokens_cost": token_data.get("prompt_tokens_cost", 0),
            "completion_tokens_cost": token_data.get("completion_tokens_cost", 0)
        }

    async def set_user_pause_status(self, chat_id: str, is_paused: bool):
        await self.users_collection.update_one(
            {"chat_id": chat_id},
            {"$set": {"is_paused": is_paused}}
        )

    async def delete_messages(self, user: BaseUser) -> None:
        """Deletes messages for a given user."""
        await self.assert_user_exists(user)
        await self.messages_collection.delete_many({"chat_id": user.chat_id})
        await self.update_summary(user.chat_id, "")


class BaseLanguageRepository(BaseRepository):

    async def get_language_or_default(self, chat_id: str) -> str:
        language = await self.db.language.find_one({"chat_id": chat_id})
        if language:
            return language.get("language", BaseLang.UKRAINIAN)
        return BaseLang.UKRAINIAN

    async def update_language(self, chat_id: str, language: str) -> None:
        await self.db.language.update_one(
            {"chat_id": chat_id},
            {"$set": {"language": language}},
            upsert=True
        )
