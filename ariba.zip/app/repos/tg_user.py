from bson import ObjectId
from motor.core import AgnosticCollection

from providers.tg.models import TgMessage, TgUser
from repos.base import BaseUserRepository
from utils.logger import logger_manager

logger = logger_manager.get_logger()


class TgUserMongoRepository(BaseUserRepository):
    @property
    def users_collection(self) -> AgnosticCollection:
        return self.db.tg_users

    @property
    def messages_collection(self) -> AgnosticCollection:
        return self.db.tg_messages

    async def _add_tg_user_if_not_exists(self, tg_message: TgMessage) -> None:
        user = await self.db.tg_users.find_one({"chat_id": tg_message.chat_id})
        if not user:
            data = tg_message.get_user().model_dump()
            await self.db.tg_users.insert_one(data)

    async def _add_tg_message(self, tg_message: TgMessage) -> None:
        data = tg_message.model_dump()
        await self.db.tg_messages.insert_one(data)

    async def save_message(self, tg_message: TgMessage):
        await self._add_tg_user_if_not_exists(tg_message)
        await self._add_tg_message(tg_message)

    async def get_history(self, chat_id: str) -> list[TgMessage]:
        messages = await self.db.tg_messages.find({"chat_id": chat_id, "is_summarized": False}).to_list(None)
        tg_messages = []
        for message in messages:
            tg_messages.append(TgMessage(**message))

        return tg_messages

    async def delete_tg_messages(self, chat_id: str) -> None:
        await self.db.tg_messages.delete_many({"chat_id": chat_id})

    async def mark_messages_as_summarized(self, message_ids: list[ObjectId]) -> None:
        await self.db.tg_messages.update_many({"_id": {"$in": message_ids}}, {"$set": {"is_summarized": True}})

    async def get_summary(self, chat_id: str) -> str:
        user = await self.db.tg_users.find_one({"chat_id": chat_id})
        user = TgUser(**user)
        return user.summary

    async def get_all_users(self) -> list[TgUser]:
        users = await self.db.tg_users.find().to_list(None)

        return [TgUser(**u) for u in users]

    async def get_user_by_chat_id(self, chat_id: str) -> TgUser | None:
        user = await self.db.tg_users.find_one({"chat_id": chat_id})

        return TgUser(**user) if user else None

    async def get_user_by_username(self, username: str) -> TgUser | None:
        user = await self.db.tg_users.find_one({"username": username})

        return TgUser(**user) if user else None

    async def add_chosen_categories(self, username: str, categories: list[str]):
        user = await self.db.tg_users.find_one({"username": username})
        if not user:
            return

        await self.db.tg_users.update_one(
            {"username": username},
            {"$addToSet": {"chosen_category_ids": {"$each": categories}}}
        )
