from enum import StrEnum


class BaseLang(StrEnum):
    UKRAINIAN = "uk"


async def language_converter(language):
    if language.lower() in ["uk", "ua", "ukrainian", "ru", "russian", ""]:
        return "uk"
    return "en"
