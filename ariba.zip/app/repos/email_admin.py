from providers.email.models import AdminThread, AdminEmailMessage
from repos.base import BaseChatRepository
from utils.logger import logger_manager

logger = logger_manager.get_logger()


class EmailAdminMongoRepository(BaseChatRepository):
    async def create_thread(self, user_id: str | None = None, chat_type: str | None = None, chat_id: str | None = None) -> AdminThread:
        thread =  AdminThread(user_id=user_id, chat_type=chat_type, chat_id=chat_id)
        data = thread.model_dump()
        await self.db.admin_threads.insert_one(data)
        return thread

    async def find_thread_id(self, message: AdminEmailMessage) -> str | None:
        message = await self.db.admin_thread_messages.find_one({"chat_id": message.chat_id})
        if message is None:
            return None

        return AdminEmailMessage(**message).thread_id

    async def add_message(self, message: AdminEmailMessage) -> None:
        data = message.model_dump()
        await self.db.admin_thread_messages.insert_one(data)

    async def get_thread_by_id(self, thread_id: str) -> AdminThread:
        thread = await self.db.admin_threads.find_one({"thread_id": thread_id})
        thread.pop('_id')
        return AdminThread(**thread)

    async def close_thread(self, thread_id: str):
        await self.db.admin_threads.update_one(
            {"thread_id": thread_id},
            {"$set": {"is_closed": True}}
        )

    async def get_open_threads(self) -> list[AdminThread]:
        threads = await self.db.admin_threads.find({"is_closed": False}).to_list(None)

        return [AdminThread(**t) for t in threads]

    async def get_history(self, thread_id: str) -> list[AdminEmailMessage]:
        messages = await self.db.admin_thread_messages.find({"thread_id": thread_id}).to_list(None)
        email_messages = []
        for message in messages:
            email_messages.append(AdminEmailMessage(**message))

        return email_messages
