from agentcore.plugins.knowledge_base.repository import AbstractRepository
from motor.core import AgnosticCollection

from repos.base import BaseRepository


class KnowledgeBaseRepository(BaseRepository, AbstractRepository):

    @property
    def collection(self) -> AgnosticCollection:
        return self.db.knowledge_base

    async def get_sections(self) -> dict[str, str]:
        documents = await self.collection.find({}).to_list(None)

        return {d['_id']: d.get('content', '') for d in documents}

    #TODO remane to find_section and change the return type to str | None
    async def get_section(self, title: str) -> str:
        document = await self.collection.find_one({'_id': title})
        return document.get('content', '') if document else None

    async def save_section(self, title: str, content: str):
        await self.collection.update_one({'_id': title}, {'$set': {'content': content}}, upsert=True)

    async def update_section(self, title: str, content: str):
        await self.collection.find_one_and_update({'_id': title}, {'$set': {'content': content}})

    async def delete_section(self, title: str):
        await self.collection.delete_one({'_id': title})

    async def get_section_titles(self) -> list[str]:
        cursor = await self.collection.find({}, {'_id': 1}).to_list(None)

        return [document['_id'] for document in cursor]
