from http.server import HTTPServer, BaseHTTPRequestHandler
from pymongo import MongoClient
import os
import datetime
import threading

# Load MongoDB URI from the environment variable
mongo_uri = os.getenv('MONGO_URI')

# Connect to MongoDB
client = MongoClient(mongo_uri)

def perform_backup():
    # Source database and collection
    source_db = client.mhp_prod
    source_collection = source_db.knowledge_base

    # Target backup database
    backup_db = client.backup

    # Get the current date to name the backup collection
    current_date = datetime.datetime.now().strftime("%d%m%y")
    backup_collection_name = f"knowledge_base_backup_{current_date}"

    # Target backup collection (automatically created if it doesn't exist)
    backup_collection = backup_db[backup_collection_name]

    # Fetch all documents from the source collection
    documents = list(source_collection.find({}))

    # If the documents list is not empty, insert into backup collection
    if documents:
        backup_collection.insert_many(documents)
        print(f"Backup of 'knowledge_base' saved to collection '{backup_collection_name}' in 'backup' database.")
    else:
        print("No documents found in 'knowledge_base'. No backup created.")

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/healthcheck':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            try:
                # Attempt to get a list of database names to check the connection
                client.list_database_names()
                self.wfile.write("Connection to MongoDB is healthy.".encode())
            except Exception as e:
                self.wfile.write(f"Failed to connect to MongoDB: {str(e)}".encode())
        elif self.path == '/trigger_backup':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            try:
                perform_backup()
                self.wfile.write("Backup initiated successfully.".encode())
            except Exception as e:
                self.wfile.write(f"Failed to initiate backup: {str(e)}".encode())
        else:
            self.send_response(404)
            self.end_headers()