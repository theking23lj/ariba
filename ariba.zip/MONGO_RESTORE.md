globaldb [primary] mhp_dev> use backup;
switched to db backup

globaldb [primary] backup> var docs = db.knowledge_base_backup_140224.find().toArray();

globaldb [primary] backup> use mhp_dev
switched to db mhp_dev
globaldb [primary] mhp_dev> db.knowledge_base.deleteMany({})
{ acknowledged: true, deletedCount: 88 }
globaldb [primary] mhp_dev> 

globaldb [primary] mhp_dev> docs.forEach(doc => db.knowledge_base.insertOne(doc));
