import uvicorn
from memray import Tracker
import os


# Fetch SSL key and certificate paths from environment variables
KEYFILE_PATH = os.getenv('KEYFILE_PATH', 'default_keyfile_path.pem')
CERTFILE_PATH = os.getenv('CERTFILE_PATH', 'default_certfile_path.pem')


def start_server():
    uvicorn.run("main:app",
                host="0.0.0.0",
                port=443,
                reload=True,
                forwarded_allow_ips='*',
                proxy_headers=True,
                ssl_keyfile=KEYFILE_PATH,
                ssl_certfile=CERTFILE_PATH)

if __name__ == "__main__":
    with Tracker("memray_output.bin"):
        start_server()
